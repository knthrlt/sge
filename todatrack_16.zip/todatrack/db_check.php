<?php
/**
 * Connection check. Open http://localhost/todatrack/db_check.php
 * (works only on your own computer) to see exactly what is wrong.
 */
require_once __DIR__ . '/config/helpers.php';
require_once __DIR__ . '/config/Database.php';

if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('This page works only on localhost.');
}

$checks = [];
$add = function (string $label, bool $ok, string $hint = '') use (&$checks) {
    $checks[] = ['label' => $label, 'ok' => $ok, 'hint' => $hint];
};

$conn = null;
$add('PHP extension pdo_pgsql is enabled', in_array('pgsql', PDO::getAvailableDrivers(), true),
     'Laragon menu > PHP > Extensions > pdo_pgsql, then restart Apache.');

if (end($checks)['ok']) {
    try {
        $conn = (new Database())->connect();
        $add('Connected to PostgreSQL and database todatrack_db', true);
    } catch (RuntimeException $e) {
        $msg = $e->getMessage();
        $hint = 'Common causes: PostgreSQL not started in Laragon; wrong port; database todatrack_db not created yet.';
        if (stripos($msg, 'no password supplied') !== false || stripos($msg, 'password authentication failed') !== false) {
            $hint = 'Open config/config.php, replace PUT_TODA_USER_PASSWORD_HERE with the password you gave the toda_user role '
                  . 'in pgAdmin, make sure the user line says toda_user, save the file, and reload this page.';
        } elseif (stripos($msg, 'role') !== false && stripos($msg, 'does not exist') !== false) {
            $hint = 'The role toda_user does not exist yet. Create it first (database/0_create_role_pgsql.sql, or Login/Group Roles in pgAdmin).';
        } elseif (stripos($msg, 'database') !== false && stripos($msg, 'does not exist') !== false) {
            $hint = 'The database todatrack_db does not exist yet. In pgAdmin run: CREATE DATABASE todatrack_db;';
        }
        $add('Connected to PostgreSQL and database todatrack_db', false, $hint . ' (Details: ' . $msg . ')');
    }
}

if ($conn) {
    foreach (['users', 'admins', 'passengers', 'zones', 'locations', 'fare_rates', 'drivers', 'tricycles', 'help_requests', 'driver_ratings'] as $table) {
        try {
            $conn->query("SELECT 1 FROM {$table} LIMIT 1");
            $add("Table {$table} exists", true);
        } catch (PDOException $e) {
            $denied = stripos($e->getMessage(), 'permission denied') !== false;
            $hint = 'Run database/1_schema_pgsql.sql in the Query Tool of todatrack_db (as postgres).';
            if ($table === 'help_requests') {
                $hint = 'Run database/4_add_help_requests_pgsql.sql once in the Query Tool of todatrack_db (as postgres).';
            } elseif ($table === 'admins' || $table === 'passengers') {
                $hint = 'Run database/11_create_passenger_admin_profiles_pgsql.sql in the Query Tool of todatrack_db (as postgres).';
            } elseif ($table === 'driver_ratings') {
                $hint = 'Run database/5_add_passenger_features_pgsql.sql once in the Query Tool of todatrack_db (as postgres).';
            }
            if ($denied) {
                $hint = 'toda_user has no permission yet. Run database/3_grant_privileges_pgsql.sql in the Query Tool of todatrack_db (as postgres).';
            }
            $add("Table {$table} exists", false, $hint);
        }
    }
    try {
        $conn->query('SELECT is_anonymous FROM driver_ratings LIMIT 0');
        $add('Anonymous rating support is installed', true);
    } catch (PDOException $e) {
        $add('Anonymous rating support is installed', false,
             'Run database/8_add_anonymous_ratings_pgsql.sql in the Query Tool of todatrack_db (as postgres).');
    }
    try {
        $n = (int)$conn->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
        $add('An admin account exists', $n > 0, 'Run the INSERT INTO users ... admin part of 1_schema_pgsql.sql.');
    } catch (PDOException $e) {
        $add('An admin account exists', false, 'Create the tables first.');
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>TodaTrack connection check</title>
<link rel="stylesheet" href="assets/vendor/bootstrap/bootstrap.min.css"></head>
<body class="bg-light"><main class="container py-4" style="max-width: 760px;">
<h1 class="h4 mb-3">TodaTrack connection check</h1>
<ul class="list-group">
<?php foreach ($checks as $c): ?>
    <li class="list-group-item">
        <span class="badge text-bg-<?= $c['ok'] ? 'success' : 'danger' ?> me-2"><?= $c['ok'] ? 'OK' : 'FIX' ?></span><?= e($c['label']) ?>
        <?php if (!$c['ok'] && $c['hint']): ?><div class="small text-danger mt-1"><?= e($c['hint']) ?></div><?php endif; ?>
    </li>
<?php endforeach; ?>
</ul>
<p class="small text-muted mt-3">Settings are in config/config.php. When everything says OK, open <a href="index.php">the app</a>.</p>
</main></body></html>
