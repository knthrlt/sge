-- ============================================================
-- Move the zone colors to the official TodaTrack palette
-- (Love the Philippines). Run once as the postgres user on todatrack_db.
-- Safe to run twice. You can also change any color on the admin Zones page.
-- ============================================================
UPDATE zones SET color_hex = '#D23A36' WHERE zone_name = 'City Proper';     -- Festival Red
UPDATE zones SET color_hex = '#489BDE' WHERE zone_name = 'Crossing Vito';   -- Sky Blue
UPDATE zones SET color_hex = '#59AE68' WHERE zone_name = 'Paraiso';         -- Leaf Green
UPDATE zones SET color_hex = '#F0CD4F' WHERE zone_name = 'Old Sagay';       -- Marigold Yellow
UPDATE zones SET color_hex = '#30398A' WHERE zone_name = 'Bato';            -- Indigo
