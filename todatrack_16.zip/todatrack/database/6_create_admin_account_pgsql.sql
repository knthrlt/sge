-- ============================================================
-- CREATE A NEW ADMIN ACCOUNT (done in the database on purpose:
-- the Register page can only create passenger and driver accounts)
--
-- Run in pgAdmin: right-click todatrack_db > Query Tool, as postgres.
-- 1. Change the five values in the "VALUES" line below:
--      full name, username, email, and the PASSWORD (inside crypt('...')).
-- 2. Run it (F5). Then log in on the website with that username and password.
--
-- The password is stored as a bcrypt hash made by PostgreSQL's pgcrypto,
-- and the PHP login (password_verify) accepts it.
-- Use a strong password: 8+ characters with upper and lower case letters,
-- a number, and a symbol. Do not reuse the sample one.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

INSERT INTO users (full_name, username, email, password_hash, role, consented_at)
VALUES (
  'Maria Admin',                                  -- full name
  'maria_admin',                                  -- username (5-20 letters, numbers, underscore)
  'maria.admin@example.com',                      -- email
  crypt('Change-This-Pass#2026', gen_salt('bf', 10)),   -- PASSWORD: replace the text between the quotes
  'admin',
  CURRENT_TIMESTAMP
);

INSERT INTO admins (user_id)
SELECT user_id FROM users WHERE username = 'maria_admin'
ON CONFLICT (user_id) DO NOTHING;

-- Check that it worked:
-- SELECT user_id, username, email, role FROM users WHERE role = 'admin';

-- To remove an admin you no longer need:
-- DELETE FROM users WHERE username = 'maria_admin';

-- To change an admin's password later:
-- UPDATE users SET password_hash = crypt('New-Password#2026', gen_salt('bf', 10)) WHERE username = 'maria_admin';
