-- ============================================================
-- TodaTrack: Tricycle Zone Monitoring System  (PostgreSQL / pgAdmin)
--
-- STEP 1 (run alone, while connected to the default "postgres" database):
--     CREATE DATABASE todatrack_db;
--
-- STEP 2: right-click todatrack_db > Query Tool, then run everything
--         below this line (F5).
-- Safe to re-run: it drops and recreates the tables.
-- ============================================================

DROP TABLE IF EXISTS driver_ratings CASCADE;
DROP TABLE IF EXISTS favorite_drivers CASCADE;
DROP TABLE IF EXISTS saved_places CASCADE;
DROP TABLE IF EXISTS help_requests CASCADE;
DROP TABLE IF EXISTS tricycles  CASCADE;
DROP TABLE IF EXISTS fare_rates CASCADE;
DROP TABLE IF EXISTS drivers    CASCADE;
DROP TABLE IF EXISTS locations  CASCADE;
DROP TABLE IF EXISTS zones      CASCADE;
DROP TABLE IF EXISTS admins     CASCADE;
DROP TABLE IF EXISTS passengers CASCADE;
DROP TABLE IF EXISTS users      CASCADE;
DROP FUNCTION IF EXISTS set_updated_at() CASCADE;

-- Login accounts. role is admin, driver, or passenger.
CREATE TABLE users (
  user_id       INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  username      VARCHAR(30)  NOT NULL UNIQUE,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          VARCHAR(10)  NOT NULL DEFAULT 'passenger' CHECK (role IN ('admin','driver','passenger')),
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  consented_at  TIMESTAMP    NULL, -- when the user agreed to the Data Privacy Notice
  is_active     BOOLEAN      NOT NULL DEFAULT TRUE  -- FALSE = deactivated by the admin (cannot log in)
);

-- Role-specific account profiles. Login credentials and shared fields stay in users.
CREATE TABLE passengers (
  passenger_id  INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id       INTEGER NOT NULL UNIQUE REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
  discount_type VARCHAR(10) NULL CHECK (discount_type IN ('student','senior','pwd')),
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admins (
  admin_id   INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id    INTEGER NOT NULL UNIQUE REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Zones = origin terminals in the fare matrix. Each has a color.
CREATE TABLE zones (
  zone_id    INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  zone_name  VARCHAR(50) NOT NULL UNIQUE,
  color_name VARCHAR(30) NOT NULL,
  color_hex  CHAR(7)     NOT NULL CHECK (color_hex ~ '^#[0-9A-Fa-f]{6}$')
);

-- Places a tricycle can be at / a passenger can travel to.
CREATE TABLE locations (
  location_id   INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  location_name VARCHAR(80) NOT NULL UNIQUE
);

-- Fare guide: regular fare from an origin zone to a destination.
-- The student/senior/PWD fare is computed (20% off), so it is not stored.
CREATE TABLE fare_rates (
  fare_id     INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  zone_id     INTEGER NOT NULL REFERENCES zones (zone_id)         ON UPDATE CASCADE ON DELETE RESTRICT,
  location_id INTEGER NOT NULL REFERENCES locations (location_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  fare        NUMERIC(6,2) NOT NULL CHECK (fare > 0),
  CONSTRAINT uq_fare_route UNIQUE (zone_id, location_id)
);

-- Drivers. user_id links a driver to a login account (optional).
CREATE TABLE drivers (
  driver_id  INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id    INTEGER NULL UNIQUE REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE SET NULL,
  full_name  VARCHAR(100) NOT NULL,
  contact_no VARCHAR(13)  NOT NULL,
  license_no VARCHAR(20)  NOT NULL UNIQUE
);

-- Tricycle units (main CRUD module).
CREATE TABLE tricycles (
  tricycle_id  INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  body_number  VARCHAR(10) NOT NULL UNIQUE,
  plate_number VARCHAR(10) NOT NULL UNIQUE,
  driver_id    INTEGER NOT NULL UNIQUE REFERENCES drivers (driver_id)     ON UPDATE CASCADE ON DELETE RESTRICT,
  zone_id      INTEGER NOT NULL REFERENCES zones (zone_id)                ON UPDATE CASCADE ON DELETE RESTRICT,
  location_id  INTEGER NOT NULL REFERENCES locations (location_id)        ON UPDATE CASCADE ON DELETE RESTRICT,
  status       VARCHAR(10) NOT NULL DEFAULT 'available' CHECK (status IN ('available','on_trip','off_duty')),
  updated_at   TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Help requests: a driver reports a problem (flat tire, engine trouble, ...).
-- Only one open request per tricycle at a time (see the partial unique index).
CREATE TABLE help_requests (
  request_id   INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tricycle_id  INTEGER NOT NULL REFERENCES tricycles (tricycle_id)  ON UPDATE CASCADE ON DELETE CASCADE,
  location_id  INTEGER NOT NULL REFERENCES locations (location_id)  ON UPDATE CASCADE ON DELETE RESTRICT,
  problem      VARCHAR(20)  NOT NULL CHECK (problem IN ('flat_tire','engine','out_of_fuel','accident','other')),
  note         VARCHAR(255) NULL,
  status       VARCHAR(10)  NOT NULL DEFAULT 'open' CHECK (status IN ('open','on_the_way','resolved','cancelled')),
  created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX uq_help_one_active ON help_requests (tricycle_id) WHERE status IN ('open','on_the_way');

-- Saved destinations of a passenger ("Home", "School", ...).
CREATE TABLE saved_places (
  saved_id    INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users (user_id)         ON UPDATE CASCADE ON DELETE CASCADE,
  location_id INTEGER NOT NULL REFERENCES locations (location_id) ON UPDATE CASCADE ON DELETE CASCADE,
  label       VARCHAR(30) NULL,
  created_at  TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_saved_place UNIQUE (user_id, location_id)
);

-- Drivers a passenger marked as favorite (many-to-many).
CREATE TABLE favorite_drivers (
  user_id    INTEGER   NOT NULL REFERENCES users (user_id)     ON UPDATE CASCADE ON DELETE CASCADE,
  driver_id  INTEGER   NOT NULL REFERENCES drivers (driver_id) ON UPDATE CASCADE ON DELETE CASCADE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, driver_id)
);

-- A passenger's rating of a driver (one per passenger and driver; the admin can hide it).
CREATE TABLE driver_ratings (
  rating_id  INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users (user_id)     ON UPDATE CASCADE ON DELETE CASCADE,
  driver_id  INTEGER NOT NULL REFERENCES drivers (driver_id) ON UPDATE CASCADE ON DELETE CASCADE,
  stars      SMALLINT NOT NULL CHECK (stars BETWEEN 1 AND 5),
  comment    VARCHAR(255) NULL,
  is_anonymous BOOLEAN NOT NULL DEFAULT FALSE,
  status     VARCHAR(10) NOT NULL DEFAULT 'visible' CHECK (status IN ('visible','hidden')),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_rating_once UNIQUE (user_id, driver_id)
);

-- Keep tricycles.updated_at current on every UPDATE (MySQL does this automatically).
CREATE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at := CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tricycles_updated_at
BEFORE UPDATE ON tricycles
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ------------------------------------------------------------
-- Admin account (the only seeded account).
-- Password: Admin@2026  (stored as a bcrypt hash made with PHP password_hash)
-- Passengers and drivers create their own accounts on the Register page.
-- Zones, locations, fares, and tricycles are added by the admin inside the
-- app (Manage menu, Fare Guide, Tricycles), or with INSERT queries.
-- ------------------------------------------------------------
INSERT INTO users (full_name, username, email, password_hash, role) VALUES
  ('TODA Administrator', 'admin', 'admin@todatrack.local', '$2y$10$.nepPy5B.4frqQhvsfgDcOoafLGaiNzJJI3W0pziLv3pitDbUOtuS', 'admin');

INSERT INTO admins (user_id)
SELECT user_id FROM users WHERE username = 'admin';
