-- ============================================================
-- STEP 0 (run once, in a Query Tool on the "postgres" database, as postgres)
-- Creates the login role the app uses. Change the password first!
-- (Or create it in pgAdmin: Login/Group Roles > Create > Login/Group Role.)
-- ============================================================
CREATE ROLE toda_user WITH LOGIN PASSWORD 'CHANGE_THIS_PASSWORD'
  NOSUPERUSER NOCREATEDB NOCREATEROLE;
