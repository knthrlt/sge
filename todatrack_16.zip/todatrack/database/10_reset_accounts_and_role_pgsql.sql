-- DESTRUCTIVE, ONE-TIME migration for existing TodaTrack databases.
-- Run as postgres on todatrack_db after the other required migrations.
-- Deletes every tricycle, driver profile, and non-admin account. Related
-- help requests, ratings, favorites, and saved places are deleted by FK cascades.
-- The admin account is retained. New accounts use admin/driver/passenger roles.

BEGIN;

DELETE FROM tricycles;
DELETE FROM drivers;
DELETE FROM users WHERE role <> 'admin';

ALTER TABLE users ALTER COLUMN role DROP DEFAULT;
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check;
ALTER TABLE users
  ADD CONSTRAINT users_role_check CHECK (role IN ('admin', 'driver', 'passenger'));
ALTER TABLE users ALTER COLUMN role SET DEFAULT 'passenger';

-- Restart emptied identity sequences at 1; preserve the next valid user_id
-- after the retained admin account rather than renumbering existing records.
SELECT setval(pg_get_serial_sequence('users', 'user_id'),
              COALESCE(MAX(user_id), 1), COUNT(*) > 0)
  FROM users;
SELECT setval(pg_get_serial_sequence('drivers', 'driver_id'),
              COALESCE(MAX(driver_id), 1), COUNT(*) > 0)
  FROM drivers;
SELECT setval(pg_get_serial_sequence('tricycles', 'tricycle_id'),
              COALESCE(MAX(tricycle_id), 1), COUNT(*) > 0)
  FROM tricycles;

COMMIT;
