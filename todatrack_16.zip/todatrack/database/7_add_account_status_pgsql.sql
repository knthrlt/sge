-- TodaTrack: account status (deactivate / reactivate accounts).
-- Run ONCE as postgres on todatrack_db (safe to run twice).
-- A deactivated user cannot log in; their tricycle is hidden from passengers.
-- Nothing is deleted, so ratings and history are kept and the account can be reactivated.
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE;
