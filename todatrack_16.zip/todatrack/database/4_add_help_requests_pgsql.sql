-- ============================================================
-- OPTIONAL MIGRATION (only if you already ran an older 1_schema_pgsql.sql)
-- Run ONCE in the Query Tool of todatrack_db, as postgres.
-- Adds the help_requests table used by the drivers' "Request Help" feature
-- and gives toda_user access to it. Do not run it on a fresh database
-- that used the new 1_schema_pgsql.sql: that file already has this table.
-- ============================================================
-- Help requests: a driver reports a problem (flat tire, engine trouble, ...).
-- Only one open request per tricycle at a time (see the partial unique index).
CREATE TABLE IF NOT EXISTS help_requests (
  request_id   INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tricycle_id  INTEGER NOT NULL REFERENCES tricycles (tricycle_id)  ON UPDATE CASCADE ON DELETE CASCADE,
  location_id  INTEGER NOT NULL REFERENCES locations (location_id)  ON UPDATE CASCADE ON DELETE RESTRICT,
  problem      VARCHAR(20)  NOT NULL CHECK (problem IN ('flat_tire','engine','out_of_fuel','accident','other')),
  note         VARCHAR(255) NULL,
  status       VARCHAR(10)  NOT NULL DEFAULT 'open' CHECK (status IN ('open','on_the_way','resolved','cancelled')),
  created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_help_one_active ON help_requests (tricycle_id) WHERE status IN ('open','on_the_way');

GRANT SELECT, INSERT, UPDATE, DELETE ON help_requests TO toda_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO toda_user;
