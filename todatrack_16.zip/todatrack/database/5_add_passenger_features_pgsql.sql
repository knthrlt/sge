-- ============================================================
-- OPTIONAL MIGRATION (only if you already ran an older 1_schema_pgsql.sql)
-- Run ONCE in the Query Tool of todatrack_db, as postgres.
-- Adds what the passenger features need: the discount type on users,
-- saved destinations, favorite drivers, and driver ratings. Also makes sure
-- the consent column exists, and gives toda_user access.
-- Safe to run twice. Do not run it on a fresh database that used the new
-- 1_schema_pgsql.sql: that file already has all of this.
-- ============================================================
ALTER TABLE users ADD COLUMN IF NOT EXISTS consented_at  TIMESTAMP NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS discount_type VARCHAR(10) NULL CHECK (discount_type IN ('student','senior','pwd'));

-- Saved destinations of a passenger ("Home", "School", ...).
CREATE TABLE IF NOT EXISTS saved_places (
  saved_id    INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users (user_id)         ON UPDATE CASCADE ON DELETE CASCADE,
  location_id INTEGER NOT NULL REFERENCES locations (location_id) ON UPDATE CASCADE ON DELETE CASCADE,
  label       VARCHAR(30) NULL,
  created_at  TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_saved_place UNIQUE (user_id, location_id)
);

-- Drivers a passenger marked as favorite (many-to-many).
CREATE TABLE IF NOT EXISTS favorite_drivers (
  user_id    INTEGER   NOT NULL REFERENCES users (user_id)     ON UPDATE CASCADE ON DELETE CASCADE,
  driver_id  INTEGER   NOT NULL REFERENCES drivers (driver_id) ON UPDATE CASCADE ON DELETE CASCADE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, driver_id)
);

-- A passenger's rating of a driver (one per passenger and driver; the admin can hide it).
CREATE TABLE IF NOT EXISTS driver_ratings (
  rating_id  INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users (user_id)     ON UPDATE CASCADE ON DELETE CASCADE,
  driver_id  INTEGER NOT NULL REFERENCES drivers (driver_id) ON UPDATE CASCADE ON DELETE CASCADE,
  stars      SMALLINT NOT NULL CHECK (stars BETWEEN 1 AND 5),
  comment    VARCHAR(255) NULL,
  is_anonymous BOOLEAN NOT NULL DEFAULT FALSE,
  status     VARCHAR(10) NOT NULL DEFAULT 'visible' CHECK (status IN ('visible','hidden')),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_rating_once UNIQUE (user_id, driver_id)
);

ALTER TABLE driver_ratings ADD COLUMN IF NOT EXISTS is_anonymous BOOLEAN NOT NULL DEFAULT FALSE;

GRANT SELECT, INSERT, UPDATE, DELETE ON saved_places, favorite_drivers, driver_ratings TO toda_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO toda_user;
