-- ============================================================
-- OPTIONAL reference data: 5 zones (with colors), 36 locations, 39 fares.
-- Typed from the provided fare screenshots - compare with the original.
-- Skip this file if you want to enter them yourself as admin in the app.
-- Run it ONCE (running twice gives "already exists" errors).
-- ============================================================

INSERT INTO zones (zone_name, color_name, color_hex) VALUES
  ('City Proper', 'Red', '#D23A36'),
  ('Crossing Vito', 'Blue', '#489BDE'),
  ('Paraiso', 'Green', '#59AE68'),
  ('Old Sagay', 'Yellow', '#F0CD4F'),
  ('Bato', 'Purple', '#30398A');

INSERT INTO locations (location_name) VALUES
  ('Tanke'),
  ('Tan-ao'),
  ('Palenas/City Hall'),
  ('Municipal Cemetery'),
  ('Sarromar'),
  ('Aguilar Subdivision'),
  ('Charmaine Village'),
  ('Yungho'),
  ('Tagnipis'),
  ('Hupac'),
  ('Intaplan'),
  ('Ricky'),
  ('San Agustin'),
  ('Brgy. Bulanon - Barangay Proper'),
  ('Brgy. Bulanon - Talusan'),
  ('Brgy. Bulanon - Dungca-an'),
  ('Brgy. General Luna'),
  ('Brgy. Lopez Jaena'),
  ('Brgy. Old Sagay'),
  ('Brgy. Plaridel'),
  ('Brgy. Rizal'),
  ('Brgy. Taba-ao'),
  ('Brgy. Andres Bonifacio'),
  ('Brgy. Vito'),
  ('Brgy. Rafaela Barrera'),
  ('Brgy. Bato'),
  ('Brgy. Paraiso/Fabrica'),
  ('Vito Port'),
  ('Brgy. Fabrica'),
  ('Brgy. Malubon'),
  ('Brgy. Tadlong'),
  ('Central Lopez'),
  ('Garganira'),
  ('Sitio Bago'),
  ('Brgy. Maquiling'),
  ('Brgy. Cpo. Hinogaan');

INSERT INTO fare_rates (zone_id, location_id, fare)
SELECT z.zone_id, l.location_id, v.fare FROM (VALUES
  ('City Proper', 'Tanke', 15.00),
  ('City Proper', 'Tan-ao', 15.00),
  ('City Proper', 'Palenas/City Hall', 15.00),
  ('City Proper', 'Municipal Cemetery', 15.00),
  ('City Proper', 'Sarromar', 15.00),
  ('City Proper', 'Aguilar Subdivision', 15.00),
  ('City Proper', 'Charmaine Village', 15.00),
  ('City Proper', 'Yungho', 15.00),
  ('City Proper', 'Tagnipis', 23.00),
  ('City Proper', 'Hupac', 19.00),
  ('City Proper', 'Intaplan', 21.00),
  ('City Proper', 'Ricky', 17.00),
  ('City Proper', 'San Agustin', 25.00),
  ('City Proper', 'Brgy. Bulanon - Barangay Proper', 30.00),
  ('City Proper', 'Brgy. Bulanon - Talusan', 35.00),
  ('City Proper', 'Brgy. Bulanon - Dungca-an', 40.00),
  ('City Proper', 'Brgy. General Luna', 20.00),
  ('City Proper', 'Brgy. Lopez Jaena', 23.00),
  ('City Proper', 'Brgy. Old Sagay', 20.00),
  ('City Proper', 'Brgy. Plaridel', 31.00),
  ('City Proper', 'Brgy. Rizal', 17.00),
  ('City Proper', 'Brgy. Taba-ao', 25.00),
  ('City Proper', 'Brgy. Andres Bonifacio', 35.00),
  ('City Proper', 'Brgy. Vito', 25.00),
  ('City Proper', 'Brgy. Rafaela Barrera', 21.00),
  ('City Proper', 'Brgy. Bato', 29.00),
  ('City Proper', 'Brgy. Paraiso/Fabrica', 25.00),
  ('Crossing Vito', 'Vito Port', 23.00),
  ('Crossing Vito', 'Brgy. Andres Bonifacio', 15.00),
  ('Paraiso', 'Brgy. Fabrica', 15.00),
  ('Paraiso', 'Brgy. Malubon', 17.00),
  ('Paraiso', 'Brgy. Tadlong', 15.00),
  ('Paraiso', 'Central Lopez', 15.00),
  ('Paraiso', 'San Agustin', 19.00),
  ('Paraiso', 'Garganira', 33.00),
  ('Old Sagay', 'Brgy. Taba-ao', 15.00),
  ('Bato', 'Sitio Bago', 25.00),
  ('Bato', 'Brgy. Maquiling', 17.00),
  ('Bato', 'Brgy. Cpo. Hinogaan', 17.00)
) AS v(zn, ln, fare)
JOIN zones z ON z.zone_name = v.zn
JOIN locations l ON l.location_name = v.ln;

-- ============================================================
-- 39 Driver Registration Credentials (Original Order)
-- ============================================================
-- ------------------------------------------------------------
-- ADMIN ACCOUNT
-- Full name: TODA Administrator
-- Username: admin
-- Email: admin@tidatrack.local
-- Password: Admin@2026
-- Confirm password: Admin@x2026
-- ------------------------------------------------------------
-- PASSENGER ACCOUNT
-- Full name: John Kenth Bornea
-- Username: Johnkenth_
-- Email: johnkenth@email.com
-- Password: John@2026
-- Confirm password: John@2026
-- ------------------------------------------------------------
-- DRIVER ACCOUNTS
-- ------------------------------------------------------------
-- 1. City Proper — Tanke
-- Full name: Marco Santos
-- Username: Marco_
-- Email: marcosantos@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09180150192
-- License number: N06-25-000001
-- ------------------------------------------------------------
-- 2. City Proper — Tan-ao
-- Full name: Lito Reyes
-- Username: Lito_
-- Email: litoreyes@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09180250192
-- License number: N06-25-000002
-- ------------------------------------------------------------
-- 3. City Proper — Palenas
-- Full name: Ramon Cruz
-- Username: Ramon_
-- Email: ramoncruz@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09180350192
-- License number: N06-25-000003
-- ------------------------------------------------------------
-- 4. City Proper — Municipal Cemetery
-- Full name: Jun Bautista
-- Username: Jun_
-- Email: junbautista@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09180450192
-- License number: N06-25-000004
-- ------------------------------------------------------------
-- 5. City Proper — Sarromar
-- Full name: Dodong Mendoza
-- Username: Dodong_
-- Email: dodongmendoza@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09180550192
-- License number: N06-25-000005
-- ------------------------------------------------------------
-- 6. City Proper — Aguilar Subdivision
-- Full name: Boy Flores
-- Username: Boy_
-- Email: boyflores@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09180650192
-- License number: N06-25-000006
-- ------------------------------------------------------------
-- 7. City Proper — Charmaine Village
-- Full name: Nino Gonzales
-- Username: Nino_
-- Email: ninogonzales@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09180750192
-- License number: N06-25-000007
-- ------------------------------------------------------------
-- 8. City Proper — Yungho
-- Full name: Carlo Garcia
-- Username: Carlo_
-- Email: carlogarcia@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09180850192
-- License number: N06-25-000008
-- ------------------------------------------------------------
-- 9. City Proper — Tagnipis
-- Full name: Allan Lopez
-- Username: Allan_
-- Email: allanlopez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09180950192
-- License number: N06-25-000009
-- ------------------------------------------------------------
-- 10. City Proper — Hupac
-- Full name: Rodel Ramos
-- Username: Rodel_
-- Email: rodelramos@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181050192
-- License number: N06-25-000010
-- ------------------------------------------------------------
-- 11. City Proper — Intaplan
-- Full name: Elmer Aquino
-- Username: Elmer_
-- Email: elmeraquino@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181150192
-- License number: N06-25-000011
-- ------------------------------------------------------------
-- 12. City Proper — Ricky
-- Full name: Jhun Castro
-- Username: Jhun_
-- Email: jhuncastro@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181250192
-- License number: N06-25-000012
-- ------------------------------------------------------------
-- 13. City Proper — San Agustin
-- Full name: Arnel Rivera
-- Username: Arnel_
-- Email: arnelrivera@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181350192
-- License number: N06-25-000013
-- ------------------------------------------------------------
-- 14. City Proper — Barangay Proper Bulanon
-- Full name: Renato Gomez
-- Username: Renato_
-- Email: renatogomez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181450192
-- License number: N06-25-000014
-- ------------------------------------------------------------
-- 15. City Proper — Talusan Bulanon
-- Full name: Danilo Navarro
-- Username: Danilo_
-- Email: danilonavarro@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181550192
-- License number: N06-25-000015
-- ------------------------------------------------------------
-- 16. City Proper — Dungca-an Bulanon
-- Full name: Rey Torres
-- Username: Rey_
-- Email: reytorres@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181650192
-- License number: N06-25-000016
-- ------------------------------------------------------------
-- 17. City Proper — General Luna
-- Full name: Joel Dominguez
-- Username: Joel_
-- Email: joeldominguez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181750192
-- License number: N06-25-000017
-- ------------------------------------------------------------
-- 18. City Proper — Lopez Jaena
-- Full name: Benny Castillo
-- Username: Benny_
-- Email: bennycastillo@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181850192
-- License number: N06-25-000018
-- ------------------------------------------------------------
-- 19. City Proper — Old Sagay
-- Full name: Cris Morales
-- Username: Cris_
-- Email: crismorales@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09181950192
-- License number: N06-25-000019
-- ------------------------------------------------------------
-- 20. City Proper — Plaridel
-- Full name: Dante Alvarez
-- Username: Dante_
-- Email: dantealvarez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182050192
-- License number: N06-25-000020
-- ------------------------------------------------------------
-- 21. City Proper — Rizal
-- Full name: Gerry Diaz
-- Username: Gerry_
-- Email: gerrydiaz@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182150192
-- License number: N06-25-000021
-- ------------------------------------------------------------
-- 22. City Proper — Taba-ao
-- Full name: Leo Fernandez
-- Username: Leo_
-- Email: leofernandez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182250192
-- License number: N06-25-000022
-- ------------------------------------------------------------
-- 23. City Proper — Andres Bonifacio
-- Full name: Mario Guzman
-- Username: Mario_
-- Email: marioguzman@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182350192
-- License number: N06-25-000023
-- ------------------------------------------------------------
-- 24. City Proper — Vito
-- Full name: Noel Jimenez
-- Username: Noel_
-- Email: noeljimenez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182450192
-- License number: N06-25-000024
-- ------------------------------------------------------------
-- 25. City Proper — Rafaela Barrera
-- Full name: Oscar Luna
-- Username: Oscar_
-- Email: oscarluna@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182550192
-- License number: N06-25-000025
-- ------------------------------------------------------------
-- 26. City Proper — Bato
-- Full name: Paul Martinez
-- Username: Paul_
-- Email: paulmartinez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182650192
-- License number: N06-25-000026
-- ------------------------------------------------------------
-- 27. City Proper — Paraiso
-- Full name: Rolly Nunez
-- Username: Rolly_
-- Email: rollynunez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182750192
-- License number: N06-25-000027
-- ------------------------------------------------------------
-- 28. Crossing Vito — Vito Port
-- Full name: Sonny Ortega
-- Username: Sonny_
-- Email: sonnyortega@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182850192
-- License number: N06-25-000028
-- ------------------------------------------------------------
-- 29. Crossing Vito — Andres Bonifacio
-- Full name: Tito Perez
-- Username: Tito_
-- Email: titoperez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09182950192
-- License number: N06-25-000029
-- ------------------------------------------------------------
-- 30. Paraiso — Fabrica
-- Full name: Vic Ramirez
-- Username: Vic_
-- Email: vicramirez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183050192
-- License number: N06-25-000030
-- ------------------------------------------------------------
-- 31. Paraiso — Malubon
-- Full name: Wilfred Salazar
-- Username: Wilfred_
-- Email: wilfredsalazar@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183150192
-- License number: N06-25-000031
-- ------------------------------------------------------------
-- 32. Paraiso — Tadlong
-- Full name: Zandro Silva
-- Username: Zandro_
-- Email: zandrosilva@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183250192
-- License number: N06-25-000032
-- ------------------------------------------------------------
-- 33. Paraiso — Central Lopez
-- Full name: Bong Soriano
-- Username: Bong_
-- Email: bongsoriano@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183350192
-- License number: N06-25-000033
-- ------------------------------------------------------------
-- 34. Paraiso — San Agustin
-- Full name: Chito Valdez
-- Username: Chito_
-- Email: chitovaldez@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183450192
-- License number: N06-25-000034
-- ------------------------------------------------------------
-- 35. Paraiso — Garganira
-- Full name: Erwin Vargas
-- Username: Erwin_
-- Email: erwinvargas@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183550192
-- License number: N06-25-000035
-- ------------------------------------------------------------
-- 36. Old Sagay — Taba-ao
-- Full name: Fred Villanueva
-- Username: Fred_
-- Email: fredvillanueva@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183650192
-- License number: N06-25-000036
-- ------------------------------------------------------------
-- 37. Bato — Sitio Bago
-- Full name: Gil Cabrera
-- Username: Gil_
-- Email: gilcabrera@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183750192
-- License number: N06-25-000037
-- ------------------------------------------------------------
-- 38. Bato — Maquiling
-- Full name: Henry Delgado
-- Username: Henry_
-- Email: henrydelgado@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183850192
-- License number: N06-25-000038
-- ------------------------------------------------------------
-- 39. Bato — Hinogaan
-- Full name: Ivan Espinoza
-- Username: Ivan_
-- Email: ivanespinoza@gmail.com
-- Password: Toda@2026
-- Confirm password: Toda@2026
-- Contact number: 09183950192
-- License number: N06-25-000039
-- ------------------------------------------------------------