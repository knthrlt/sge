-- Add anonymous rating support to an existing TodaTrack database.
-- Run as postgres on todatrack_db. Safe to run more than once.
ALTER TABLE driver_ratings
  ADD COLUMN IF NOT EXISTS is_anonymous BOOLEAN NOT NULL DEFAULT FALSE;

GRANT SELECT, INSERT, UPDATE, DELETE ON driver_ratings TO toda_user;
