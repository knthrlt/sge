-- ============================================================
-- STEP 3 (run in a Query Tool on "todatrack_db", as postgres)
-- Run AFTER 1_schema_pgsql.sql. Lets toda_user read and write the app's
-- tables (but not drop or alter them). Safe to run again.
-- ============================================================
GRANT CONNECT ON DATABASE todatrack_db TO toda_user;
GRANT USAGE ON SCHEMA public TO toda_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO toda_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO toda_user;

-- Keep the permissions if the tables are recreated later.
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO toda_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO toda_user;
