-- Add role-specific profiles to an existing database.
-- Run as postgres after database/10_reset_accounts_and_role_pgsql.sql.
-- Migration 5 must have added users.discount_type before running this file.

BEGIN;

CREATE TABLE IF NOT EXISTS passengers (
  passenger_id  INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id       INTEGER NOT NULL UNIQUE REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
  discount_type VARCHAR(10) NULL CHECK (discount_type IN ('student','senior','pwd')),
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admins (
  admin_id   INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id    INTEGER NOT NULL UNIQUE REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO passengers (user_id, discount_type)
SELECT user_id, discount_type
  FROM users
 WHERE role = 'passenger'
ON CONFLICT (user_id) DO NOTHING;

INSERT INTO admins (user_id)
SELECT user_id
  FROM users
 WHERE role = 'admin'
ON CONFLICT (user_id) DO NOTHING;

-- Keep profile IDs unique; empty profile tables start their next ID at 1.
SELECT setval(pg_get_serial_sequence('passengers', 'passenger_id'),
              COALESCE(MAX(passenger_id), 1), COUNT(*) > 0)
  FROM passengers;
SELECT setval(pg_get_serial_sequence('admins', 'admin_id'),
              COALESCE(MAX(admin_id), 1), COUNT(*) > 0)
  FROM admins;

ALTER TABLE users DROP COLUMN IF EXISTS discount_type;

GRANT SELECT, INSERT, UPDATE, DELETE ON passengers, admins TO toda_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO toda_user;

COMMIT;
