/*
 * TodaTrack front-end:
 *  1. Client-side (JavaScript) validation for every form with data-validate
 *  2. Bootstrap confirmation modal for forms with data-confirm (save/update/delete)
 *  3. DataTables search + filter dropdowns
 *  4. Small helpers (passenger/driver fields, password checklist, privacy notice, add/edit modals)
 */
(function () {
    'use strict';

    /* ---------- 1. Validation ---------- */
    var RESERVED = ['admin', 'administrator', 'root', 'system', 'superuser', 'support', 'todatrack', 'toda'];
    var WEAK = ['password', 'qwerty', '12345678', 'abcdefgh', 'admin123', 'letmein', 'iloveyou'];

    // true = the rule is satisfied
    function passwordRules(pw, username) {
        var lower = pw.toLowerCase();
        var user = (username || '').trim().toLowerCase();
        return {
            length:   pw.length >= 8 && pw.length <= 64,
            upper:    /[A-Z]/.test(pw),
            lower:    /[a-z]/.test(pw),
            number:   /\d/.test(pw),
            special:  /[^A-Za-z0-9\s]/.test(pw),
            space:    !/\s/.test(pw),
            username: !(user.length >= 4 && lower.indexOf(user) !== -1),
            common:   !WEAK.some(function (w) { return lower.indexOf(w) !== -1; })
        };
    }

    function validateForm(form) {
        // Password confirmation must match the field named in data-match.
        form.querySelectorAll('[data-match]').forEach(function (field) {
            var other = form.querySelector('#' + field.getAttribute('data-match'));
            field.setCustomValidity(other && field.value !== other.value ? 'Passwords do not match.' : '');
        });

        // Username: reserved names are not allowed (same list as the PHP rule).
        var un = form.querySelector('input[data-username]');
        if (un) {
            un.setCustomValidity(RESERVED.indexOf(un.value.trim().toLowerCase()) !== -1 ? 'That username is reserved.' : '');
        }

        // Strong password (same rules as the PHP rule).
        var pw = form.querySelector('input[data-strong]');
        if (pw) {
            var res = passwordRules(pw.value, un ? un.value : '');
            var all = Object.keys(res).every(function (k) { return res[k]; });
            pw.setCustomValidity(all ? '' : 'Password does not meet all requirements.');
        }

        // Passenger / Driver choice: driver fields are required only for drivers.
        var isDriver = form.querySelector('#type_driver');
        ['contact_no', 'license_no'].forEach(function (name) {
            var f = form.querySelector('[name="' + name + '"]');
            if (f) { f.required = !!(isDriver && isDriver.checked); }
        });
        var typeError = form.querySelector('#typeError');
        if (typeError) {
            typeError.classList.toggle('d-none', !!form.querySelector('input[name="account_type"]:checked'));
        }
        // Star rating: one of the five stars must be chosen.
        var starError = form.querySelector('#starError');
        if (starError) {
            starError.classList.toggle('d-none', !!form.querySelector('input[name="stars"]:checked'));
        }

        form.classList.add('was-validated');
        return form.checkValidity();
    }

    /* ---------- 2. Confirmation modal ---------- */
    var confirmEl = document.getElementById('confirmModal');
    var confirmModal = confirmEl ? new bootstrap.Modal(confirmEl) : null;
    var pendingForm = null;
    var parentModal = null;
    var confirmed = false;

    document.addEventListener('submit', function (ev) {
        var form = ev.target;
        if (!(form instanceof HTMLFormElement)) { return; }

        if (form.hasAttribute('data-validate') && !validateForm(form)) {
            ev.preventDefault();
            ev.stopPropagation();
            var firstBad = form.querySelector(':invalid');
            if (firstBad) { firstBad.focus(); }
            return;
        }

        if (form.getAttribute('data-confirm') && confirmModal && form.dataset.confirmed !== '1') {
            ev.preventDefault();
            pendingForm = form;
            confirmed = false;
            document.getElementById('confirmMessage').textContent = form.getAttribute('data-confirm');
            var yes = document.getElementById('confirmYes');
            var danger = form.getAttribute('data-confirm-style') === 'danger';
            yes.className = 'btn ' + (danger ? 'btn-danger' : 'btn-primary');

            // A form inside another modal: hide that modal first (no stacked modals).
            var parent = form.closest('.modal');
            parentModal = parent ? bootstrap.Modal.getInstance(parent) : null;
            if (parentModal) {
                parent.addEventListener('hidden.bs.modal', function openConfirm() {
                    parent.removeEventListener('hidden.bs.modal', openConfirm);
                    confirmModal.show();
                });
                parentModal.hide();
            } else {
                confirmModal.show();
            }
        }
    }, true);

    if (confirmEl) {
        document.getElementById('confirmYes').addEventListener('click', function () {
            if (!pendingForm) { return; }
            confirmed = true;
            pendingForm.dataset.confirmed = '1';
            confirmModal.hide();
            pendingForm.submit();
        });
        // If the user cancels, return to the form they were in.
        confirmEl.addEventListener('hidden.bs.modal', function () {
            if (!confirmed && parentModal) { parentModal.show(); }
            parentModal = null;
        });
    }

    /* ---------- Greeting by local time (dashboards) ---------- */
    window.addEventListener('DOMContentLoaded', function () {
        var h = new Date().getHours();
        var word = h < 12 ? 'Good morning' : (h < 18 ? 'Good afternoon' : 'Good evening');
        document.querySelectorAll('[data-greeting]').forEach(function (el) { el.textContent = word; });
    });

    /* ---------- 3. DataTables + filters ---------- */
    window.addEventListener('DOMContentLoaded', function () {
        if (!window.jQuery || !jQuery.fn.DataTable) { return; }
        var $ = window.jQuery;

        $('table.table[id$="Table"]').each(function () {
            var table = $(this).DataTable({
                responsive: true,
                pageLength: 10,
                lengthMenu: [10, 25, 50],
                columnDefs: [{ orderable: false, targets: 'no-sort' }],
                language: {
                    search: 'Search:',
                    searchPlaceholder: 'Type to search...',
                    emptyTable: 'No records found.',
                    zeroRecords: 'No matching records found.'
                }
            });

            // Filter dropdowns bound to this table (exact-match on data-search text).
            $('select[data-table="#' + this.id + '"]').on('change', function () {
                var col = parseInt(this.getAttribute('data-col'), 10);
                var val = this.value;
                var regex = val ? '^' + $.fn.dataTable.util.escapeRegex(val) + '$' : '';
                table.column(col).search(regex, true, false).draw();
            });
            // A link such as ?zone=3 pre-selects a filter: apply it on load.
            $('select[data-table="#' + this.id + '"]').each(function () { if (this.value) { $(this).trigger('change'); } });
        });

        /* ---------- 4. Helpers ---------- */
        // Register page: show the driver fields only when "Driver" is chosen.
        var typeRadios = document.querySelectorAll('input[name="account_type"]');
        var driverFields = document.getElementById('driverFields');
        if (typeRadios.length && driverFields) {
            var toggle = function () {
                var driver = document.getElementById('type_driver');
                driverFields.classList.toggle('d-none', !(driver && driver.checked));
                var err = document.getElementById('typeError');
                if (err && document.querySelector('input[name="account_type"]:checked')) { err.classList.add('d-none'); }
            };
            typeRadios.forEach(function (r) { r.addEventListener('change', toggle); });
            toggle();
        }

        // Live password checklist + strength bar (registration page).
        var pwInput = document.querySelector('input[data-strong]');
        var pwList = document.getElementById('pwRules');
        var pwBar = document.getElementById('pwBar');
        if (pwInput && pwList && pwBar) {
            var userInput = document.querySelector('input[data-username]');
            var updateRules = function () {
                var res = passwordRules(pwInput.value, userInput ? userInput.value : '');
                var has = pwInput.value !== '';
                pwList.querySelectorAll('li[data-rule]').forEach(function (li) {
                    li.classList.toggle('ok', has && !!res[li.getAttribute('data-rule')]);
                });
                // Strength: 80% from the five "must have" rules, 20% when no weak pattern is found.
                var must = ['length', 'upper', 'lower', 'number', 'special'];
                var metMust = must.filter(function (k) { return has && res[k]; }).length;
                var clean = has && res.space && res.username && res.common;
                var pct = has ? Math.round((metMust / must.length) * 80) + (clean ? 20 : 0) : 0;
                pwBar.style.width = pct + '%';
                pwBar.className = 'progress-bar ' + (pct < 50 ? 'bg-danger' : pct < 100 ? 'bg-warning' : 'bg-success');
            };
            pwInput.addEventListener('input', updateRules);
            if (userInput) { userInput.addEventListener('input', updateRules); }
            updateRules();
        }

        // Data Privacy Notice (registration): Agree ticks the box, Disagree clears it.
        var agreeBtn = document.getElementById('privacyAgree');
        var disagreeBtn = document.getElementById('privacyDisagree');
        var consentBox = document.getElementById('privacy_consent');
        var privacyEl = document.getElementById('privacyModal');
        if (agreeBtn && disagreeBtn && consentBox && privacyEl) {
            var privacyModal = bootstrap.Modal.getOrCreateInstance(privacyEl);
            agreeBtn.addEventListener('click', function () {
                consentBox.checked = true;
                consentBox.setCustomValidity('');
                privacyModal.hide();
            });
            disagreeBtn.addEventListener('click', function () {
                consentBox.checked = false;
                privacyModal.hide();
                var form = consentBox.closest('form');
                form.classList.add('was-validated');   // shows the "you must agree" message
            });
        }

        // Add/Edit modals (fares, zones, locations): fill the form for Edit, clear it for Add.
        document.querySelectorAll('.crud-modal').forEach(function (modal) {
            modal.addEventListener('show.bs.modal', function (ev) {
                var btn = ev.relatedTarget;
                var form = modal.querySelector('form');
                var isEdit = !!(btn && btn.classList.contains('edit-btn'));
                form.classList.remove('was-validated');
                form.dataset.confirmed = '';
                modal.querySelector('.modal-title').textContent = isEdit ? modal.dataset.titleEdit : modal.dataset.titleAdd;
                form.querySelectorAll('[data-field]').forEach(function (el) {
                    var key = el.getAttribute('data-field');
                    el.value = isEdit ? (btn.dataset[key] || '') : (el.getAttribute('data-default') || '');
                });
            });
        });
    });

    /* ---------- 5. Find a Tricycle: keep "Available now" fresh ---------- */
    (function () {
        var box = document.getElementById('available');
        if (!box || !box.getAttribute('data-live-url') || !window.fetch || !window.DOMParser) { return; }
        setInterval(function () {
            if (document.hidden) { return; }
            fetch(box.getAttribute('data-live-url'), { credentials: 'same-origin' })
                .then(function (r) { return r.ok ? r.text() : null; })
                .then(function (html) {
                    if (!html) { return; }
                    var fresh = new DOMParser().parseFromString(html, 'text/html').getElementById('availLive');
                    var cur = document.getElementById('availLive');
                    if (fresh && cur && !cur.contains(document.activeElement)) { cur.innerHTML = fresh.innerHTML; }
                })
                .catch(function () { /* offline: keep what is on screen */ });
        }, 30000);
    })();
})();
