/*
 * Display preferences: text size and light/dark theme.
 * Loaded in <head> (blocking) so the saved choice is applied before the page paints (no flash).
 * Stored only in this browser (localStorage); the server never sees it.
 */
(function () {
    var root = document.documentElement;
    var KEY = { text: 'toda_text', theme: 'toda_theme' };

    function read(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
    function write(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* private mode: still works for this page */ } }
    var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

    function applyText(size) {
        if (['md', 'lg', 'xl'].indexOf(size) < 0) size = 'md';
        root.setAttribute('data-text', size);
        fitNav();
        return size;
    }
    function applyTheme(mode) {                       // mode: light | dark | auto
        if (['light', 'dark', 'auto'].indexOf(mode) < 0) mode = 'auto';
        var dark = mode === 'dark' || (mode === 'auto' && mq && mq.matches);
        root.setAttribute('data-bs-theme', dark ? 'dark' : 'light');
        root.setAttribute('data-theme-mode', mode);
        return mode;
    }
    // At big text sizes the full menu will not fit beside the brand: switch to the hamburger layout.
    function fitNav() {
        root.classList.remove('nav-compact');
        var nav = document.querySelector('.app-nav');
        if (!nav || window.innerWidth < 992) return;
        var bar = nav.querySelector('.container'), brand = nav.querySelector('.navbar-brand'),
            list = nav.querySelector('.navbar-nav'), acts = nav.querySelector('.nav-actions');
        if (!bar || !brand || !list || !acts) return;
        var listW = 0;
        nav.querySelectorAll('.navbar-nav').forEach(function (u) { listW += u.scrollWidth; });
        if (nav.querySelector('.nav-search')) listW += 200;
        var need = brand.offsetWidth + listW + acts.offsetWidth + 48;
        if (need > bar.clientWidth) root.classList.add('nav-compact');
    }

    applyText(read(KEY.text));
    applyTheme(read(KEY.theme));
    if (mq && mq.addEventListener) mq.addEventListener('change', function () { if (root.getAttribute('data-theme-mode') === 'auto') applyTheme('auto'); });

    function sync() {
        var t = root.getAttribute('data-text'), m = root.getAttribute('data-theme-mode');
        document.querySelectorAll('[data-set-text]').forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-set-text') === t ? 'true' : 'false'); });
        document.querySelectorAll('[data-set-theme]').forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-set-theme') === m ? 'true' : 'false'); });
    }
    document.addEventListener('DOMContentLoaded', function () {
        sync(); fitNav();
        document.addEventListener('click', function (ev) {
            var b = ev.target.closest('[data-set-text],[data-set-theme],[data-toggle-theme]');
            if (!b) return;
            if (b.hasAttribute('data-set-text')) write(KEY.text, applyText(b.getAttribute('data-set-text')));
            if (b.hasAttribute('data-set-theme')) write(KEY.theme, applyTheme(b.getAttribute('data-set-theme')));
            if (b.hasAttribute('data-toggle-theme')) write(KEY.theme, applyTheme(root.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark'));
            sync();
        });
        var t; window.addEventListener('resize', function () { clearTimeout(t); t = setTimeout(fitNav, 120); });
        if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitNav);
    });
})();
