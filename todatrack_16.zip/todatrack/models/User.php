<?php
/** User: a login account (admin, passenger, or driver). */
class User extends BaseModel
{
    public const ROLES = ['admin', 'driver', 'passenger'];

    /** Usernames nobody may register (prevents impersonating staff). */
    public const RESERVED_USERNAMES = ['admin', 'administrator', 'root', 'system', 'superuser', 'support', 'todatrack', 'toda'];

    /** Passwords that contain any of these are rejected (same list is in assets/js/app.js). */
    public const WEAK_PASSWORD_PARTS = ['password', 'qwerty', '12345678', 'abcdefgh', 'admin123', 'letmein', 'iloveyou'];

    /** Fare discount categories a passenger can pick on their profile. */
    public const DISCOUNT_TYPES = ['student' => 'Student', 'senior' => 'Senior citizen', 'pwd' => 'Person with disability (PWD)'];

    private int $id = 0;
    private string $fullName = '';
    private string $username = '';
    private string $email = '';
    private string $passwordHash = '';
    private string $role = 'passenger';

    protected function table(): string
    {
        return 'users';
    }

    // ---- getters / setters ----
    public function getId(): int { return $this->id; }
    public function getFullName(): string { return $this->fullName; }
    public function setFullName(string $v): self { $this->fullName = trim($v); return $this; }

    public function getUsername(): string { return $this->username; }
    public function setUsername(string $v): self { $this->username = strtolower(trim($v)); return $this; }

    public function getEmail(): string { return $this->email; }
    public function setEmail(string $v): self { $this->email = strtolower(trim($v)); return $this; }

    public function getRole(): string { return $this->role; }
    public function setRole(string $v): self
    {
        if (!in_array($v, self::ROLES, true)) {
            throw new InvalidArgumentException('Choose a valid account role.');
        }
        $this->role = $v;
        return $this;
    }

    /** The plain password is hashed immediately; it is never stored. */
    public function setPassword(string $plain): self
    {
        $this->passwordHash = password_hash($plain, PASSWORD_DEFAULT);
        return $this;
    }

    /** Rules for a username. Returns a list of problems (empty = OK). */
    public static function usernameProblems(string $username): array
    {
        $username = strtolower(trim($username));
        $problems = [];
        if (strlen($username) < 5 || strlen($username) > 20) {
            $problems[] = 'Username must be 5-20 characters long.';
        }
        if ($username !== '' && !preg_match('/^[a-z]/', $username)) {
            $problems[] = 'Username must start with a letter.';
        }
        if ($username !== '' && !preg_match('/^[a-z0-9_]+$/', $username)) {
            $problems[] = 'Username can only use letters, numbers, and underscore (no spaces).';
        }
        if (in_array($username, self::RESERVED_USERNAMES, true)) {
            $problems[] = 'That username is reserved. Please choose another.';
        }
        return $problems;
    }

    /** Rules for a strong password. Returns a list of problems (empty = OK). */
    public static function passwordProblems(string $password, string $username = ''): array
    {
        $problems = [];
        if (strlen($password) < 8 || strlen($password) > 64) {
            $problems[] = 'Password must be 8-64 characters long.';
        }
        if (!preg_match('/[A-Z]/', $password)) {
            $problems[] = 'Password needs at least one uppercase letter.';
        }
        if (!preg_match('/[a-z]/', $password)) {
            $problems[] = 'Password needs at least one lowercase letter.';
        }
        if (!preg_match('/\d/', $password)) {
            $problems[] = 'Password needs at least one number.';
        }
        if (!preg_match('/[^A-Za-z0-9\s]/', $password)) {
            $problems[] = 'Password needs at least one special character (for example ! @ # $ %).';
        }
        if (preg_match('/\s/', $password)) {
            $problems[] = 'Password cannot contain spaces.';
        }
        $username = strtolower(trim($username));
        if (strlen($username) >= 4 && str_contains(strtolower($password), $username)) {
            $problems[] = 'Password cannot contain your username.';
        }
        foreach (self::WEAK_PASSWORD_PARTS as $weak) {
            if (str_contains(strtolower($password), $weak)) {
                $problems[] = 'Password is too common or easy to guess.';
                break;
            }
        }
        return $problems;
    }

    /** Server-side validation for the registration form. */
    public function validate(array $data): array
    {
        $errors   = [];
        $name     = trim($data['full_name'] ?? '');
        $username = strtolower(trim($data['username'] ?? ''));
        $email    = strtolower(trim($data['email'] ?? ''));
        $password = (string)($data['password'] ?? '');
        $confirm  = (string)($data['confirm_password'] ?? '');

        if (trim($data['first_name'] ?? '') === '') {
            $errors[] = 'First name is required.';
        }
        if (trim($data['last_name'] ?? '') === '') {
            $errors[] = 'Last name is required.';
        }
        if (strlen($name) > 100) {
            $errors[] = 'First and last name together must be 100 characters or fewer.';
        }
        $errors = array_merge($errors, self::usernameProblems($username));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 120) {
            $errors[] = 'Enter a valid email address.';
        }
        $errors = array_merge($errors, self::passwordProblems($password, $username));
        if ($password !== $confirm) {
            $errors[] = 'Passwords do not match.';
        }
        if (empty($data['privacy_consent'])) {
            $errors[] = 'You must agree to the Data Privacy Notice to create an account.';
        }

        try {
            if (!self::usernameProblems($username) && $this->isTaken('username', $username, 0, 'user_id')) {
                $errors[] = 'That username is already taken.';
            }
            if (filter_var($email, FILTER_VALIDATE_EMAIL) && $this->isTaken('email', $email, 0, 'user_id')) {
                $errors[] = 'That email is already registered.';
            }
        } catch (PDOException $e) {
            $errors[] = $this->friendlyError($e);
        }

        $type = (string)($data['account_type'] ?? '');
        // Only passengers and drivers can register. Admin accounts are created directly in the database.
        if (!in_array($type, ['passenger', 'driver'], true)) {
            $errors[] = 'Choose whether you are registering as a passenger or a driver.';
        }
        // Passengers give no extra details; drivers must give a contact and license number.
        if ($type === 'driver') {
            $driver = new Driver();
            $errors = array_merge($errors, $driver->validate([
                'full_name'  => $name,
                'contact_no' => $data['contact_no'] ?? '',
                'license_no' => $data['license_no'] ?? '',
            ]));
        }
        return $errors;
    }

    /**
     * Create the account (role: driver or passenger). When $driverData is given, a linked
     * driver profile is created in the same transaction (a driver); without
     * it the account is a passenger.
     */
    public function register(?array $driverData = null): bool
    {
        $this->clearErrors();
        $this->role = $driverData === null ? 'passenger' : 'driver';
        try {
            $this->beginTransaction();
            $this->id = $this->insertGetId(
                'INSERT INTO users (full_name, username, email, password_hash, role, consented_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)',
                [$this->fullName, $this->username, $this->email, $this->passwordHash, $this->role],
                'user_id'
            );

            if ($driverData !== null) {
                $driver = new Driver();
                $driver->setUserId($this->id)
                       ->setFullName($this->fullName)
                       ->setContactNo($driverData['contact_no'] ?? '')
                       ->setLicenseNo($driverData['license_no'] ?? '');
                if (!$driver->create()) {
                    throw new RuntimeException(implode(' ', $driver->getErrors()));
                }
            } else {
                $this->query('INSERT INTO passengers (user_id) VALUES (?)', [$this->id]);
            }
            $this->commit();
            return true;
        } catch (PDOException $e) {
            $this->rollback();
            $this->addError($this->friendlyError($e, ['unique' => 'That username, email, or license number is already registered.']));
        } catch (RuntimeException $e) {
            $this->rollback();
            $this->addError($e->getMessage());
        }
        return false;
    }

    /** Check username/email + password. Returns the user row or null. */
    public function authenticate(string $login, string $password): ?array
    {
        $login = strtolower(trim($login));
        try {
            $row = $this->fetchOne(
                'SELECT u.user_id, u.full_name, u.username, u.role, u.password_hash, p.discount_type, u.is_active
                   FROM users u
              LEFT JOIN passengers p ON p.user_id = u.user_id
                  WHERE u.username = ? OR u.email = ? LIMIT 1',
                [$login, $login]
            );
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e));
            return null;
        }
        if ($row && password_verify($password, $row['password_hash'])) {
            if (!$row['is_active']) {
                $this->addError('This account has been deactivated. Please contact the TODA admin.');
                return null;
            }
            unset($row['password_hash']);
            $row['account_type'] = $row['role'];
            return $row;
        }
        return null;
    }

    // ---- account status (admin) ----
    /** False only when the account exists and was deactivated. A database hiccup never locks anyone out here. */
    public function isActive(int $id): bool
    {
        try {
            $row = $this->fetchOne('SELECT is_active FROM users WHERE user_id = ?', [$id]);
        } catch (PDOException $e) {
            return true;
        }
        return $row === null ? false : (bool)$row['is_active'];
    }

    /** Deactivate or reactivate a non-admin account. */
    public function setActive(int $id, bool $active): bool
    {
        try {
            $this->query("UPDATE users SET is_active = ? WHERE user_id = ? AND role <> 'admin'", [$active ? 'true' : 'false', $id]);
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    /** Passenger account details for the admin's passenger list. Passwords are never selected. */
    public function allPassengersForAdmin(): array
    {
        return $this->fetchAll(
            "SELECT u.user_id, u.full_name, u.username, u.email, u.is_active, u.created_at,
                    p.passenger_id, p.discount_type
               FROM users u
               JOIN passengers p ON p.user_id = u.user_id
              WHERE u.role = 'passenger'
           ORDER BY u.full_name, u.user_id"
        );
    }

    /** Deactivate/reactivate only a passenger account. */
    public function setPassengerActive(int $id, bool $active): bool
    {
        try {
            $updated = $this->query(
                "UPDATE users SET is_active = ? WHERE user_id = ? AND role = 'passenger'",
                [$active ? 'true' : 'false', $id]
            );
            if ($updated->rowCount() === 0) {
                $this->addError('That passenger account no longer exists.');
                return false;
            }
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    /** Permanently delete a passenger login; linked passenger data is removed by foreign-key cascades. */
    public function deletePassengerAccount(int $id): bool
    {
        try {
            $this->beginTransaction();
            $deleted = $this->query("DELETE FROM users WHERE user_id = ? AND role = 'passenger'", [$id]);
            if ($deleted->rowCount() === 0) {
                $this->rollback();
                $this->addError('That passenger account no longer exists.');
                return false;
            }
            $this->commit();
            return true;
        } catch (PDOException $e) {
            $this->rollback();
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    // ---- passenger profile ----
    public function findProfile(int $id): ?array
    {
        return $this->fetchOne(
            'SELECT u.user_id, u.full_name, u.username, u.email, p.discount_type, u.created_at
               FROM users u
               JOIN passengers p ON p.user_id = u.user_id
              WHERE u.user_id = ?',
            [$id]
        );
    }

    /** Validate and save the passenger's name and discount type. */
    public function updateProfile(int $id, string $fullName, string $discount): bool
    {
        $this->clearErrors();
        $fullName = trim($fullName);
        if (strlen($fullName) < 2 || strlen($fullName) > 100) {
            $this->addError('Full name is required (2-100 characters).');
        }
        if ($discount !== '' && !array_key_exists($discount, self::DISCOUNT_TYPES)) {
            $this->addError('Choose a valid discount type.');
        }
        if ($this->errors) {
            return false;
        }
        try {
            $this->beginTransaction();
            $this->query('UPDATE users SET full_name = ? WHERE user_id = ?', [$fullName, $id]);
            $updated = $this->query(
                'UPDATE passengers SET discount_type = ? WHERE user_id = ?',
                [$discount === '' ? null : $discount, $id]
            );
            if ($updated->rowCount() === 0) {
                $this->rollback();
                $this->addError('The passenger profile could not be found.');
                return false;
            }
            $this->commit();
            return true;
        } catch (PDOException $e) {
            $this->rollback();
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    /** Number of passenger and driver accounts (admins are excluded). */
    public function countByType(): array
    {
        $row = $this->fetchOne(
            "SELECT COUNT(*) FILTER (WHERE role = 'passenger') AS passengers,
                    COUNT(*) FILTER (WHERE role = 'driver') AS drivers
               FROM users"
        );
        return ['passengers' => (int)$row['passengers'], 'drivers' => (int)$row['drivers']];
    }
}
