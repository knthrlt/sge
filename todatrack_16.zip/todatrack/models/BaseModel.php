<?php
/**
 * BaseModel
 * Abstract parent of all models. Provides prepared-statement helpers,
 * friendly database error messages, transactions, and the abstract
 * validate() method that every child overrides (polymorphism).
 */
abstract class BaseModel extends Database
{
    protected array $errors = [];

    public function __construct()
    {
        $this->connect();
    }

    /** Table handled by the model. */
    abstract protected function table(): string;

    /** Validate input and return a list of error messages (empty = valid). */
    abstract public function validate(array $data): array;

    public function getErrors(): array
    {
        return $this->errors;
    }

    protected function addError(string $message): void
    {
        $this->errors[] = $message;
    }

    protected function clearErrors(): void
    {
        $this->errors = [];
    }

    private function driverName(): string
    {
        return (string)$this->conn->getAttribute(PDO::ATTR_DRIVER_NAME);
    }

    /** Run a prepared statement (values are bound, never concatenated). */
    protected function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    protected function fetchAll(string $sql, array $params = []): array
    {
        return $this->query($sql, $params)->fetchAll(PDO::FETCH_ASSOC);
    }

    protected function fetchOne(string $sql, array $params = []): ?array
    {
        $rows = $this->fetchAll($sql, $params);
        return $rows[0] ?? null;
    }

    /** INSERT and return the new id (works on MySQL and PostgreSQL). */
    protected function insertGetId(string $sql, array $params, string $idColumn): int
    {
        if ($this->driverName() === 'pgsql') {
            return (int)$this->query($sql . ' RETURNING ' . $idColumn, $params)->fetchColumn();
        }
        $this->query($sql, $params);
        return (int)$this->conn->lastInsertId();
    }

    /** True if $value already exists in $column (ignoring row $exceptId). Not case-sensitive. */
    protected function isTaken(string $column, string $value, int $exceptId = 0, string $idColumn = ''): bool
    {
        $idColumn = $idColumn ?: $this->table() . '_id';
        $row = $this->fetchOne(
            "SELECT 1 FROM {$this->table()} WHERE LOWER({$column}) = LOWER(?) AND {$idColumn} <> ? LIMIT 1",
            [$value, $exceptId]
        );
        return $row !== null;
    }

    /** True if a row with this id exists in $table. */
    protected function rowExists(string $table, string $idColumn, int $id): bool
    {
        return $this->fetchOne("SELECT 1 FROM {$table} WHERE {$idColumn} = ? LIMIT 1", [$id]) !== null;
    }

    /** Classify a database error: unique, fk_delete, fk_insert, check, notnull, toolong, other. */
    private function errorKind(PDOException $e): string
    {
        $state = (string)$e->getCode();
        $code  = (int)($e->errorInfo[1] ?? 0);

        if ($this->driverName() === 'mysql') {
            return [1062 => 'unique', 1451 => 'fk_delete', 1452 => 'fk_insert', 1406 => 'toolong',
                    1048 => 'notnull', 3819 => 'check', 4025 => 'check'][$code] ?? 'other';
        }
        switch ($state) {
            case '23505': return 'unique';
            case '23503': return str_contains($e->getMessage(), 'is still referenced') ? 'fk_delete' : 'fk_insert';
            case '23514': return 'check';
            case '23502': return 'notnull';
            case '22001': return 'toolong';
            default:      return 'other';
        }
    }

    /** Convert a database exception into a message that is safe to show. */
    protected function friendlyError(PDOException $e, array $custom = []): string
    {
        error_log('[TodaTrack] ' . $e->getCode() . ' ' . $e->getMessage());
        $kind = $this->errorKind($e);
        if (isset($custom[$kind])) {
            return $custom[$kind];
        }
        return [
            'unique'    => 'That record already exists (a unique value is duplicated).',
            'fk_delete' => 'This record is still used by other records, so it cannot be deleted.',
            'fk_insert' => 'A selected option does not exist anymore. Please refresh and try again.',
            'toolong'   => 'One of the values is too long.',
            'notnull'   => 'A required value is missing.',
            'check'     => 'A value is outside the allowed range.',
        ][$kind] ?? 'A database error occurred. Please try again.';
    }

    public function beginTransaction(): void
    {
        $this->conn->beginTransaction();
    }

    public function commit(): void
    {
        $this->conn->commit();
    }

    public function rollback(): void
    {
        if ($this->conn->inTransaction()) {
            $this->conn->rollBack();
        }
    }
}
