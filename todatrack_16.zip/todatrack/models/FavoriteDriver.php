<?php
/** FavoriteDriver: drivers a passenger marked as favorite. */
class FavoriteDriver extends BaseModel
{
    protected function table(): string
    {
        return 'favorite_drivers';
    }

    /** Nothing to validate on its own; kept because every model overrides validate(). */
    public function validate(array $data): array
    {
        $errors = [];
        try {
            if ((int)($data['driver_id'] ?? 0) <= 0 || !$this->rowExists('drivers', 'driver_id', (int)$data['driver_id'])) {
                $errors[] = 'That driver does not exist.';
            }
        } catch (PDOException $e) {
            $errors[] = $this->friendlyError($e);
        }
        return $errors;
    }

    /** Add the driver to the favorites, or remove it if it is already there. Returns true when added. */
    public function toggle(int $userId, int $driverId): bool
    {
        $removed = $this->query('DELETE FROM favorite_drivers WHERE user_id = ? AND driver_id = ?', [$userId, $driverId])->rowCount();
        if ($removed > 0) {
            return false;
        }
        $this->query('INSERT INTO favorite_drivers (user_id, driver_id) VALUES (?, ?)', [$userId, $driverId]);
        return true;
    }

    public function idsForUser(int $userId): array
    {
        return array_map('intval', array_column(
            $this->fetchAll('SELECT driver_id FROM favorite_drivers WHERE user_id = ?', [$userId]),
            'driver_id'
        ));
    }

    /** Favorite drivers with their tricycle, current status, and the passenger's own rating. */
    public function forUser(int $userId): array
    {
        $rows = $this->fetchAll(
            "SELECT d.driver_id, d.full_name,
                    t.body_number, t.plate_number, t.status,
                    z.zone_name, z.color_name, z.color_hex, l.location_name,
                    (SELECT stars FROM driver_ratings r WHERE r.user_id = fd.user_id AND r.driver_id = d.driver_id) AS my_stars
               FROM favorite_drivers fd
               JOIN drivers d        ON d.driver_id   = fd.driver_id
          LEFT JOIN tricycles t      ON t.driver_id   = d.driver_id
          LEFT JOIN zones z          ON z.zone_id     = t.zone_id
          LEFT JOIN locations l      ON l.location_id = t.location_id
              WHERE fd.user_id = ?
           ORDER BY (t.status = 'available') DESC NULLS LAST, d.full_name",
            [$userId]
        );
        foreach ($rows as &$r) {
            $r['text_hex']     = $r['color_hex'] ? Zone::contrastColor($r['color_hex']) : '#ffffff';
            $r['status_label'] = Tricycle::STATUSES[$r['status'] ?? ''] ?? 'No tricycle yet';
        }
        return $rows;
    }

    /** Identity-free favorite entries for the driver's dashboard. */
    public function anonymousEntriesForDriver(int $driverId): array
    {
        return $this->fetchAll(
            'SELECT created_at AS favorited_at
               FROM favorite_drivers
              WHERE driver_id = ?
           ORDER BY created_at DESC',
            [$driverId]
        );
    }
}
