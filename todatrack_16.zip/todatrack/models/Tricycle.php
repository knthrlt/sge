<?php
/** Tricycle: a tricycle unit (main CRUD module). */
class Tricycle extends BaseModel
{
    public const STATUSES = [
        'available' => 'Available',
        'on_trip'   => 'On Trip',
        'off_duty'  => 'Off Duty',
    ];

    private int $id = 0;
    private string $bodyNumber = '';
    private string $plateNumber = '';
    private int $driverId = 0;
    private int $zoneId = 0;
    private int $locationId = 0;
    private string $status = 'available';

    protected function table(): string
    {
        return 'tricycles';
    }

    // ---- getters / setters ----
    public function getId(): int { return $this->id; }
    public function setId(int $id): self { $this->id = $id; return $this; }

    public function getBodyNumber(): string { return $this->bodyNumber; }
    public function setBodyNumber(string $v): self { $this->bodyNumber = strtoupper(trim($v)); return $this; }

    public function getPlateNumber(): string { return $this->plateNumber; }
    public function setPlateNumber(string $v): self { $this->plateNumber = strtoupper(trim($v)); return $this; }

    public function getDriverId(): int { return $this->driverId; }
    public function setDriverId(int $v): self { $this->driverId = $v; return $this; }

    public function getZoneId(): int { return $this->zoneId; }
    public function setZoneId(int $v): self { $this->zoneId = $v; return $this; }

    public function getLocationId(): int { return $this->locationId; }
    public function setLocationId(int $v): self { $this->locationId = $v; return $this; }

    public function getStatus(): string { return $this->status; }
    public function setStatus(string $v): self { $this->status = $v; return $this; }

    /** Fill all fields from posted data using the setters. */
    public function fill(array $d): self
    {
        return $this->setBodyNumber($d['body_number'] ?? '')
                    ->setPlateNumber($d['plate_number'] ?? '')
                    ->setDriverId((int)($d['driver_id'] ?? 0))
                    ->setZoneId((int)($d['zone_id'] ?? 0))
                    ->setLocationId((int)($d['location_id'] ?? 0))
                    ->setStatus((string)($d['status'] ?? 'available'));
    }

    // ---- validation (server-side) ----
    public function validate(array $data): array
    {
        $errors = [];
        $id     = (int)($data['tricycle_id'] ?? 0);
        $body   = strtoupper(trim($data['body_number'] ?? ''));
        $plate  = strtoupper(trim($data['plate_number'] ?? ''));
        $driver = (int)($data['driver_id'] ?? 0);
        $zone   = (int)($data['zone_id'] ?? 0);

        if (!preg_match('/^[A-Z0-9-]{1,10}$/', $body)) {
            $errors[] = 'Body number is required: up to 10 letters, numbers, or dashes (e.g., T-015).';
        }
        if (!preg_match('/^[A-Z0-9-]{4,10}$/', $plate)) {
            $errors[] = 'Plate number is required: 4-10 letters, numbers, or dashes (e.g., ABC-1234).';
        }

        try {
            if (preg_match('/^[A-Z0-9-]{1,10}$/', $body) && $this->isTaken('body_number', $body, $id, 'tricycle_id')) {
                $errors[] = 'That body number is already used by another tricycle.';
            }
            if (preg_match('/^[A-Z0-9-]{4,10}$/', $plate) && $this->isTaken('plate_number', $plate, $id, 'tricycle_id')) {
                $errors[] = 'That plate number is already used by another tricycle.';
            }
            if ($driver <= 0 || !$this->rowExists('drivers', 'driver_id', $driver)) {
                $errors[] = 'Choose a driver.';
            } else {
                $other = $this->fetchOne(
                    'SELECT 1 FROM tricycles WHERE driver_id = ? AND tricycle_id <> ? LIMIT 1',
                    [$driver, $id]
                );
                if ($other) {
                    $errors[] = 'That driver is already assigned to another tricycle.';
                }
            }
            if ($zone <= 0 || !$this->rowExists('zones', 'zone_id', $zone)) {
                $errors[] = 'Choose a zone.';
            }
        } catch (PDOException $e) {
            $errors[] = $this->friendlyError($e);
        }

        return array_merge($errors, $this->validateLocationStatus($data));
    }

    /** Rules for the two fields a driver may update by themselves. */
    public function validateLocationStatus(array $data): array
    {
        $errors = [];
        $loc    = (int)($data['location_id'] ?? 0);
        $status = (string)($data['status'] ?? '');
        try {
            if ($loc <= 0 || !$this->rowExists('locations', 'location_id', $loc)) {
                $errors[] = 'Choose the current location.';
            }
        } catch (PDOException $e) {
            $errors[] = $this->friendlyError($e);
        }
        if (!array_key_exists($status, self::STATUSES)) {
            $errors[] = 'Choose a valid status.';
        }
        return $errors;
    }

    // ---- create / update / delete ----
    public function create(): bool
    {
        $this->clearErrors();
        try {
            $this->id = $this->insertGetId(
                'INSERT INTO tricycles (body_number, plate_number, driver_id, zone_id, location_id, status) VALUES (?, ?, ?, ?, ?, ?)',
                [$this->bodyNumber, $this->plateNumber, $this->driverId, $this->zoneId, $this->locationId, $this->status],
                'tricycle_id'
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'Body number, plate number, or driver is already used by another tricycle.']));
            return false;
        }
    }

    public function update(): bool
    {
        $this->clearErrors();
        try {
            $this->query(
                'UPDATE tricycles SET body_number = ?, plate_number = ?, driver_id = ?, zone_id = ?, location_id = ?, status = ? WHERE tricycle_id = ?',
                [$this->bodyNumber, $this->plateNumber, $this->driverId, $this->zoneId, $this->locationId, $this->status, $this->id]
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'Body number, plate number, or driver is already used by another tricycle.']));
            return false;
        }
    }

    /** Drivers use this to update only their location and status. */
    public function updateLocationStatus(): bool
    {
        $this->clearErrors();
        try {
            $this->query(
                'UPDATE tricycles SET location_id = ?, status = ? WHERE tricycle_id = ?',
                [$this->locationId, $this->status, $this->id]
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    public function delete(int $id): bool
    {
        $this->clearErrors();
        try {
            $stmt = $this->query('DELETE FROM tricycles WHERE tricycle_id = ?', [$id]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    // ---- reading ----
    private function baseSelect(): string
    {
        return "SELECT t.tricycle_id, t.body_number, t.plate_number, t.status, t.updated_at,
                       t.driver_id, d.full_name AS driver_name, d.contact_no, d.user_id AS driver_user_id,
                       COALESCE(du.is_active, TRUE) AS driver_active,
                       t.zone_id, z.zone_name, z.color_name, z.color_hex,
                       t.location_id, l.location_name
                  FROM tricycles t
                  JOIN drivers d   ON d.driver_id   = t.driver_id
             LEFT JOIN users du    ON du.user_id     = d.user_id
                  JOIN zones z     ON z.zone_id     = t.zone_id
                  JOIN locations l ON l.location_id = t.location_id";
    }

    private function decorate(array $row): array
    {
        $row['text_hex']     = Zone::contrastColor($row['color_hex']);
        $row['status_label'] = self::STATUSES[$row['status']] ?? $row['status'];
        return $row;
    }

    public function all(): array
    {
        return array_map([$this, 'decorate'], $this->fetchAll($this->baseSelect() . ' ORDER BY t.body_number'));
    }

    public function find(int $id): ?array
    {
        $row = $this->fetchOne($this->baseSelect() . ' WHERE t.tricycle_id = ?', [$id]);
        return $row ? $this->decorate($row) : null;
    }

    /** The tricycle driven by the driver linked to this login account. */
    public function findByDriverUser(int $userId): ?array
    {
        $row = $this->fetchOne($this->baseSelect() . ' WHERE d.user_id = ?', [$userId]);
        return $row ? $this->decorate($row) : null;
    }

    public function availableByZone(int $zoneId): array
    {
        $rows = $this->fetchAll(
            $this->baseSelect() . " WHERE t.zone_id = ? AND t.status = 'available' AND COALESCE(du.is_active, TRUE) ORDER BY t.body_number",
            [$zoneId]
        );
        return array_map([$this, 'decorate'], $rows);
    }

    /** Every tricycle that is available right now (optionally one zone). A deactivated driver never counts. */
    public function allAvailable(int $zoneId = 0): array
    {
        $sql    = $this->baseSelect() . " WHERE t.status = 'available' AND COALESCE(du.is_active, TRUE)";
        $params = [];
        if ($zoneId > 0) {
            $sql .= ' AND t.zone_id = ?';
            $params[] = $zoneId;
        }
        return array_map([$this, 'decorate'], $this->fetchAll($sql . ' ORDER BY z.zone_name, t.body_number', $params));
    }

    /** Count of tricycles per status (every status is present). */
    public function statusCounts(): array
    {
        $counts = array_fill_keys(array_keys(self::STATUSES), 0);
        foreach ($this->fetchAll(
            "SELECT CASE WHEN COALESCE(du.is_active, TRUE) THEN t.status ELSE 'off_duty' END AS status, COUNT(*) AS total
               FROM tricycles t JOIN drivers d ON d.driver_id = t.driver_id LEFT JOIN users du ON du.user_id = d.user_id
           GROUP BY 1"
        ) as $r) {
            $counts[$r['status']] = (int)$r['total'];
        }
        return $counts;
    }
}
