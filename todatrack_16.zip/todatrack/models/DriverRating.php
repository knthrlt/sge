<?php
/** DriverRating: a passenger's 1-5 star rating (and optional comment) for a driver. */
class DriverRating extends BaseModel
{
    public const STATUSES = ['visible' => 'Visible', 'hidden' => 'Hidden'];

    private int $userId = 0;
    private int $driverId = 0;
    private int $stars = 0;
    private string $comment = '';
    private bool $anonymous = false;

    protected function table(): string
    {
        return 'driver_ratings';
    }

    public function setUserId(int $v): self { $this->userId = $v; return $this; }
    public function getUserId(): int { return $this->userId; }
    public function setDriverId(int $v): self { $this->driverId = $v; return $this; }
    public function getDriverId(): int { return $this->driverId; }
    public function setStars(int $v): self { $this->stars = $v; return $this; }
    public function getStars(): int { return $this->stars; }
    public function setComment(string $v): self { $this->comment = trim($v); return $this; }
    public function getComment(): string { return $this->comment; }
    public function setAnonymous(bool $v): self { $this->anonymous = $v; return $this; }
    public function isAnonymous(): bool { return $this->anonymous; }

    public function validate(array $data): array
    {
        $errors = [];
        $stars  = (int)($data['stars'] ?? 0);
        if ($stars < 1 || $stars > 5) {
            $errors[] = 'Choose a rating from 1 to 5 stars.';
        }
        if (strlen(trim((string)($data['comment'] ?? ''))) > 255) {
            $errors[] = 'The comment is too long (maximum 255 characters).';
        }
        try {
            if ((int)($data['driver_id'] ?? 0) <= 0 || !$this->rowExists('drivers', 'driver_id', (int)$data['driver_id'])) {
                $errors[] = 'That driver does not exist.';
            }
        } catch (PDOException $e) {
            $errors[] = $this->friendlyError($e);
        }
        return $errors;
    }

    /** Create the rating, or change the passenger's earlier rating of the same driver. */
    public function save(): bool
    {
        $this->clearErrors();
        try {
            $this->query(
                'INSERT INTO driver_ratings (user_id, driver_id, stars, comment, is_anonymous) VALUES (?, ?, ?, ?, ?)
                 ON CONFLICT (user_id, driver_id)
                 DO UPDATE SET stars = EXCLUDED.stars, comment = EXCLUDED.comment,
                               is_anonymous = EXCLUDED.is_anonymous, updated_at = CURRENT_TIMESTAMP',
                [
                    $this->userId,
                    $this->driverId,
                    $this->stars,
                    $this->comment === '' ? null : $this->comment,
                    $this->anonymous ? 'true' : 'false',
                ]
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    /** The passenger's own rating of one driver (or null). */
    public function mine(int $userId, int $driverId): ?array
    {
        return $this->fetchOne('SELECT rating_id, stars, comment, is_anonymous FROM driver_ratings WHERE user_id = ? AND driver_id = ?', [$userId, $driverId]);
    }

    /** Average and count of VISIBLE ratings for every driver: [driver_id => ['avg' => 4.5, 'count' => 3]]. */
    public function summaries(): array
    {
        $out = [];
        foreach ($this->fetchAll("SELECT driver_id, ROUND(AVG(stars), 1) AS avg_stars, COUNT(*) AS total FROM driver_ratings WHERE status = 'visible' GROUP BY driver_id") as $r) {
            $out[(int)$r['driver_id']] = ['avg' => (float)$r['avg_stars'], 'count' => (int)$r['total']];
        }
        return $out;
    }

    public function summaryForDriver(int $driverId): array
    {
        return $this->summaries()[$driverId] ?? ['avg' => 0.0, 'count' => 0];
    }

    /** Visible reviews for the driver's dashboard; never return account identifiers for anonymous reviews. */
    public function visibleForDriver(int $driverId): array
    {
        return $this->fetchAll(
            "SELECT r.stars, r.comment, r.created_at,
                    CASE WHEN r.is_anonymous THEN 'Anonymous' ELSE u.full_name END AS passenger_display
               FROM driver_ratings r
               JOIN users u ON u.user_id = r.user_id
              WHERE r.driver_id = ? AND r.status = 'visible'
           ORDER BY r.created_at DESC",
            [$driverId]
        );
    }

    public function countForUser(int $userId): int
    {
        return (int)$this->fetchOne('SELECT COUNT(*) AS total FROM driver_ratings WHERE user_id = ?', [$userId])['total'];
    }

    // ---- admin ----
    public function allForAdmin(): array
    {
        return $this->fetchAll(
            'SELECT r.rating_id, r.stars, r.comment, r.is_anonymous, r.status, r.created_at,
                    d.full_name AS driver_name, u.full_name AS passenger_name, u.username AS passenger_username
               FROM driver_ratings r
               JOIN drivers d ON d.driver_id = r.driver_id
               JOIN users u   ON u.user_id   = r.user_id
           ORDER BY r.created_at DESC'
        );
    }

    public function recent(int $limit = 5): array
    {
        return array_slice($this->allForAdmin(), 0, $limit);
    }

    public function countAll(): int
    {
        return (int)$this->fetchOne('SELECT COUNT(*) AS total FROM driver_ratings')['total'];
    }

    public function setStatus(int $id, string $status): bool
    {
        if (!array_key_exists($status, self::STATUSES)) {
            return false;
        }
        return $this->query('UPDATE driver_ratings SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE rating_id = ?', [$status, $id])->rowCount() > 0;
    }

    public function delete(int $id): bool
    {
        return $this->query('DELETE FROM driver_ratings WHERE rating_id = ?', [$id])->rowCount() > 0;
    }
}
