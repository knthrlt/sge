<?php
/** FareRate: regular fare from an origin zone to a destination location. */
class FareRate extends BaseModel
{
    /** Student / Senior Citizen / PWD discount (20%). */
    public const DISCOUNT_RATE = 0.20;

    private int $id = 0;
    private int $zoneId = 0;
    private int $locationId = 0;
    private float $fare = 0.0;

    protected function table(): string
    {
        return 'fare_rates';
    }

    // ---- getters / setters ----
    public function getId(): int { return $this->id; }
    public function setId(int $id): self { $this->id = $id; return $this; }

    public function getZoneId(): int { return $this->zoneId; }
    public function setZoneId(int $v): self { $this->zoneId = $v; return $this; }

    public function getLocationId(): int { return $this->locationId; }
    public function setLocationId(int $v): self { $this->locationId = $v; return $this; }

    public function getFare(): float { return $this->fare; }
    public function setFare(float $v): self { $this->fare = round($v, 2); return $this; }

    public function validate(array $data): array
    {
        $errors = [];
        $id     = (int)($data['fare_id'] ?? 0);
        $zone   = (int)($data['zone_id'] ?? 0);
        $loc    = (int)($data['location_id'] ?? 0);
        $fare   = $data['fare'] ?? '';

        try {
            if ($zone <= 0 || !$this->rowExists('zones', 'zone_id', $zone)) {
                $errors[] = 'Choose a valid origin zone.';
            }
            if ($loc <= 0 || !$this->rowExists('locations', 'location_id', $loc)) {
                $errors[] = 'Choose a valid destination.';
            }
            if (!is_numeric($fare) || (float)$fare <= 0 || (float)$fare > 9999.99) {
                $errors[] = 'Fare must be a number greater than 0 (max 9999.99).';
            }
            if (!$errors) {
                $dup = $this->fetchOne(
                    'SELECT 1 FROM fare_rates WHERE zone_id = ? AND location_id = ? AND fare_id <> ? LIMIT 1',
                    [$zone, $loc, $id]
                );
                if ($dup) {
                    $errors[] = 'A fare for that origin zone and destination already exists.';
                }
            }
        } catch (PDOException $e) {
            $errors[] = $this->friendlyError($e);
        }
        return $errors;
    }

    public function create(): bool
    {
        $this->clearErrors();
        try {
            $this->query(
                'INSERT INTO fare_rates (zone_id, location_id, fare) VALUES (?, ?, ?)',
                [$this->zoneId, $this->locationId, $this->fare]
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'A fare for that origin zone and destination already exists.']));
            return false;
        }
    }

    public function update(): bool
    {
        $this->clearErrors();
        try {
            $this->query(
                'UPDATE fare_rates SET zone_id = ?, location_id = ?, fare = ? WHERE fare_id = ?',
                [$this->zoneId, $this->locationId, $this->fare, $this->id]
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'A fare for that origin zone and destination already exists.']));
            return false;
        }
    }

    public function delete(int $id): bool
    {
        $this->clearErrors();
        try {
            $stmt = $this->query('DELETE FROM fare_rates WHERE fare_id = ?', [$id]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    /** Select with joins; the discounted fare is computed, not stored. */
    private function baseSelect(): string
    {
        $d = (float)self::DISCOUNT_RATE;
        return "SELECT fr.fare_id, fr.zone_id, fr.location_id, fr.fare,
                       ROUND(fr.fare * (1 - {$d}), 2) AS discounted_fare,
                       z.zone_name, z.color_name, z.color_hex,
                       l.location_name
                  FROM fare_rates fr
                  JOIN zones z ON z.zone_id = fr.zone_id
                  JOIN locations l ON l.location_id = fr.location_id";
    }

    public function all(): array
    {
        $rows = $this->fetchAll($this->baseSelect() . ' ORDER BY z.zone_id, l.location_name');
        return array_map(fn($r) => $r + ['text_hex' => Zone::contrastColor($r['color_hex'])], $rows);
    }

    /** Fares to one destination, optionally from one origin zone. */
    public function forRoute(int $locationId, int $zoneId = 0): array
    {
        $sql = $this->baseSelect() . ' WHERE fr.location_id = ?';
        $params = [$locationId];
        if ($zoneId > 0) {
            $sql .= ' AND fr.zone_id = ?';
            $params[] = $zoneId;
        }
        $rows = $this->fetchAll($sql . ' ORDER BY fr.fare', $params);
        return array_map(fn($r) => $r + ['text_hex' => Zone::contrastColor($r['color_hex'])], $rows);
    }
}
