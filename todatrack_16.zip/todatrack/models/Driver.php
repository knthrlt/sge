<?php
/** Driver: person who drives a tricycle. May be linked to a login account. */
class Driver extends BaseModel
{
    private int $id = 0;
    private ?int $userId = null;
    private string $fullName = '';
    private string $contactNo = '';
    private string $licenseNo = '';

    protected function table(): string
    {
        return 'drivers';
    }

    // ---- getters / setters ----
    public function getId(): int { return $this->id; }
    public function setId(int $id): self { $this->id = $id; return $this; }

    public function getUserId(): ?int { return $this->userId; }
    public function setUserId(?int $userId): self { $this->userId = $userId; return $this; }

    public function getFullName(): string { return $this->fullName; }
    public function setFullName(string $v): self { $this->fullName = trim($v); return $this; }

    public function getContactNo(): string { return $this->contactNo; }
    public function setContactNo(string $v): self { $this->contactNo = preg_replace('/\s+/', '', trim($v)); return $this; }

    public function getLicenseNo(): string { return $this->licenseNo; }
    public function setLicenseNo(string $v): self { $this->licenseNo = strtoupper(trim($v)); return $this; }

    /** Server-side validation of driver details. */
    public function validate(array $data): array
    {
        $errors = [];
        $name    = trim($data['full_name'] ?? '');
        $contact = preg_replace('/\s+/', '', trim($data['contact_no'] ?? ''));
        $license = strtoupper(trim($data['license_no'] ?? ''));
        $id      = (int)($data['driver_id'] ?? 0);

        if ($name === '' || strlen($name) > 100) {
            $errors[] = 'Driver name is required (max 100 characters).';
        }
        if (!preg_match('/^(09\d{9}|\+639\d{9})$/', $contact)) {
            $errors[] = 'Contact number must look like 09171234567 or +639171234567.';
        }
        if (!preg_match('/^[A-Z0-9-]{5,20}$/', $license)) {
            $errors[] = "License number must be 5-20 letters, numbers, or dashes.";
        } else {
            try {
                if ($this->isTaken('license_no', $license, $id, 'driver_id')) {
                    $errors[] = 'That license number is already registered.';
                }
            } catch (PDOException $e) {
                $errors[] = $this->friendlyError($e);
            }
        }
        return $errors;
    }

    /** Insert this driver (call the setters first). */
    public function create(): bool
    {
        $this->clearErrors();
        try {
            $this->id = $this->insertGetId(
                'INSERT INTO drivers (user_id, full_name, contact_no, license_no) VALUES (?, ?, ?, ?)',
                [$this->userId, $this->fullName, $this->contactNo, $this->licenseNo],
                'driver_id'
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'That license number is already registered.']));
            return false;
        }
    }

    /**
     * Drivers for the tricycle form: only drivers that do not have a
     * tricycle yet, plus the driver of the tricycle being edited.
     */
    public function assignable(int $includeDriverId = 0): array
    {
        return $this->fetchAll(
            'SELECT d.driver_id, d.full_name, d.license_no
               FROM drivers d
          LEFT JOIN tricycles t ON t.driver_id = d.driver_id
              WHERE t.tricycle_id IS NULL OR d.driver_id = ?
           ORDER BY d.full_name',
            [$includeDriverId]
        );
    }

    /** Read-only list for the admin: each driver, their account, and assigned tricycle. */
    public function allWithDetails(): array
    {
        return $this->fetchAll(
            'SELECT d.driver_id, d.full_name, d.contact_no, d.license_no,
                    d.user_id, u.username, COALESCE(u.is_active, TRUE) AS is_active,
                    t.tricycle_id, t.body_number, t.plate_number
               FROM drivers d
          LEFT JOIN users u     ON u.user_id   = d.user_id
          LEFT JOIN tricycles t ON t.driver_id = d.driver_id
           ORDER BY d.full_name'
        );
    }

    /**
     * Deactivate/reactivate the driver's login. Deactivating also sets the tricycle Off Duty,
     * so passengers stop seeing it. Nothing is deleted.
     */
    public function setActive(int $driverId, bool $active): bool
    {
        $d = $this->fetchOne('SELECT driver_id, user_id FROM drivers WHERE driver_id = ?', [$driverId]);
        if (!$d || !$d['user_id']) {
            $this->addError('That driver has no login account to change.');
            return false;
        }
        try {
            $this->beginTransaction();
            $this->query("UPDATE users SET is_active = ? WHERE user_id = ? AND role <> 'admin'", [$active ? 'true' : 'false', $d['user_id']]);
            if (!$active) {
                $this->query("UPDATE tricycles SET status = 'off_duty' WHERE driver_id = ?", [$driverId]);
            }
            $this->commit();
            return true;
        } catch (PDOException $e) {
            $this->rollback();
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    /**
     * Permanently delete a driver and their login. Only allowed when no tricycle is assigned
     * (remove or reassign the tricycle first). Ratings and favorites of this driver go with it.
     */
    public function deleteWithAccount(int $driverId): bool
    {
        $d = $this->fetchOne('SELECT d.driver_id, d.user_id, (SELECT COUNT(*) FROM tricycles t WHERE t.driver_id = d.driver_id) AS trikes FROM drivers d WHERE d.driver_id = ?', [$driverId]);
        if (!$d) {
            $this->addError('That driver no longer exists.');
            return false;
        }
        if ((int)$d['trikes'] > 0) {
            $this->addError('This driver still has a tricycle. Delete or reassign the tricycle first, or deactivate the account instead.');
            return false;
        }
        try {
            $this->beginTransaction();
            $this->query('DELETE FROM drivers WHERE driver_id = ?', [$driverId]);
            if ($d['user_id']) {
                $this->query("DELETE FROM users WHERE user_id = ? AND role <> 'admin'", [$d['user_id']]);
            }
            $this->commit();
            return true;
        } catch (PDOException $e) {
            $this->rollback();
            $this->addError($this->friendlyError($e));
            return false;
        }
    }

    /** Driver profile linked to a login account. */
    public function findByUser(int $userId): ?array
    {
        return $this->fetchOne('SELECT driver_id, full_name, contact_no, license_no FROM drivers WHERE user_id = ?', [$userId]);
    }

    /** Registered drivers who do not have a tricycle yet. */
    public function countUnassigned(): int
    {
        return (int)$this->fetchOne(
            'SELECT COUNT(*) AS total FROM drivers d LEFT JOIN tricycles t ON t.driver_id = d.driver_id WHERE t.tricycle_id IS NULL'
        )['total'];
    }

    /** Public details only (name, contact, tricycle): used by the passenger rating page. */
    public function findPublic(int $driverId): ?array
    {
        return $this->fetchOne(
            'SELECT d.driver_id, d.full_name, d.contact_no, t.body_number, t.plate_number
               FROM drivers d LEFT JOIN tricycles t ON t.driver_id = d.driver_id
              WHERE d.driver_id = ?',
            [$driverId]
        );
    }
}
