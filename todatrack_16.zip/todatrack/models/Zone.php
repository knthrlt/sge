<?php
/** Zone: a terminal/origin area with its own color. Managed by the admin. */
class Zone extends BaseModel
{
    private int $id = 0;
    private string $zoneName = '';
    private string $colorName = '';
    private string $colorHex = '';

    protected function table(): string
    {
        return 'zones';
    }

    // ---- getters / setters ----
    public function getId(): int { return $this->id; }
    public function setId(int $id): self { $this->id = $id; return $this; }

    public function getZoneName(): string { return $this->zoneName; }
    public function setZoneName(string $v): self { $this->zoneName = trim($v); return $this; }

    public function getColorName(): string { return $this->colorName; }
    public function setColorName(string $v): self { $this->colorName = trim($v); return $this; }

    public function getColorHex(): string { return $this->colorHex; }
    public function setColorHex(string $v): self { $this->colorHex = strtoupper(trim($v)); return $this; }

    public function validate(array $data): array
    {
        $errors = [];
        $id    = (int)($data['zone_id'] ?? 0);
        $name  = trim($data['zone_name'] ?? '');
        $color = trim($data['color_name'] ?? '');
        $hex   = trim($data['color_hex'] ?? '');

        if ($name === '' || strlen($name) > 50) {
            $errors[] = 'Zone name is required (max 50 characters).';
        }
        if ($color === '' || strlen($color) > 30) {
            $errors[] = 'Color name is required (max 30 characters), for example Red.';
        }
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $hex)) {
            $errors[] = 'Pick a valid color (hex like #D23A36).';
        }
        try {
            if ($name !== '' && $this->isTaken('zone_name', $name, $id, 'zone_id')) {
                $errors[] = 'A zone with that name already exists.';
            }
        } catch (PDOException $e) {
            $errors[] = $this->friendlyError($e);
        }
        return $errors;
    }

    public function create(): bool
    {
        $this->clearErrors();
        try {
            $this->id = $this->insertGetId(
                'INSERT INTO zones (zone_name, color_name, color_hex) VALUES (?, ?, ?)',
                [$this->zoneName, $this->colorName, $this->colorHex],
                'zone_id'
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'A zone with that name already exists.']));
            return false;
        }
    }

    public function update(): bool
    {
        $this->clearErrors();
        try {
            $this->query(
                'UPDATE zones SET zone_name = ?, color_name = ?, color_hex = ? WHERE zone_id = ?',
                [$this->zoneName, $this->colorName, $this->colorHex, $this->id]
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'A zone with that name already exists.']));
            return false;
        }
    }

    public function delete(int $id): bool
    {
        $this->clearErrors();
        try {
            return $this->query('DELETE FROM zones WHERE zone_id = ?', [$id])->rowCount() > 0;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, [
                'fk_delete' => 'This zone still has tricycles or fares. Delete or move them first.',
            ]));
            return false;
        }
    }

    public function all(): array
    {
        return array_map([$this, 'decorate'], $this->fetchAll('SELECT * FROM zones ORDER BY zone_id'));
    }

    public function find(int $id): ?array
    {
        $row = $this->fetchOne('SELECT * FROM zones WHERE zone_id = ?', [$id]);
        return $row ? $this->decorate($row) : null;
    }

    /** Each zone with its number of tricycles, how many are available, and its fares. */
    public function withCounts(): array
    {
        $rows = $this->fetchAll(
            "SELECT z.*,
                    (SELECT COUNT(*) FROM tricycles t WHERE t.zone_id = z.zone_id) AS total,
                    (SELECT COUNT(*) FROM tricycles t JOIN drivers d ON d.driver_id = t.driver_id LEFT JOIN users du ON du.user_id = d.user_id
                      WHERE t.zone_id = z.zone_id AND t.status = 'available' AND COALESCE(du.is_active, TRUE)) AS available,
                    (SELECT COUNT(*) FROM fare_rates f WHERE f.zone_id = z.zone_id) AS fare_count
               FROM zones z
           ORDER BY z.zone_id"
        );
        return array_map([$this, 'decorate'], $rows);
    }

    private function decorate(array $row): array
    {
        $row['text_hex'] = self::contrastColor($row['color_hex']);
        return $row;
    }

    /** Official palette colors that take black text; the other palette colors take white text. */
    private const BLACK_TEXT = ['#DD773F', '#F0CD4F', '#489BDE', '#59AE68', '#99C159', '#E2A77B'];
    private const WHITE_TEXT = ['#D23A36', '#97251F', '#30398A', '#397BA1', '#3F7E3F', '#222329'];

    /**
     * Text color for a zone color. Official palette colors follow the palette rules
     * (Fiesta Orange, Marigold, Sky Blue, Leaf, Lime and Sand take black; the rest take white).
     * Any other color (for example one typed in directly) gets whichever of black or white
     * has the higher WCAG contrast ratio.
     */
    public static function contrastColor(string $hex): string
    {
        $hex = strtoupper('#' . ltrim($hex, '#'));
        if (in_array($hex, self::BLACK_TEXT, true)) {
            return '#000000';
        }
        if (in_array($hex, self::WHITE_TEXT, true)) {
            return '#FFFFFF';
        }
        if (strlen($hex) !== 7) {
            return '#FFFFFF';
        }
        $lin = static function (int $c): float {
            $c /= 255;
            return $c <= 0.03928 ? $c / 12.92 : (($c + 0.055) / 1.055) ** 2.4;
        };
        $lum = 0.2126 * $lin(hexdec(substr($hex, 1, 2))) + 0.7152 * $lin(hexdec(substr($hex, 3, 2))) + 0.0722 * $lin(hexdec(substr($hex, 5, 2)));
        $contrastBlack = ($lum + 0.05) / 0.05;
        $contrastWhite = 1.05 / ($lum + 0.05);
        return $contrastBlack >= $contrastWhite ? '#000000' : '#FFFFFF';
    }
}
