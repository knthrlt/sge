<?php
/** HelpRequest: a driver reports a problem (flat tire, engine, out of fuel, ...). */
class HelpRequest extends BaseModel
{
    public const PROBLEMS = [
        'flat_tire'   => 'Flat tire',
        'engine'      => 'Engine trouble',
        'out_of_fuel' => 'Out of fuel',
        'accident'    => 'Accident',
        'other'       => 'Other problem',
    ];

    public const STATUSES = [
        'open'       => 'Waiting for help',
        'on_the_way' => 'Help is on the way',
        'resolved'   => 'Resolved',
        'cancelled'  => 'Cancelled',
    ];

    private int $id = 0;
    private int $tricycleId = 0;
    private int $locationId = 0;
    private string $problem = '';
    private string $note = '';

    protected function table(): string
    {
        return 'help_requests';
    }

    // ---- getters / setters ----
    public function getId(): int { return $this->id; }
    public function setId(int $v): self { $this->id = $v; return $this; }

    public function getTricycleId(): int { return $this->tricycleId; }
    public function setTricycleId(int $v): self { $this->tricycleId = $v; return $this; }

    public function getLocationId(): int { return $this->locationId; }
    public function setLocationId(int $v): self { $this->locationId = $v; return $this; }

    public function getProblem(): string { return $this->problem; }
    public function setProblem(string $v): self { $this->problem = $v; return $this; }

    public function getNote(): string { return $this->note; }
    public function setNote(string $v): self { $this->note = trim($v); return $this; }

    /** Server-side validation of the Request Help form. */
    public function validate(array $data): array
    {
        $errors = [];
        if (!array_key_exists((string)($data['problem'] ?? ''), self::PROBLEMS)) {
            $errors[] = 'Choose what the problem is.';
        }
        if (strlen(trim((string)($data['note'] ?? ''))) > 255) {
            $errors[] = 'The note is too long (maximum 255 characters).';
        }
        try {
            $loc = (int)($data['location_id'] ?? 0);
            if ($loc <= 0 || !$this->rowExists('locations', 'location_id', $loc)) {
                $errors[] = 'Choose where you are right now.';
            }
        } catch (PDOException $e) {
            $errors[] = $this->friendlyError($e);
        }
        return $errors;
    }

    /**
     * Save the request AND set the tricycle to Off Duty at the reported
     * location, in one transaction, so passengers stop seeing it.
     */
    public function create(): bool
    {
        $this->clearErrors();
        try {
            $this->beginTransaction();
            $this->id = $this->insertGetId(
                'INSERT INTO help_requests (tricycle_id, location_id, problem, note) VALUES (?, ?, ?, ?)',
                [$this->tricycleId, $this->locationId, $this->problem, $this->note === '' ? null : $this->note],
                'request_id'
            );
            $this->query(
                "UPDATE tricycles SET status = 'off_duty', location_id = ? WHERE tricycle_id = ?",
                [$this->locationId, $this->tricycleId]
            );
            $this->commit();
            return true;
        } catch (PDOException $e) {
            $this->rollback();
            $this->addError($this->friendlyError($e, ['unique' => 'You already have an active help request. Cancel it first if you need to send a new one.']));
            return false;
        }
    }

    // ---- reading ----
    private function baseSelect(): string
    {
        return 'SELECT h.request_id, h.problem, h.note, h.status, h.created_at, h.updated_at,
                       h.tricycle_id, t.body_number, t.plate_number,
                       d.full_name AS driver_name, d.contact_no, d.user_id AS driver_user_id,
                       l.location_name, z.zone_name, z.color_hex
                  FROM help_requests h
                  JOIN tricycles t ON t.tricycle_id = h.tricycle_id
                  JOIN drivers d   ON d.driver_id   = t.driver_id
                  JOIN locations l ON l.location_id = h.location_id
                  JOIN zones z     ON z.zone_id     = t.zone_id';
    }

    private function decorate(array $row): array
    {
        $row['problem_label'] = self::PROBLEMS[$row['problem']] ?? $row['problem'];
        $row['status_label']  = self::STATUSES[$row['status']] ?? $row['status'];
        $row['text_hex']      = Zone::contrastColor($row['color_hex']);
        return $row;
    }

    public function find(int $id): ?array
    {
        $row = $this->fetchOne($this->baseSelect() . ' WHERE h.request_id = ?', [$id]);
        return $row ? $this->decorate($row) : null;
    }

    /** Admin list: open and on-the-way requests first, then the newest. */
    public function all(): array
    {
        $rows = $this->fetchAll($this->baseSelect() .
            " ORDER BY CASE h.status WHEN 'open' THEN 0 WHEN 'on_the_way' THEN 1 ELSE 2 END, h.created_at DESC");
        return array_map([$this, 'decorate'], $rows);
    }

    /** A driver's own requests (newest first). */
    public function forDriverUser(int $userId, int $limit = 10): array
    {
        $rows = $this->fetchAll($this->baseSelect() . ' WHERE d.user_id = ? ORDER BY h.created_at DESC LIMIT ' . (int)$limit, [$userId]);
        return array_map([$this, 'decorate'], $rows);
    }

    public function countActive(): int
    {
        return (int)$this->fetchOne("SELECT COUNT(*) AS total FROM help_requests WHERE status IN ('open','on_the_way')")['total'];
    }

    // ---- status changes ----
    /** Driver cancels: allowed only while the request is still "open". */
    public function cancel(int $id): bool
    {
        return $this->query(
            "UPDATE help_requests SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE request_id = ? AND status = 'open'",
            [$id]
        )->rowCount() > 0;
    }

    /** Admin: mark "on_the_way" (from open) or "resolved" (from open / on_the_way). */
    public function setStatus(int $id, string $status): bool
    {
        $from = ['on_the_way' => "('open')", 'resolved' => "('open','on_the_way')"][$status] ?? null;
        if ($from === null) {
            return false;
        }
        return $this->query(
            "UPDATE help_requests SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE request_id = ? AND status IN {$from}",
            [$status, $id]
        )->rowCount() > 0;
    }
}
