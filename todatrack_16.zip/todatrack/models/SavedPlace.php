<?php
/** SavedPlace: a destination a passenger saved (for example "Home" or "School"). */
class SavedPlace extends BaseModel
{
    public const MAX_PER_USER = 10;

    private int $userId = 0;
    private int $locationId = 0;
    private string $label = '';

    protected function table(): string
    {
        return 'saved_places';
    }

    public function setUserId(int $v): self { $this->userId = $v; return $this; }
    public function getUserId(): int { return $this->userId; }

    public function setLocationId(int $v): self { $this->locationId = $v; return $this; }
    public function getLocationId(): int { return $this->locationId; }

    public function setLabel(string $v): self { $this->label = trim($v); return $this; }
    public function getLabel(): string { return $this->label; }

    public function validate(array $data): array
    {
        $errors = [];
        $user   = (int)($data['user_id'] ?? 0);
        $loc    = (int)($data['location_id'] ?? 0);
        $label  = trim((string)($data['label'] ?? ''));

        if (strlen($label) > 30) {
            $errors[] = 'The label is too long (maximum 30 characters).';
        }
        try {
            if ($loc <= 0 || !$this->rowExists('locations', 'location_id', $loc)) {
                $errors[] = 'Choose a destination.';
            } elseif ($this->fetchOne('SELECT 1 FROM saved_places WHERE user_id = ? AND location_id = ? LIMIT 1', [$user, $loc])) {
                $errors[] = 'You already saved that destination.';
            }
            $count = (int)$this->fetchOne('SELECT COUNT(*) AS total FROM saved_places WHERE user_id = ?', [$user])['total'];
            if ($count >= self::MAX_PER_USER) {
                $errors[] = 'You can save up to ' . self::MAX_PER_USER . ' destinations. Remove one first.';
            }
        } catch (PDOException $e) {
            $errors[] = $this->friendlyError($e);
        }
        return $errors;
    }

    public function create(): bool
    {
        $this->clearErrors();
        try {
            $this->query(
                'INSERT INTO saved_places (user_id, location_id, label) VALUES (?, ?, ?)',
                [$this->userId, $this->locationId, $this->label === '' ? null : $this->label]
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'You already saved that destination.']));
            return false;
        }
    }

    /** Delete one of the passenger's own saved places. */
    public function delete(int $savedId, int $userId): bool
    {
        return $this->query('DELETE FROM saved_places WHERE saved_id = ? AND user_id = ?', [$savedId, $userId])->rowCount() > 0;
    }

    /** The passenger's saved places with the cheapest fare and how many tricycles are free now. */
    public function forUser(int $userId): array
    {
        return $this->fetchAll(
            "SELECT s.saved_id, s.label, l.location_id, l.location_name,
                    (SELECT MIN(f.fare) FROM fare_rates f WHERE f.location_id = l.location_id) AS from_fare,
                    (SELECT COUNT(*) FROM tricycles t
                      WHERE t.status = 'available'
                        AND t.zone_id IN (SELECT f.zone_id FROM fare_rates f WHERE f.location_id = l.location_id)) AS available_count
               FROM saved_places s
               JOIN locations l ON l.location_id = s.location_id
              WHERE s.user_id = ?
           ORDER BY s.created_at DESC",
            [$userId]
        );
    }

    /** Ids of the locations this passenger saved (to hide the "save" button). */
    public function locationIds(int $userId): array
    {
        return array_map('intval', array_column(
            $this->fetchAll('SELECT location_id FROM saved_places WHERE user_id = ?', [$userId]),
            'location_id'
        ));
    }
}
