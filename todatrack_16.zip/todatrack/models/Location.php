<?php
/** Location: a place a tricycle can be at, or a passenger can go to. Managed by the admin. */
class Location extends BaseModel
{
    private int $id = 0;
    private string $locationName = '';

    protected function table(): string
    {
        return 'locations';
    }

    // ---- getters / setters ----
    public function getId(): int { return $this->id; }
    public function setId(int $id): self { $this->id = $id; return $this; }

    public function getLocationName(): string { return $this->locationName; }
    public function setLocationName(string $v): self { $this->locationName = trim($v); return $this; }

    public function validate(array $data): array
    {
        $errors = [];
        $id   = (int)($data['location_id'] ?? 0);
        $name = trim($data['location_name'] ?? '');

        if ($name === '' || strlen($name) > 80) {
            $errors[] = 'Location name is required (max 80 characters).';
        } else {
            try {
                if ($this->isTaken('location_name', $name, $id, 'location_id')) {
                    $errors[] = 'A location with that name already exists.';
                }
            } catch (PDOException $e) {
                $errors[] = $this->friendlyError($e);
            }
        }
        return $errors;
    }

    public function create(): bool
    {
        $this->clearErrors();
        try {
            $this->id = $this->insertGetId(
                'INSERT INTO locations (location_name) VALUES (?)',
                [$this->locationName],
                'location_id'
            );
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'A location with that name already exists.']));
            return false;
        }
    }

    public function update(): bool
    {
        $this->clearErrors();
        try {
            $this->query('UPDATE locations SET location_name = ? WHERE location_id = ?', [$this->locationName, $this->id]);
            return true;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, ['unique' => 'A location with that name already exists.']));
            return false;
        }
    }

    public function delete(int $id): bool
    {
        $this->clearErrors();
        try {
            return $this->query('DELETE FROM locations WHERE location_id = ?', [$id])->rowCount() > 0;
        } catch (PDOException $e) {
            $this->addError($this->friendlyError($e, [
                'fk_delete' => 'This location is still used by a fare or a tricycle. Change those first.',
            ]));
            return false;
        }
    }

    public function all(): array
    {
        return $this->fetchAll('SELECT * FROM locations ORDER BY location_name');
    }

    /** Locations with how many fares and tricycles use them (for the admin page). */
    public function withUsage(): array
    {
        return $this->fetchAll(
            'SELECT l.*,
                    (SELECT COUNT(*) FROM fare_rates f WHERE f.location_id = l.location_id) AS fare_count,
                    (SELECT COUNT(*) FROM tricycles t WHERE t.location_id = l.location_id) AS tricycle_count
               FROM locations l
           ORDER BY l.location_name'
        );
    }
}
