<?php
/** Escape output (prevents XSS). */
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/** Build an internal link, e.g. url('tricycles', ['zone' => 2]). */
function url(string $page = '', array $params = []): string
{
    $query = $page !== '' ? ['page' => $page] + $params : $params;
    return 'index.php' . ($query ? '?' . http_build_query($query) : '');
}

/** Format an amount in pesos. */
function peso($amount): string
{
    return '₱' . number_format((float)$amount, 2);
}

/** Account label shown in the navbar and dashboard: Admin, Driver, or Passenger. */
function account_label(?array $user): string
{
    $type = $user['type'] ?? (($user['role'] ?? '') === 'admin' ? 'admin' : 'passenger');
    return ['admin' => 'Admin', 'driver' => 'Driver'][$type] ?? 'Passenger';
}

/** URL of a static file with a version number, so browsers load the newest CSS/JS after an update. */
function asset(string $path): string
{
    $file = __DIR__ . '/../' . $path;
    return $path . (is_file($file) ? '?v=' . filemtime($file) : '');
}

/** Star rating text, for example "★ 4.5 (3)", or a note when nobody rated yet. */
function rating_text(?array $summary): string
{
    if (!$summary || (int)$summary['count'] === 0) {
        return 'No ratings yet';
    }
    return '★ ' . number_format((float)$summary['avg'], 1) . ' (' . (int)$summary['count'] . ')';
}

/** Discount label for a passenger, for example "Student", or '' when none is set. */
function discount_label(?string $type): string
{
    return User::DISCOUNT_TYPES[$type ?? ''] ?? '';
}

/** Inline line icon (24x24, uses the current text color). Names: see the list below. */
function icon(string $name, string $class = 'ico'): string
{
    static $paths = [
        'grid'    => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
        'trike'   => '<circle cx="6" cy="17" r="2.5"/><circle cx="19" cy="17" r="2.5"/><path d="M2.5 15v-4a1.5 1.5 0 0 1 1.5-1.5h6.5a2 2 0 0 1 2 2V15M13 14h3l2-4h3M17 8h3"/>',
        'peso'    => '<path d="M8 20V5h5a3.5 3.5 0 0 1 0 7H8"/><path d="M5 9h12M5 12h12"/>',
        'alert'   => '<path d="M12 3 2.5 20h19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
        'map'     => '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
        'pin'     => '<path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
        'user'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
        'users'   => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 14.5a5.5 5.5 0 0 1 4.5 5.5"/>',
        'star'    => '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.2 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/>',
        'heart'   => '<path d="M12 20s-8-4.7-8-10.5A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 8 2.5C20 15.3 12 20 12 20z"/>',
        'bookmark'=> '<path d="M6 3h12v18l-6-4-6 4z"/>',
        'logout'  => '<path d="M9 4H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4"/><path d="m16 8 4 4-4 4M20 12H9"/>',
        'sun'     => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
        'moon'    => '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
        'clock'   => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'plus'    => '<path d="M12 5v14M5 12h14"/>',
        'check'   => '<path d="m5 12 5 5 9-10"/>',
        'power'   => '<path d="M12 3v8"/><path d="M6.3 7.2a8 8 0 1 0 11.4 0"/>',
        'chat'    => '<path d="M4 5h16v11H9l-5 4z"/>',
    ];
    return '<svg class="' . $class . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
         . ($paths[$name] ?? '') . '</svg>';
}

/** Dashboard statistic tile. $tone: indigo (admin), red (driver), sky (passenger). $hl = solid highlighted tile. */
function dash_tile(string $label, $value, string $sub, string $tone, string $ico, bool $hl = false, ?string $href = null): string
{
    $tag  = $href ? 'a' : 'div';
    $attr = $href ? ' href="' . e($href) . '"' : '';
    return '<' . $tag . ' class="dstat tn-' . e($tone) . ($hl ? ' hl' : '') . ($href ? ' is-link' : '') . '"' . $attr . '>'
         . '<span class="lbl">' . e($label) . '</span><span class="ico-chip">' . icon($ico) . '</span>'
         . '<span class="num">' . e((string)$value) . '</span><span class="sub">' . e($sub) . '</span></' . $tag . '>';
}

/** Star row for ratings, for example ★★★☆☆ (filled stars in accent color). */
function star_row(int $stars): string
{
    $stars = max(0, min(5, $stars));
    return '<span class="stars" role="img" aria-label="' . $stars . ' out of 5 stars">' . str_repeat('★', $stars) . '<span class="stars-off">' . str_repeat('★', 5 - $stars) . '</span></span>';
}
