<?php
/**
 * Database
 * Base class that opens the PDO connection to PostgreSQL.
 * The connection settings (host, port, user, password) are in config/config.php.
 * Every model extends this class (inheritance).
 */
class Database
{
    /** One shared connection for the whole request. */
    private static ?PDO $shared = null;

    protected ?PDO $conn = null;

    public function connect(): PDO
    {
        if (self::$shared instanceof PDO) {
            return $this->conn = self::$shared;
        }

        if (!in_array('pgsql', PDO::getAvailableDrivers(), true)) {
            throw new RuntimeException(
                'The PHP extension pdo_pgsql is not enabled. In Laragon: Menu > PHP > Extensions > pdo_pgsql, then restart Apache.'
            );
        }

        $s = require __DIR__ . '/config.php';
        $dsn = "pgsql:host={$s['host']};port={$s['port']};dbname={$s['dbname']}";

        try {
            self::$shared = new PDO($dsn, $s['user'], $s['password'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // errors throw exceptions
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,                    // real prepared statements
            ]);
        } catch (PDOException $e) {
            error_log('[TodaTrack] DB connection failed: ' . $e->getMessage());
            $message = 'Cannot connect to the database. Open config/config.php and check the PostgreSQL password, port, and database name, '
                     . 'and make sure PostgreSQL is running (open db_check.php for a step-by-step test).';
            // Technical details are shown only when you open the site on your own computer.
            if (in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) {
                $message .= ' Details: ' . $e->getMessage();
            }
            throw new RuntimeException($message);
        }

        return $this->conn = self::$shared;
    }
}
