<?php
/**
 * ============================================================
 *  EDIT THIS FILE: your PostgreSQL connection settings
 * ============================================================
 *  user     = the PostgreSQL login role created for this app (toda_user)
 *  password = the password you gave toda_user in pgAdmin
 *             (Login/Group Roles > toda_user).
 *  Avoid a quote ' or a backslash \ in the password; if you use one,
 *  put a backslash in front of it.
 *
 *  After saving, open  http://localhost/todatrack/db_check.php
 *  to test the connection.
 */
return [
    'host'     => '127.0.0.1',
    'port'     => 5432,
    'dbname'   => 'todatrack_db',
    'user'     => 'toda_user',
    'password' => 'Toda@2026',
];
