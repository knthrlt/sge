<?php
/**
 * TodaTrack front controller.
 * Every request goes through here: index.php?page=<route>
 */
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

require_once __DIR__ . '/config/helpers.php';

// Load a class from config/, models/ or controllers/ when it is first used.
spl_autoload_register(function (string $class): void {
    foreach (['config', 'models', 'controllers'] as $dir) {
        $file = __DIR__ . "/{$dir}/{$class}.php";
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
});

// route => [controller, method]
$routes = [
    'home'            => ['HomeController', 'index'],
    'login'           => ['AuthController', 'login'],
    'register'        => ['AuthController', 'register'],
    'logout'          => ['AuthController', 'logout'],
    'dashboard'       => ['DashboardController', 'index'],
    'find'            => ['TricycleController', 'find'],
    'tricycles'       => ['TricycleController', 'index'],
    'tricycle_form'   => ['TricycleController', 'form'],
    'tricycle_save'   => ['TricycleController', 'save'],
    'tricycle_delete' => ['TricycleController', 'delete'],
    'fares'           => ['FareController', 'index'],
    'fare_save'       => ['FareController', 'save'],
    'fare_delete'     => ['FareController', 'delete'],
    'zones'           => ['ZoneController', 'index'],
    'zone_save'       => ['ZoneController', 'save'],
    'zone_delete'     => ['ZoneController', 'delete'],
    'locations'       => ['LocationController', 'index'],
    'location_save'   => ['LocationController', 'save'],
    'location_delete' => ['LocationController', 'delete'],
    'drivers'         => ['DriverController', 'index'],
    'driver_status'   => ['DriverController', 'status'],
    'driver_delete'   => ['DriverController', 'delete'],
    'passengers'      => ['PassengerController', 'adminIndex'],
    'passenger_status'=> ['PassengerController', 'adminStatus'],
    'passenger_delete'=> ['PassengerController', 'adminDelete'],
    'help'            => ['HelpController', 'form'],
    'help_save'       => ['HelpController', 'save'],
    'help_cancel'     => ['HelpController', 'cancel'],
    'help_requests'   => ['HelpController', 'index'],
    'help_update'     => ['HelpController', 'update'],
    // passenger features
    'profile'         => ['PassengerController', 'profile'],
    'profile_save'    => ['PassengerController', 'profileSave'],
    'places'          => ['PassengerController', 'places'],
    'place_save'      => ['PassengerController', 'placeSave'],
    'place_delete'    => ['PassengerController', 'placeDelete'],
    'favorites'       => ['PassengerController', 'favorites'],
    'favorite_toggle' => ['PassengerController', 'favoriteToggle'],
    'rate'            => ['PassengerController', 'rate'],
    'rate_save'       => ['PassengerController', 'rateSave'],
    // admin: moderate ratings
    'ratings'         => ['RatingController', 'index'],
    'rating_update'   => ['RatingController', 'update'],
    'rating_delete'   => ['RatingController', 'delete'],
];

// Visitors start on the landing page; logged-in users start on their dashboard.
$page = (string)($_GET['page'] ?? (!empty($_SESSION['user']) ? 'dashboard' : 'home'));
$_GET['page'] = $page;

try {
    if (!isset($routes[$page])) {
        (new ErrorController())->show(404, 'The page you are looking for does not exist.');
        exit;
    }
    [$controllerName, $method] = $routes[$page];
    (new $controllerName())->$method();
} catch (RuntimeException $e) {
    // Our own friendly messages (for example: database not reachable).
    (new ErrorController())->show(500, $e->getMessage());
} catch (Throwable $e) {
    error_log('[TodaTrack] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    (new ErrorController())->show(500, 'Something went wrong. Please try again.');
}
