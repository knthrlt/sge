# TodaTrack: Tricycle Zone Monitoring System

Final project for WST1, OOP & ADS. PHP (MVC + OOP, PDO), Bootstrap 5, DataTables, JavaScript.
Database: **PostgreSQL** (managed with pgAdmin, running from Laragon).

## Setup
1. In Laragon, start Apache and PostgreSQL. Make sure the PHP extension **pdo_pgsql** is enabled (Laragon menu > PHP > Extensions > pdo_pgsql).
2. **Create the login role** `toda_user`: pgAdmin > Login/Group Roles > Create > Login/Group Role (Name `toda_user`, set a password, Can login = Yes, everything else No), or run `database/0_create_role_pgsql.sql` after changing its password.
3. In pgAdmin, connected to the `postgres` database, run: `CREATE DATABASE todatrack_db;`
4. Query Tool on `todatrack_db` (as `postgres`): run `database/1_schema_pgsql.sql` (tables + the admin account).
5. (Optional) run `database/2_optional_reference_data_pgsql.sql` once for the sample zones, locations, and fares.
6. Same Query Tool: run `database/3_grant_privileges_pgsql.sql` so `toda_user` can use the tables.
7. Open `config/config.php` and replace `PUT_TODA_USER_PASSWORD_HERE` with the password you gave `toda_user`.
8. Copy the `todatrack` folder to `C:\laragon\www\` and open `http://localhost/todatrack/db_check.php`. Every line should say OK. Then open `http://localhost/todatrack/`.

Always run the schema as `postgres`: `toda_user` can only read and write data, it cannot create or drop tables.

Bootstrap, jQuery, and DataTables are in `assets/vendor`, so no internet is needed.

Already ran an older schema? Do not re-run it (it drops the tables). Instead run these once, as `postgres`, on `todatrack_db`, in this order:
1. `database/4_add_help_requests_pgsql.sql` (Request Help table). Skip it if you already ran it.
2. `database/5_add_passenger_features_pgsql.sql` (passenger discount type, saved places, favorite drivers, ratings, and the consent column). Safe to run twice.
3. `database/7_add_account_status_pgsql.sql` (adds `users.is_active` for Deactivate/Reactivate). Safe to run twice.
4. `database/8_add_anonymous_ratings_pgsql.sql` (adds the anonymous-rating setting). Safe to run twice.
5. `database/10_reset_accounts_and_role_pgsql.sql` (deletes existing non-admin accounts, driver profiles, tricycles, and related data; enables direct `admin`/`driver`/`passenger` roles). It restarts identity sequences for emptied tables without changing existing IDs; the shared `users` sequence continues after the retained admin. **Run once only, and only if you intend this reset.**
6. `database/11_create_passenger_admin_profiles_pgsql.sql` (creates passenger/admin profiles and moves passenger discount data). Run once after migration 10; empty profile IDs start at 1.
7. (Optional) `UPDATE zones SET color_name = 'Yellow', color_hex = '#F0CD4F' WHERE zone_name = 'Old Sagay';`, or change the color on the admin Zones page.
8. `database/12_update_zone_palette_pgsql.sql` (moves the existing zone colors to the official TodaTrack palette). Safe to run twice; skip it on a fresh install that used the updated `2_optional_reference_data_pgsql.sql`.

Migrations 4, 5, 8, and 11 grant `toda_user` access to the tables they add or update.
Back up an existing database before running migration 10; it deletes accounts and related data. The fresh schema already has all three roles and both profile tables, so existing-database migrations are not needed for a new install.

## Accounts and roles
Visitors need no account. People who want more create one on the **Register** page and pick **Passenger** or **Driver** (both must agree to the Data Privacy Notice; the time is saved in `users.consented_at`). The account role is stored directly in `users.role` as `passenger` or `driver`; admins use `admin`.

| | Guest (no account) | Passenger | Driver | Admin |
|---|---|---|---|---|
| Landing page, Find a Tricycle, Fare Guide | view | view | view (Find is replaced by Request Help in the menu) | view |
| Dashboard | landing page | quick find, saved places, favorite drivers, discount | my tricycle, rating, passenger feedback, anonymous favorite list with added dates and count | totals, alerts, latest help requests and ratings |
| Saved places (up to 10), favorite drivers, rate drivers, fare discount (student / senior / PWD) | - | yes | - | - |
| Update own location and status, Request Help | - | - | yes | - |
| Tricycles, Fare Guide edit, Zones, Locations, Drivers | - | - | own tricycle only | full control |
| Help Requests ("Help is on the way" / "Resolved") | - | - | send / cancel own | manage all |
| Ratings (hide, show, delete) | - | - | views visible ratings and comments (anonymous names stay hidden) | moderates all and can see submitter account details |

- **Seeded admin:** `admin` / `Admin@2026`.
- **Admin accounts are created in the database only.** The Register page has no admin option, and the server rejects it. To add another admin, edit and run `database/6_create_admin_account_pgsql.sql` in pgAdmin (it hashes the password with bcrypt). Change the seeded `admin` password after your first login.
- **Driver accounts (Admin > Manage > Drivers):** *Deactivate* is the safe, reversible choice (the driver cannot log in, is logged out at once, and the tricycle is set Off Duty and hidden from passengers; ratings are kept; *Reactivate* restores access). *Delete* is permanent and only offered for a driver without a tricycle (for example a mistaken registration). Both ask for confirmation. **Run `database/7_add_account_status_pgsql.sql` once** (as postgres, on `todatrack_db`) to add the `users.is_active` column; new installs get it from `1_schema_pgsql.sql`.
- **Passenger accounts (Admin > Manage > Passengers):** admins can view name, username, email, discount, registration date, and status; deactivate/reactivate or permanently delete a passenger. Passwords and password hashes are never displayed. Deleting permanently removes linked passenger records; deactivate to keep them.
- **Find a Tricycle:** an *Available now* list shows every tricycle whose status is Available (a deactivated driver never shows), with zone filter chips and a 30-second live refresh.
- **Availability by zone cards** are links: guests and passengers go to the Find page filtered to that zone; drivers and admin go to the Tricycles list filtered to that zone.
- `users.role` stores each account type directly as `admin`, `driver`, or `passenger`; each account has a linked role profile. Driver dashboards show visible reviews and passenger feedback; a review marked anonymous never exposes the passenger's name to drivers or other users. The favorites list shows anonymous entries only, never passenger identities. Admins can see the submitter account details when moderating ratings. Passengers see driver names and average ratings on Find a Tricycle.

Everything the admin adds is stored in the database, so users see it immediately. A tricycle needs a zone, a location, and a registered driver without a tricycle.

## Design
A modern, professional look based on the project references: warm cream surfaces, near-black Anton headlines, green pill buttons, flat rounded cards, and a centered landing page with zone cards that hang from a string (each card is a link). The colors come from the project palette (black, dark green, green, red, orange-red, sky blue, amber, cream). The system logo is `assets/img/logo.png` (also the favicon). **Display settings** (the `Aa` button in the top bar) let anyone pick text size (Normal, Large, Extra large) and theme (Light, Dark, Auto), plus a quick moon/sun toggle. The choice is remembered in the browser (`assets/js/prefs.js`). Fonts (Anton, Source Sans 3, both open license) are in `assets/fonts`, so no internet is needed.

## Folder structure (MVC)
```
config/       config.php (toda_user password), Database.php (base class, PDO connection to PostgreSQL), helpers.php
models/       BaseModel.php (abstract) > User, Zone, Location, Driver, Tricycle, FareRate, HelpRequest, SavedPlace, FavoriteDriver, DriverRating
controllers/  BaseController.php > Home, Auth, Dashboard, Tricycle, Fare, Zone, Location, Driver, Help, Passenger, Rating, Error
views/        *_view.php (display only) + header_view.php / footer_view.php
assets/       css/style.css, js/app.js, fonts/, img/ (SVG art), vendor/ (Bootstrap, jQuery, DataTables)
database/     schema, optional reference data, grants, and migrations (all *_pgsql.sql)
index.php     front controller: index.php?page=...
```

## Requirements checklist (FINAL-PROJECT-GUIDELINES)
- **UI:** Bootstrap layout, responsive navbar, color-coded zone and status badges
- **Forms:** Login, Register, Add/Edit Tricycle (plus small add/edit modals for the admin's zones, locations, and fares)
- **CRUD:** Tricycles (main module), plus Zones, Locations, and Fares for the admin
- **Validations:** JavaScript (`assets/js/app.js` + HTML5 patterns), PHP (each model's `validate()`), database (NOT NULL, UNIQUE, FK, CHECK)
- **Error handling:** prepared statements, `PDOException` caught in models and turned into friendly messages (`BaseModel::friendlyError`), error pages for 403/404/419/500
- **Confirmations:** Bootstrap modal for save, update, and delete
- **Search + filter:** DataTables search; filters by zone and status; "Find a Tricycle" searches by destination
- **MVC + OOP:** controllers have no HTML, models hold the data logic and validation, views only display. Naming: `NameController.php`, `Name.php`, `name_view.php`
- **OOP principles:** classes/objects, private properties with getters/setters, inheritance (`Database` > `BaseModel` > models; `BaseController` > controllers), polymorphism (every model overrides the abstract `validate()` and `table()`)

## Database (3NF)
`users`, `admins`, `passengers`, `zones`, `locations`, `fare_rates`, `drivers`, `tricycles`, `help_requests`, `saved_places`, `favorite_drivers`, `driver_ratings`
- **1NF:** atomic columns, primary key in every table.
- **2NF:** no partial dependencies (a fare depends on the whole zone + location pair).
- **3NF:** no transitive dependencies. Shared login details live in `users`; role-specific profiles live in `admins`, `drivers`, and `passengers`; passenger discount lives in `passengers`. Zone name/color live only in `zones`, place names only in `locations`. The student/senior/PWD fare is computed (20% off), not stored.
- Relationships: `admins`, `passengers`, and `drivers` are each 1:1 role profiles linked to `users`; passenger fare discount lives in `passengers`. `saved_places` N:1 `users`, `locations`; `favorite_drivers` is the M:N link between `users` and `drivers`; `driver_ratings` N:1 `users`, `drivers` (one rating per passenger and driver); `help_requests` N:1 `tricycles`, `locations`; `tricycles` N:1 `drivers`, `zones`, `locations`; `fare_rates` N:1 `zones`, `locations`.
