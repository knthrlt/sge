<?php
/** Admin: manage zones (name + color). */
class ZoneController extends BaseController
{
    public function index(): void
    {
        $this->requireAdmin();
        $this->render('zone', [
            'pageTitle' => 'Zones',
            'zones'     => (new Zone())->withCounts(),
        ]);
    }

    public function save(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('zones');
        }
        $this->verifyCsrf();

        $data = [
            'zone_id'    => (int)($_POST['zone_id'] ?? 0),
            'zone_name'  => $this->input('zone_name'),
            'color_name' => $this->input('color_name'),
            'color_hex'  => $this->input('color_hex'),
        ];

        $zone   = new Zone();
        $errors = $zone->validate($data);

        if (!$errors) {
            $zone->setId($data['zone_id'])
                 ->setZoneName($data['zone_name'])
                 ->setColorName($data['color_name'])
                 ->setColorHex($data['color_hex']);
            $saved = $data['zone_id'] > 0 ? $zone->update() : $zone->create();
            if ($saved) {
                $this->flash('success', $data['zone_id'] > 0 ? 'Zone updated.' : 'Zone added.');
                $this->redirect('zones');
            }
            $errors = $zone->getErrors();
        }

        $this->flashErrors($errors);
        $this->redirect('zones');
    }

    public function delete(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('zones');
        }
        $this->verifyCsrf();

        $zone = new Zone();
        if ($zone->delete((int)($_POST['zone_id'] ?? 0))) {
            $this->flash('success', 'Zone deleted.');
        } else {
            $this->flash('danger', implode(' ', $zone->getErrors()) ?: 'That zone was not found.');
        }
        $this->redirect('zones');
    }
}
