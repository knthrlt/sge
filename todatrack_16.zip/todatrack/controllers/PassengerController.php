<?php
/** Passenger-only features: profile (discount type), saved places, favorite drivers, rating drivers. */
class PassengerController extends BaseController
{
    // ---------- admin passenger management ----------
    public function adminIndex(): void
    {
        $this->requireAdmin();
        $this->render('passengers_admin', [
            'pageTitle'  => 'Passengers',
            'passengers' => (new User())->allPassengersForAdmin(),
            'discounts'  => User::DISCOUNT_TYPES,
        ]);
    }

    public function adminStatus(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('passengers');
        }
        $this->verifyCsrf();

        $active = ($_POST['active'] ?? '') === '1';
        $user = new User();
        if ($user->setPassengerActive((int)($_POST['user_id'] ?? 0), $active)) {
            $this->flash('success', $active
                ? 'Passenger account reactivated.'
                : 'Passenger account deactivated. The passenger can no longer log in.');
        } else {
            $this->flashErrors($user->getErrors());
        }
        $this->redirect('passengers');
    }

    public function adminDelete(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('passengers');
        }
        $this->verifyCsrf();

        $user = new User();
        if ($user->deletePassengerAccount((int)($_POST['user_id'] ?? 0))) {
            $this->flash('success', 'Passenger account deleted permanently.');
        } else {
            $this->flashErrors($user->getErrors());
        }
        $this->redirect('passengers');
    }

    // ---------- profile ----------
    public function profile(): void
    {
        $this->requirePassenger();
        $profile = (new User())->findProfile((int)$this->currentUser()['id']);
        $this->render('profile', [
            'pageTitle'  => 'My Profile',
            'profile'    => $profile,
            'discounts'  => User::DISCOUNT_TYPES,
            'discountPct' => (int)(FareRate::DISCOUNT_RATE * 100),
        ]);
    }

    public function profileSave(): void
    {
        $this->requirePassenger();
        if (!$this->isPost()) {
            $this->redirect('profile');
        }
        $this->verifyCsrf();

        $id       = (int)$this->currentUser()['id'];
        $name     = $this->input('full_name');
        $discount = $this->input('discount_type');
        $user     = new User();

        if ($user->updateProfile($id, $name, $discount)) {
            $_SESSION['user']['full_name'] = trim($name);
            $_SESSION['user']['discount']  = $discount === '' ? null : $discount;
            $this->flash('success', 'Profile saved.');
        } else {
            $this->flashErrors($user->getErrors());
        }
        $this->redirect('profile');
    }

    // ---------- saved places ----------
    public function places(): void
    {
        $this->requirePassenger();
        $userId = (int)$this->currentUser()['id'];
        $saved  = new SavedPlace();
        $this->render('places', [
            'pageTitle' => 'Saved Places',
            'places'    => $saved->forUser($userId),
            'locations' => (new Location())->all(),
            'max'       => SavedPlace::MAX_PER_USER,
        ]);
    }

    public function placeSave(): void
    {
        $this->requirePassenger();
        if (!$this->isPost()) {
            $this->redirect('places');
        }
        $this->verifyCsrf();

        $userId = (int)$this->currentUser()['id'];
        $data   = ['user_id' => $userId, 'location_id' => $this->input('location_id'), 'label' => $this->input('label')];
        $place  = new SavedPlace();
        $errors = $place->validate($data);

        if (!$errors) {
            $place->setUserId($userId)->setLocationId((int)$data['location_id'])->setLabel($data['label']);
            if ($place->create()) {
                $this->flash('success', 'Destination saved.');
                $this->redirectBack('places');
            }
            $errors = $place->getErrors();
        }
        $this->flashErrors($errors);
        $this->redirectBack('places');
    }

    public function placeDelete(): void
    {
        $this->requirePassenger();
        if (!$this->isPost()) {
            $this->redirect('places');
        }
        $this->verifyCsrf();

        if ((new SavedPlace())->delete((int)($_POST['saved_id'] ?? 0), (int)$this->currentUser()['id'])) {
            $this->flash('success', 'Destination removed.');
        } else {
            $this->flash('warning', 'That saved place was not found.');
        }
        $this->redirectBack('places');
    }

    // ---------- favorite drivers ----------
    public function favorites(): void
    {
        $this->requirePassenger();
        $this->render('favorites', [
            'pageTitle' => 'Favorite Drivers',
            'favorites' => (new FavoriteDriver())->forUser((int)$this->currentUser()['id']),
            'ratings'   => (new DriverRating())->summaries(),
        ]);
    }

    public function favoriteToggle(): void
    {
        $this->requirePassenger();
        if (!$this->isPost()) {
            $this->redirect('favorites');
        }
        $this->verifyCsrf();

        $fav    = new FavoriteDriver();
        $errors = $fav->validate(['driver_id' => (int)($_POST['driver_id'] ?? 0)]);
        if ($errors) {
            $this->flashErrors($errors);
        } else {
            $added = $fav->toggle((int)$this->currentUser()['id'], (int)$_POST['driver_id']);
            $this->flash('success', $added ? 'Added to your favorite drivers.' : 'Removed from your favorite drivers.');
        }
        $this->redirectBack('favorites');
    }

    // ---------- rating a driver ----------
    public function rate(): void
    {
        $this->requirePassenger();
        $driverId = (int)($_GET['driver_id'] ?? 0);
        $driver   = $this->findDriver($driverId);
        $mine     = (new DriverRating())->mine((int)$this->currentUser()['id'], $driverId);

        $this->showRateForm($driver, [
            'stars' => (int)($mine['stars'] ?? 0),
            'comment' => (string)($mine['comment'] ?? ''),
            'is_anonymous' => (bool)($mine['is_anonymous'] ?? false),
        ], [], (bool)$mine);
    }

    public function rateSave(): void
    {
        $this->requirePassenger();
        if (!$this->isPost()) {
            $this->redirect('favorites');
        }
        $this->verifyCsrf();

        $userId   = (int)$this->currentUser()['id'];
        $driverId = (int)($_POST['driver_id'] ?? 0);
        $driver   = $this->findDriver($driverId);
        $data     = [
            'driver_id' => $driverId,
            'stars' => (int)($_POST['stars'] ?? 0),
            'comment' => $this->input('comment'),
            'is_anonymous' => isset($_POST['is_anonymous']),
        ];

        $rating = new DriverRating();
        $errors = $rating->validate($data);
        if (!$errors) {
            $rating->setUserId($userId)->setDriverId($driverId)->setStars($data['stars'])
                   ->setComment($data['comment'])->setAnonymous($data['is_anonymous']);
            if ($rating->save()) {
                $this->flash('success', 'Thank you! Your rating was saved.');
                $this->redirectBack('favorites');
            }
            $errors = $rating->getErrors();
        }
        $this->showRateForm($driver, $data, $errors, (bool)$rating->mine($userId, $driverId));
    }

    // ---------- helpers ----------
    private function findDriver(int $driverId): array
    {
        $row = (new Driver())->findPublic($driverId);
        if (!$row) {
            $this->flash('warning', 'That driver was not found.');
            $this->redirect('favorites');
        }
        return $row;
    }

    private function showRateForm(array $driver, array $values, array $errors, bool $editing): void
    {
        $this->render('rate', [
            'pageTitle' => 'Rate a Driver',
            'driver'    => $driver,
            'values'    => $values,
            'errors'    => $errors,
            'editing'   => $editing,
            'returnTo'  => (string)($_POST['return_to'] ?? $_GET['return_to'] ?? url('favorites')),
        ]);
    }
}
