<?php
/** Admin: manage locations (barangays, sitios, landmarks). */
class LocationController extends BaseController
{
    public function index(): void
    {
        $this->requireAdmin();
        $this->render('location', [
            'pageTitle'  => 'Locations',
            'locations'  => (new Location())->withUsage(),
        ]);
    }

    public function save(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('locations');
        }
        $this->verifyCsrf();

        $data = [
            'location_id'   => (int)($_POST['location_id'] ?? 0),
            'location_name' => $this->input('location_name'),
        ];

        $location = new Location();
        $errors   = $location->validate($data);

        if (!$errors) {
            $location->setId($data['location_id'])->setLocationName($data['location_name']);
            $saved = $data['location_id'] > 0 ? $location->update() : $location->create();
            if ($saved) {
                $this->flash('success', $data['location_id'] > 0 ? 'Location updated.' : 'Location added.');
                $this->redirect('locations');
            }
            $errors = $location->getErrors();
        }

        $this->flashErrors($errors);
        $this->redirect('locations');
    }

    public function delete(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('locations');
        }
        $this->verifyCsrf();

        $location = new Location();
        if ($location->delete((int)($_POST['location_id'] ?? 0))) {
            $this->flash('success', 'Location deleted.');
        } else {
            $this->flash('danger', implode(' ', $location->getErrors()) ?: 'That location was not found.');
        }
        $this->redirect('locations');
    }
}
