<?php
/** Dashboard: a different page for each account type (admin, driver, passenger). */
class DashboardController extends BaseController
{
    public function index(): void
    {
        $this->requireLogin();

        $user     = $this->currentUser();
        $type     = $user['role'] ?? ($user['type'] ?? 'passenger');
        $statuses = (new Tricycle())->statusCounts();

        $data = [
            'pageTitle' => 'Dashboard',
            'zones'     => (new Zone())->withCounts(),
            'statuses'  => $statuses,
            'total'     => array_sum($statuses),
            'labels'    => Tricycle::STATUSES,
        ];

        if ($type === 'admin') {
            $help = new HelpRequest();
            $data += [
                'accounts'      => (new User())->countByType(),
                'waiting'       => (new Driver())->countUnassigned(),
                'helpCount'     => $help->countActive(),
                'activeHelp'    => array_slice(array_values(array_filter($help->all(), fn($h) => in_array($h['status'], ['open', 'on_the_way'], true))), 0, 3),
                'recentRatings' => (new DriverRating())->recent(5),
                'ratingCount'   => (new DriverRating())->countAll(),
            ];
        } elseif ($type === 'driver') {
            $profile  = (new Driver())->findByUser((int)$user['id']);
            $activeHelp = null;
            foreach ((new HelpRequest())->forDriverUser((int)$user['id'], 5) as $h) {
                if (in_array($h['status'], ['open', 'on_the_way'], true)) { $activeHelp = $h; break; }
            }
            $driverId = (int)($profile['driver_id'] ?? 0);
            $favoriteEntries = (new FavoriteDriver())->anonymousEntriesForDriver($driverId);
            $data += [
                'myTricycle'    => (new Tricycle())->findByDriverUser((int)$user['id']),
                'activeHelp'    => $activeHelp,
                'myRating'      => (new DriverRating())->summaryForDriver($driverId),
                'myReviews'     => (new DriverRating())->visibleForDriver($driverId),
                'favoriteEntries' => $favoriteEntries,
                'favoritedBy'   => count($favoriteEntries),
            ];
        } else {
            $userId = (int)$user['id'];
            $data += [
                'savedPlaces'   => array_slice((new SavedPlace())->forUser($userId), 0, 5),
                'favorites'     => (new FavoriteDriver())->forUser($userId),
                'ratings'       => (new DriverRating())->summaries(),
                'myRatingCount' => (new DriverRating())->countForUser($userId),
                'locations'     => (new Location())->all(),
                'discountPct'   => (int)(FareRate::DISCOUNT_RATE * 100),
            ];
        }

        $this->render('dashboard_' . $type, $data);
    }
}
