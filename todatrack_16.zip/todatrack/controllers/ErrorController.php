<?php
/** Shows friendly error pages (404, 500). */
class ErrorController extends BaseController
{
    public function show(int $code, string $message): void
    {
        http_response_code($code);
        $this->render('error', [
            'pageTitle' => 'Error ' . $code,
            'code'      => $code,
            'message'   => $message,
        ]);
    }
}
