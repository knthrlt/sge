<?php
/**
 * BaseController
 * Parent of all controllers: session user, role checks, CSRF protection,
 * flash messages, redirects, and rendering of views. Controllers contain
 * no HTML; they only prepare data and call a view.
 */
abstract class BaseController
{
    private static bool $statusChecked = false;

    protected function currentUser(): ?array
    {
        // Once per request: a user the admin deactivated is logged out right away.
        if (!self::$statusChecked && isset($_SESSION['user'])) {
            self::$statusChecked = true;
            if (!(new User())->isActive((int)$_SESSION['user']['id'])) {
                unset($_SESSION['user']);
                $_SESSION['flash'][] = ['type' => 'warning', 'message' => 'Your account is deactivated or no longer exists. Please contact the TODA admin.'];
            }
        }
        return $_SESSION['user'] ?? null;
    }

    protected function isAdmin(): bool
    {
        return ($this->currentUser()['role'] ?? '') === 'admin';
    }

    protected function isPassenger(): bool
    {
        return ($this->currentUser()['role'] ?? '') === 'passenger';
    }

    protected function isPost(): bool
    {
        return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
    }

    protected function requireLogin(): void
    {
        if (!$this->currentUser()) {
            $this->flash('warning', 'Please log in first.');
            $this->redirect('login');
        }
    }

    protected function requireAdmin(): void
    {
        $this->requireLogin();
        if (!$this->isAdmin()) {
            $this->forbidden();
        }
    }

    /** Passenger-only pages (saved places, favorites, ratings, profile). */
    protected function requirePassenger(): void
    {
        $this->requireLogin();
        if (!$this->isPassenger()) {
            $this->forbidden();
        }
    }

    protected function forbidden(): void
    {
        http_response_code(403);
        $this->render('error', [
            'pageTitle' => 'Access denied',
            'code'      => 403,
            'message'   => 'You do not have permission to do that.',
        ]);
        exit;
    }

    protected function redirect(string $page, array $params = []): void
    {
        header('Location: ' . url($page, $params));
        exit;
    }

    /**
     * Go back to the page the form was sent from (posted as "return_to").
     * Only internal index.php?page=... links are accepted, so it cannot
     * be used to send people to another website.
     */
    protected function redirectBack(string $fallbackPage): void
    {
        $back = (string)($_POST['return_to'] ?? '');
        if (preg_match('/^index\.php\?page=[a-z_]+(&[A-Za-z0-9_=.%-]*)?$/', $back)) {
            header('Location: ' . $back);
            exit;
        }
        $this->redirect($fallbackPage);
    }

    // ---- flash messages ----
    protected function flash(string $type, string $message): void
    {
        $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
    }

    protected function flashErrors(array $errors): void
    {
        foreach ($errors as $error) {
            $this->flash('danger', $error);
        }
    }

    private function pullFlash(): array
    {
        $flashes = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $flashes;
    }

    // ---- CSRF ----
    protected function csrfToken(): string
    {
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf'];
    }

    /** Stop the request when the form token is missing or wrong. */
    protected function verifyCsrf(): void
    {
        $sent = (string)($_POST['csrf'] ?? '');
        if ($sent === '' || !hash_equals($this->csrfToken(), $sent)) {
            http_response_code(419);
            $this->render('error', [
                'pageTitle' => 'Session expired',
                'code'      => 419,
                'message'   => 'Your form expired. Please go back, refresh the page, and try again.',
            ]);
            exit;
        }
    }

    protected function input(string $key, string $default = ''): string
    {
        return trim((string)($_POST[$key] ?? $default));
    }

    protected function render(string $view, array $data = []): void
    {
        $data += [
            'user'        => $this->currentUser(),
            'csrf'        => $this->csrfToken(),
            'flashes'     => $this->pullFlash(),
            'currentPage' => $_GET['page'] ?? '',
        ];
        extract($data, EXTR_SKIP);
        require __DIR__ . '/../views/' . $view . '_view.php';
    }
}
