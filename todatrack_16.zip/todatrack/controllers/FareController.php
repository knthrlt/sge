<?php
/** Fare guide: public (no login needed); only the admin can add, edit, or delete. */
class FareController extends BaseController
{
    public function index(): void
    {
        $this->render('fare', [
            'pageTitle'   => 'Fare Guide',
            'fares'       => (new FareRate())->all(),
            'zones'       => (new Zone())->all(),
            'locations'   => (new Location())->all(),
            'discountPct' => (int)(FareRate::DISCOUNT_RATE * 100),
            'myDiscount'  => $this->isPassenger() ? ($this->currentUser()['discount'] ?? null) : null,
        ]);
    }

    public function save(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('fares');
        }
        $this->verifyCsrf();

        $data = [
            'fare_id'     => (int)($_POST['fare_id'] ?? 0),
            'zone_id'     => $this->input('zone_id'),
            'location_id' => $this->input('location_id'),
            'fare'        => $this->input('fare'),
        ];

        $fare   = new FareRate();
        $errors = $fare->validate($data);

        if (!$errors) {
            $fare->setId($data['fare_id'])
                 ->setZoneId((int)$data['zone_id'])
                 ->setLocationId((int)$data['location_id'])
                 ->setFare((float)$data['fare']);
            $saved = $data['fare_id'] > 0 ? $fare->update() : $fare->create();
            if ($saved) {
                $this->flash('success', $data['fare_id'] > 0 ? 'Fare updated.' : 'Fare added.');
                $this->redirect('fares');
            }
            $errors = $fare->getErrors();
        }

        $this->flashErrors($errors);
        $this->redirect('fares');
    }

    public function delete(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('fares');
        }
        $this->verifyCsrf();

        $fare = new FareRate();
        if ($fare->delete((int)($_POST['fare_id'] ?? 0))) {
            $this->flash('success', 'Fare deleted.');
        } else {
            $this->flash('danger', implode(' ', $fare->getErrors()) ?: 'That fare was not found.');
        }
        $this->redirect('fares');
    }
}
