<?php
/** Landing page: what TodaTrack is, with links for visitors. */
class HomeController extends BaseController
{
    public function index(): void
    {
        // Logged-in users go straight to their dashboard.
        if ($this->currentUser()) {
            $this->redirect('dashboard');
        }

        $statuses = (new Tricycle())->statusCounts();
        $this->render('home', [
            'pageTitle' => 'Welcome',
            'zones'     => (new Zone())->withCounts(),
            'available' => $statuses['available'],
            'total'     => array_sum($statuses),
            'locations' => (new Location())->all(),
            'places'    => count((new Location())->all()),
        ]);
    }
}
