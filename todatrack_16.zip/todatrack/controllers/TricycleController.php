<?php
/** Tricycle CRUD, the passenger "Find a Tricycle" page. */
class TricycleController extends BaseController
{
    /** Read: list with search and filters (DataTables in the view). */
    public function index(): void
    {
        $this->requireLogin();

        $tricycle = new Tricycle();
        $own      = $this->isAdmin() ? null : $tricycle->findByDriverUser((int)$this->currentUser()['id']);

        $this->render('tricycle', [
            'pageTitle' => 'Tricycles',
            'tricycles' => $tricycle->all(),
            'zones'     => (new Zone())->all(),
            'statuses'  => Tricycle::STATUSES,
            'ownId'     => $own['tricycle_id'] ?? 0,
        ]);
    }

    /** Create / Update form (admin: all fields; driver: location and status only). */
    public function form(): void
    {
        $this->requireLogin();

        $id       = (int)($_GET['id'] ?? 0);
        $tricycle = new Tricycle();

        if ($id > 0) {
            $row = $tricycle->find($id);
            if (!$row) {
                $this->flash('warning', 'That tricycle no longer exists.');
                $this->redirect('tricycles');
            }
            $this->assertCanEdit($row);
            $values = $row;
        } else {
            $this->requireAdmin();
            $values = ['tricycle_id' => 0, 'body_number' => '', 'plate_number' => '', 'driver_id' => 0,
                       'zone_id' => 0, 'location_id' => 0, 'status' => 'available'];
        }

        $this->showForm($values, []);
    }

    /** Handles the form submit for both create and update. */
    public function save(): void
    {
        $this->requireLogin();
        if (!$this->isPost()) {
            $this->redirect('tricycles');
        }
        $this->verifyCsrf();

        $id       = (int)($_POST['tricycle_id'] ?? 0);
        $tricycle = new Tricycle();
        $data     = [
            'tricycle_id'  => $id,
            'body_number'  => $this->input('body_number'),
            'plate_number' => $this->input('plate_number'),
            'driver_id'    => $this->input('driver_id'),
            'zone_id'      => $this->input('zone_id'),
            'location_id'  => $this->input('location_id'),
            'status'       => $this->input('status'),
        ];

        // --- Driver accounts: may update only their own location and status ---
        if (!$this->isAdmin()) {
            $current = $id > 0 ? $tricycle->find($id) : null;
            if (!$current) {
                $this->forbidden();
            }
            $this->assertCanEdit($current);

            $errors = $tricycle->validateLocationStatus($data);
            if (!$errors) {
                $tricycle->setId($id)
                         ->setLocationId((int)$data['location_id'])
                         ->setStatus($data['status']);
                if ($tricycle->updateLocationStatus()) {
                    $this->flash('success', 'Your location and status were updated.');
                    $this->redirect('tricycles');
                }
                $errors = $tricycle->getErrors();
            }
            $this->showForm(array_merge($current, $data), $errors);
            return;
        }

        // --- Admin: full create / update ---
        $errors = $tricycle->validate($data);
        if (!$errors) {
            $tricycle->fill($data)->setId($id);
            $saved = $id > 0 ? $tricycle->update() : $tricycle->create();
            if ($saved) {
                $this->flash('success', $id > 0 ? 'Tricycle updated.' : 'Tricycle added.');
                $this->redirect('tricycles');
            }
            $errors = $tricycle->getErrors();
        }
        $this->showForm($data, $errors);
    }

    /** Delete (admin only; the view asks for confirmation first). */
    public function delete(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('tricycles');
        }
        $this->verifyCsrf();

        $tricycle = new Tricycle();
        if ($tricycle->delete((int)($_POST['tricycle_id'] ?? 0))) {
            $this->flash('success', 'Tricycle deleted.');
        } else {
            $this->flash('danger', implode(' ', $tricycle->getErrors()) ?: 'That tricycle was not found.');
        }
        $this->redirect('tricycles');
    }

    /** Public page (no login needed): pick a destination to see fare, zone color, and available tricycles. */
    public function find(): void
    {
        $fromZone    = (int)($_GET['from_zone'] ?? 0);
        $zoneFilter  = (int)($_GET['zone'] ?? 0);
        $destination = (int)($_GET['destination'] ?? 0);
        $query       = trim((string)($_GET['q'] ?? ''));
        $queryMiss   = false;
        $allLocations = (new Location())->all();
        if ($destination === 0 && $query !== '') {
            // Navbar search: exact name first, then the first name that contains the text.
            foreach ($allLocations as $loc) {
                if (mb_strtolower($loc['location_name']) === mb_strtolower($query)) { $destination = (int)$loc['location_id']; break; }
            }
            if ($destination === 0) {
                foreach ($allLocations as $loc) {
                    if (mb_stripos($loc['location_name'], $query) !== false) { $destination = (int)$loc['location_id']; break; }
                }
            }
            $queryMiss = $destination === 0;
        }
        $fares       = [];
        $groups      = [];
        $searched    = $destination > 0;

        if ($searched) {
            $fares    = (new FareRate())->forRoute($destination, $fromZone);
            $tricycle = new Tricycle();
            foreach ($fares as $fare) {
                $groups[] = [
                    'fare'      => $fare,
                    'tricycles' => $tricycle->availableByZone((int)$fare['zone_id']),
                ];
            }
        }

        // Everyone who is available right now (status comes straight from the database), per-zone counts for the chips.
        $trikeModel = new Tricycle();
        $zoneAvail  = [];
        foreach ((new Zone())->withCounts() as $z) {
            $zoneAvail[(int)$z['zone_id']] = (int)$z['available'];
        }

        // Extras for logged-in passengers: saved places, favorites, and their discount.
        $savedPlaces = [];
        $savedIds    = [];
        $favIds      = [];
        if ($this->isPassenger()) {
            $userId      = (int)$this->currentUser()['id'];
            $saved       = new SavedPlace();
            $savedPlaces = $saved->forUser($userId);
            $savedIds    = array_map('intval', array_column($savedPlaces, 'location_id'));
            $favIds      = (new FavoriteDriver())->idsForUser($userId);
        }

        $this->render('find', [
            'pageTitle'   => 'Find a Tricycle',
            'isPassenger' => $this->isPassenger(),
            'savedPlaces' => $savedPlaces,
            'savedIds'    => $savedIds,
            'favIds'      => $favIds,
            'ratings'     => (new DriverRating())->summaries(),
            'myDiscount'  => $this->isPassenger() ? ($this->currentUser()['discount'] ?? null) : null,
            'zones'       => (new Zone())->all(),
            'locations'   => $allLocations,
            'query'       => $query,
            'queryMiss'   => $queryMiss,
            'fromZone'    => $fromZone,
            'zoneFilter'  => $zoneFilter,
            'availableAll' => $trikeModel->allAvailable($zoneFilter),
            'zoneAvail'   => $zoneAvail,
            'destination' => $destination,
            'searched'    => $searched,
            'groups'      => $groups,
            'discountPct' => (int)(FareRate::DISCOUNT_RATE * 100),
        ]);
    }

    // ---- helpers ----
    /** Admin can edit any tricycle; a driver only the one linked to their account. */
    private function assertCanEdit(array $row): void
    {
        if ($this->isAdmin()) {
            return;
        }
        if ((int)($row['driver_user_id'] ?? 0) !== (int)$this->currentUser()['id']) {
            $this->forbidden();
        }
    }

    private function showForm(array $values, array $errors): void
    {
        $isAdmin = $this->isAdmin();
        $driverId = (int)($values['driver_id'] ?? 0);
        $this->render('tricycle_form', [
            'pageTitle' => ((int)($values['tricycle_id'] ?? 0) > 0 ? 'Edit' : 'Add') . ' Tricycle',
            'values'    => $values,
            'errors'    => $errors,
            'limited'   => !$isAdmin,
            'drivers'   => (new Driver())->assignable($driverId),
            'zones'     => (new Zone())->all(),
            'locations' => (new Location())->all(),
            'statuses'  => Tricycle::STATUSES,
        ]);
    }
}
