<?php
/** Login, registration, and logout. */
class AuthController extends BaseController
{
    public function login(): void
    {
        if ($this->currentUser()) {
            $this->redirect('dashboard');
        }

        $old = ['login' => ''];
        if ($this->isPost()) {
            $this->verifyCsrf();
            $old['login'] = $this->input('login');
            $password     = (string)($_POST['password'] ?? '');
            $errors       = [];

            if ($old['login'] === '' || $password === '') {
                $errors[] = 'Enter your username or email and your password.';
            } else {
                $model = new User();
                $found = $model->authenticate($old['login'], $password);
                if ($found) {
                    session_regenerate_id(true);
                    $_SESSION['user'] = [
                        'id'        => (int)$found['user_id'],
                        'full_name' => $found['full_name'],
                        'username'  => $found['username'],
                        'role'      => $found['role'],
                        'type'      => $found['role'],            // admin | driver | passenger
                        'discount'  => $found['discount_type'],  // student | senior | pwd | null
                    ];
                    $this->redirect('dashboard');
                }
                $errors = $model->getErrors() ?: ['Incorrect username/email or password.'];
            }
            $this->flashErrors($errors);
        }

        $this->render('login', ['pageTitle' => 'Log in', 'old' => $old]);
    }

    public function register(): void
    {
        if ($this->currentUser()) {
            $this->redirect('dashboard');
        }

        $old = ['first_name' => '', 'last_name' => '', 'username' => '', 'email' => '', 'account_type' => '', 'contact_no' => '', 'license_no' => '', 'privacy_consent' => ''];
        $errors = [];
        // Links like register?type=driver pre-select the account type.
        if (!$this->isPost() && in_array($_GET['type'] ?? '', ['passenger', 'driver'], true)) {
            $old['account_type'] = $_GET['type'];
        }

        if ($this->isPost()) {
            $this->verifyCsrf();
            foreach (array_keys($old) as $key) {
                $old[$key] = $this->input($key);
            }
            $data = $old + [
                'full_name'        => trim($old['first_name'] . ' ' . $old['last_name']),
                'password'         => (string)($_POST['password'] ?? ''),
                'confirm_password' => (string)($_POST['confirm_password'] ?? ''),
            ];
            $model  = new User();
            $errors = $model->validate($data);

            if (!$errors) {
                $model->setFullName($data['full_name'])
                      ->setUsername($data['username'])
                      ->setEmail($data['email'])
                      ->setPassword($data['password']);   // Admin accounts are created in the database only.
                $driverData = $data['account_type'] === 'driver' ? ['contact_no' => $data['contact_no'], 'license_no' => $data['license_no']] : null;

                if ($model->register($driverData)) {
                    $this->flash('success', $data['account_type'] === 'driver'
                        ? 'Driver account created. You can log in now. The admin will assign your tricycle.'
                        : 'Account created. You can log in now.');
                    $this->redirect('login');
                }
                $errors = $model->getErrors();
            }
        }

        $this->render('register', ['pageTitle' => 'Register', 'old' => $old, 'errors' => $errors]);
    }

    /** Logout is a POST with a CSRF token (the navbar button asks for confirmation first). */
    public function logout(): void
    {
        if (!$this->isPost()) {
            $this->redirect($this->currentUser() ? 'dashboard' : 'login');
        }
        $this->verifyCsrf();

        $_SESSION = [];
        session_regenerate_id(true);
        $this->flash('info', 'You have been logged out.');
        $this->redirect('login');
    }
}
