<?php
/** Admin: review passenger ratings and hide or delete inappropriate ones. */
class RatingController extends BaseController
{
    public function index(): void
    {
        $this->requireAdmin();
        $this->render('ratings_admin', [
            'pageTitle' => 'Ratings',
            'ratings'   => (new DriverRating())->allForAdmin(),
        ]);
    }

    public function update(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('ratings');
        }
        $this->verifyCsrf();

        $rating = new DriverRating();
        if ($rating->setStatus((int)($_POST['rating_id'] ?? 0), $this->input('status'))) {
            $this->flash('success', 'Rating updated.');
        } else {
            $this->flash('warning', 'That rating could not be changed.');
        }
        $this->redirect('ratings');
    }

    public function delete(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('ratings');
        }
        $this->verifyCsrf();

        if ((new DriverRating())->delete((int)($_POST['rating_id'] ?? 0))) {
            $this->flash('success', 'Rating deleted.');
        } else {
            $this->flash('warning', 'That rating was not found.');
        }
        $this->redirect('ratings');
    }
}
