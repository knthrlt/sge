<?php
/**
 * Admin: drivers who registered, and their account status.
 *
 * Two ways to remove access:
 *   Deactivate  (recommended, reversible): the driver cannot log in and the tricycle is hidden from
 *               passengers. Ratings and history are kept. Use Reactivate to restore.
 *   Delete      (permanent): only for a driver with no tricycle, e.g. a mistaken registration.
 */
class DriverController extends BaseController
{
    public function index(): void
    {
        $this->requireAdmin();
        $this->render('driver', [
            'pageTitle' => 'Drivers',
            'drivers'   => (new Driver())->allWithDetails(),
        ]);
    }

    /** Deactivate or reactivate a driver's login (POST: driver_id, active=0|1). */
    public function status(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('drivers');
        }
        $this->verifyCsrf();

        $id     = (int)($_POST['driver_id'] ?? 0);
        $active = ($_POST['active'] ?? '') === '1';
        $driver = new Driver();
        if ($driver->setActive($id, $active)) {
            $this->flash('success', $active
                ? 'Account reactivated. The driver can log in again and should set their status.'
                : 'Account deactivated. The driver can no longer log in and the tricycle is hidden from passengers.');
        } else {
            $this->flashErrors($driver->getErrors());
        }
        $this->redirect('drivers');
    }

    /** Permanently delete a driver and their login (POST: driver_id). */
    public function delete(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('drivers');
        }
        $this->verifyCsrf();

        $driver = new Driver();
        if ($driver->deleteWithAccount((int)($_POST['driver_id'] ?? 0))) {
            $this->flash('success', 'Driver account deleted permanently.');
        } else {
            $this->flashErrors($driver->getErrors());
        }
        $this->redirect('drivers');
    }
}
