<?php
/** Request Help: drivers report a problem; the admin follows up. */
class HelpController extends BaseController
{
    // ---------- driver ----------
    public function form(): void
    {
        $tricycle = $this->requireDriverTricycle();
        $this->showForm($tricycle, ['problem' => '', 'location_id' => $tricycle['location_id'], 'note' => ''], []);
    }

    public function save(): void
    {
        $tricycle = $this->requireDriverTricycle();
        if (!$this->isPost()) {
            $this->redirect('help');
        }
        $this->verifyCsrf();

        $data   = ['problem' => $this->input('problem'), 'location_id' => $this->input('location_id'), 'note' => $this->input('note')];
        $help   = new HelpRequest();
        $errors = $help->validate($data);

        if (!$errors) {
            $help->setTricycleId((int)$tricycle['tricycle_id'])
                 ->setLocationId((int)$data['location_id'])
                 ->setProblem($data['problem'])
                 ->setNote($data['note']);
            if ($help->create()) {
                $this->flash('success', 'Help request sent. Your tricycle is now Off Duty, so passengers will not see it.');
                $this->redirect('help');
            }
            $errors = $help->getErrors();
        }
        $this->showForm($tricycle, $data, $errors);
    }

    public function cancel(): void
    {
        $this->requireDriverTricycle();
        if (!$this->isPost()) {
            $this->redirect('help');
        }
        $this->verifyCsrf();

        $help = new HelpRequest();
        $row  = $help->find((int)($_POST['request_id'] ?? 0));
        if (!$row || (int)$row['driver_user_id'] !== (int)$this->currentUser()['id']) {
            $this->forbidden();
        }
        if ($help->cancel((int)$row['request_id'])) {
            $this->flash('success', 'Help request cancelled. When you are ready, set your tricycle back to Available with "Update my location and status".');
        } else {
            $this->flash('warning', 'Only a request that is still waiting can be cancelled.');
        }
        $this->redirect('help');
    }

    // ---------- admin ----------
    public function index(): void
    {
        $this->requireAdmin();
        $this->render('help_admin', [
            'pageTitle' => 'Help Requests',
            'requests'  => (new HelpRequest())->all(),
        ]);
    }

    public function update(): void
    {
        $this->requireAdmin();
        if (!$this->isPost()) {
            $this->redirect('help_requests');
        }
        $this->verifyCsrf();

        $status = $this->input('status');
        $help   = new HelpRequest();
        if ($help->setStatus((int)($_POST['request_id'] ?? 0), $status)) {
            $this->flash('success', $status === 'resolved' ? 'Request marked as resolved.' : 'Marked: help is on the way.');
        } else {
            $this->flash('warning', 'That request cannot be changed to that status (it may already be closed).');
        }
        $this->redirect('help_requests');
    }

    // ---------- helpers ----------
    /** Only a driver who already has a tricycle may use Request Help. */
    private function requireDriverTricycle(): array
    {
        $this->requireLogin();
        if (($this->currentUser()['role'] ?? '') !== 'driver') {
            $this->forbidden();
        }
        $tricycle = (new Tricycle())->findByDriverUser((int)$this->currentUser()['id']);
        if (!$tricycle) {
            $this->flash('info', 'You can request help once the admin assigns a tricycle to you.');
            $this->redirect('dashboard');
        }
        return $tricycle;
    }

    private function showForm(array $tricycle, array $values, array $errors): void
    {
        $help = new HelpRequest();
        $this->render('help', [
            'pageTitle' => 'Request Help',
            'tricycle'  => $tricycle,
            'values'    => $values,
            'errors'    => $errors,
            'locations' => (new Location())->all(),
            'problems'  => HelpRequest::PROBLEMS,
            'mine'      => $help->forDriverUser((int)$this->currentUser()['id']),
        ]);
    }
}
