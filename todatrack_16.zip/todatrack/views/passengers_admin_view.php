<?php require __DIR__ . '/header_view.php'; ?>
<div class="page-head">
    <h1 class="h3 mb-0">Passengers</h1>
    <p class="text-muted mb-0">View and manage passenger accounts. Passwords and password hashes are never displayed.</p>
</div>

<div class="alert alert-info small">
    Deactivating blocks login but keeps the account and its records. Deleting permanently removes the account and its linked passenger data.
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table id="passengerTable" class="table table-hover align-middle w-100">
                <thead>
                    <tr>
                        <th data-priority="1">Name</th>
                        <th data-priority="3">Username</th>
                        <th data-priority="4">Email</th>
                        <th data-priority="5">Discount</th>
                        <th data-priority="6">Registered</th>
                        <th data-priority="2">Status</th>
                        <th class="no-sort" data-priority="1">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($passengers as $p): $active = (bool)$p['is_active']; ?>
                    <tr>
                        <td class="fw-semibold"><?= e($p['full_name']) ?></td>
                        <td><?= e($p['username']) ?></td>
                        <td><?= e($p['email']) ?></td>
                        <td><?= $p['discount_type'] ? e($discounts[$p['discount_type']] ?? $p['discount_type']) : '<span class="text-muted">None</span>' ?></td>
                        <td data-order="<?= e($p['created_at']) ?>"><?= e(date('M j, Y', strtotime($p['created_at']))) ?></td>
                        <td data-search="<?= $active ? 'Active' : 'Deactivated' ?>">
                            <?php if ($active): ?><span class="badge status-available">Active</span>
                            <?php else: ?><span class="badge text-bg-danger">Deactivated</span><?php endif; ?>
                        </td>
                        <td class="text-nowrap">
                            <form method="post" action="<?= e(url('passenger_status')) ?>" class="d-inline"
                                  data-confirm="<?= $active
                                      ? 'Deactivate ' . e($p['full_name']) . '? They will no longer be able to log in. Their records will be kept.'
                                      : 'Reactivate ' . e($p['full_name']) . '? They will be able to log in again.' ?>"
                                  <?= $active ? 'data-confirm-style="danger"' : '' ?>>
                                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                <input type="hidden" name="user_id" value="<?= (int)$p['user_id'] ?>">
                                <input type="hidden" name="active" value="<?= $active ? '0' : '1' ?>">
                                <button type="submit" class="btn btn-sm <?= $active ? 'btn-outline-secondary' : 'btn-success' ?>"><?= $active ? 'Deactivate' : 'Reactivate' ?></button>
                            </form>
                            <form method="post" action="<?= e(url('passenger_delete')) ?>" class="d-inline"
                                  data-confirm="Permanently delete <?= e($p['full_name']) ?> and their passenger account? This cannot be undone. Deactivate the account instead to keep its records."
                                  data-confirm-style="danger">
                                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                <input type="hidden" name="user_id" value="<?= (int)$p['user_id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require __DIR__ . '/footer_view.php'; ?>
