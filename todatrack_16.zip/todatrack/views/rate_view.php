<?php require __DIR__ . '/header_view.php'; ?>
<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="page-head">
            <h1 class="h3 mb-0">Rate <?= e($driver['full_name']) ?></h1>
            <p class="text-muted mb-0"><?= $driver['body_number'] ? e($driver['body_number']) . ' | ' . e($driver['plate_number']) . '. ' : '' ?>You can rate each driver once; rating again updates your earlier rating.</p>
        </div>

        <?php if ($errors): ?>
            <div class="alert alert-danger" role="alert">
                <ul class="mb-0 ps-3">
                    <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm">
            <div class="card-body p-4">
                <form method="post" action="<?= e(url('rate_save')) ?>" data-validate data-confirm="Save your rating?" novalidate>
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <input type="hidden" name="driver_id" value="<?= (int)$driver['driver_id'] ?>">
                    <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
                    <fieldset class="mb-3">
                        <legend class="form-label fs-6">Your rating *</legend>
                        <div class="star-input">
                            <?php for ($i = 5; $i >= 1; $i--): ?>
                                <input type="radio" id="star<?= $i ?>" name="stars" value="<?= $i ?>" <?= (int)$values['stars'] === $i ? 'checked' : '' ?> required>
                                <label for="star<?= $i ?>" title="<?= $i ?> star<?= $i === 1 ? '' : 's' ?>">★</label>
                            <?php endfor; ?>
                        </div>
                        <div class="text-danger small mt-1 d-none" id="starError">Choose 1 to 5 stars.</div>
                    </fieldset>
                    <div class="mb-3">
                        <label for="comment" class="form-label">Comment (optional)</label>
                        <textarea class="form-control" id="comment" name="comment" rows="3" maxlength="255"
                                  placeholder="Polite driver, correct fare, safe ride..."><?= e($values['comment']) ?></textarea>
                        <div class="form-text">Drivers and the TODA admin can read your comment. Please keep it respectful.</div>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="is_anonymous" name="is_anonymous" value="1"
                               <?= !empty($values['is_anonymous']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_anonymous">Submit anonymously</label>
                        <div class="form-text">Your name will be hidden from the driver and other users. The TODA admin can still see your account details.</div>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary"><?= $editing ? 'Update rating' : 'Submit rating' ?></button>
                        <a class="btn btn-outline-secondary" href="<?= e($returnTo) ?>">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
