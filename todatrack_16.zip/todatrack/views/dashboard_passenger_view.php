<?php
require __DIR__ . '/header_view.php';
$discount = discount_label($user['discount'] ?? null);
$first    = explode(' ', trim($user['full_name']))[0];
?>
<header class="greet">
    <h1><span data-greeting>Welcome back</span>, <?= e($first) ?></h1>
    <p>Find a ride quickly with your saved places and favorite drivers.</p>
</header>

<div class="row g-3">
    <!-- Left column: find a ride, saved places -->
    <div class="col-xl-4">
        <div class="d-flex flex-column gap-3">
            <section class="dcard" aria-labelledby="rideTitle">
                <h2 class="dlabel" id="rideTitle">Need a ride?</h2>
                <div class="dbig mb-3">Where are you going?</div>
                <form method="get" action="index.php" data-validate novalidate>
                    <input type="hidden" name="page" value="find">
                    <label for="destination" class="visually-hidden">Destination</label>
                    <select class="form-select mb-2" id="destination" name="destination" required>
                        <option value="">Choose a destination</option>
                        <?php foreach ($locations as $l): ?>
                            <option value="<?= (int)$l['location_id'] ?>"><?= e($l['location_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">Choose a destination.</div>
                    <div class="d-flex gap-2 mt-2 mb-3">
                        <button type="submit" class="btn btn-primary flex-fill btn-icon"><?= icon('trike') ?>Find a Tricycle</button>
                        <a class="btn btn-soft flex-fill btn-icon" href="<?= e(url('fares')) ?>"><?= icon('peso') ?>Fare Guide</a>
                    </div>
                </form>
                <div class="dinset">
                    <div class="dinset-head"><span>My fare discount</span><a class="small" href="<?= e(url('profile')) ?>">Change in My Profile</a></div>
                    <?php if ($discount): ?>
                        <p class="mb-1"><span class="badge text-bg-success"><?= e($discount) ?></span></p>
                        <p class="small text-muted mb-0"><?= (int)$discountPct ?>% off is shown on Find a Tricycle and the Fare Guide.</p>
                    <?php else: ?>
                        <p class="small text-muted mb-0">Not set. Students, seniors, and PWD get <?= (int)$discountPct ?>% off.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="dcard" aria-labelledby="placesTitle">
                <div class="dcard-head"><h2 id="placesTitle">Saved places</h2><a class="btn btn-soft btn-sm" href="<?= e(url('places')) ?>">Manage</a></div>
                <?php if (!$savedPlaces): ?>
                    <p class="text-muted small mb-0">No saved places yet. Save places like Home or School on the <a href="<?= e(url('places')) ?>">Saved Places</a> page, or from a search on Find a Tricycle.</p>
                <?php endif; ?>
                <?php foreach ($savedPlaces as $p): ?>
                    <a class="list-row" href="<?= e(url('find', ['destination' => $p['location_id']])) ?>">
                        <span>
                            <span class="fw-semibold"><?= e($p['label'] ?: $p['location_name']) ?></span>
                            <?php if ($p['label']): ?><span class="small text-muted d-block"><?= e($p['location_name']) ?></span><?php endif; ?>
                        </span>
                        <span class="text-end small">
                            <?php if ($p['from_fare'] !== null): ?><span class="d-block">from <?= e(peso($p['from_fare'])) ?></span><?php endif; ?>
                            <span class="<?= (int)$p['available_count'] > 0 ? 'text-success' : 'text-muted' ?>"><?= (int)$p['available_count'] ?> available</span>
                        </span>
                    </a>
                <?php endforeach; ?>
            </section>
        </div>
    </div>

    <!-- Right column: availability, zones, favorite drivers -->
    <div class="col-xl-8">
        <div class="row g-3">
            <div class="col-md-6">
                <div class="tiles h-100">
                    <?= dash_tile('Available now', $statuses['available'], 'tricycles ready to ride', 'sky', 'check', true, url('find')) ?>
                    <?= dash_tile('Saved places', count($savedPlaces), 'shown on this page', 'sky', 'bookmark', false, url('places')) ?>
                    <?= dash_tile('Favorite drivers', count($favorites), 'drivers you follow', 'sky', 'heart', false, url('favorites')) ?>
                    <?= dash_tile('My ratings', $myRatingCount, 'drivers rated', 'sky', 'star', false, url('favorites')) ?>
                </div>
            </div>
            <div class="col-md-6"><?php require __DIR__ . '/partial_zone_cards.php'; ?></div>
            <div class="col-12">
                <section class="dcard" aria-labelledby="favDriversTitle">
                    <div class="dcard-head"><h2 id="favDriversTitle">Favorite drivers</h2><a class="btn btn-soft btn-sm" href="<?= e(url('favorites')) ?>">Manage</a></div>
                    <?php if (!$favorites): ?>
                        <p class="text-muted small mb-0">No favorite drivers yet. Tap "Add favorite" on a driver in Find a Tricycle.</p>
                    <?php else: ?>
                    <div class="dtab-wrap">
                        <table class="dtab">
                            <thead><tr><th scope="col">Driver</th><th scope="col">Rating</th><th scope="col">Location</th><th scope="col">Status</th></tr></thead>
                            <tbody>
                            <?php foreach (array_slice($favorites, 0, 5) as $f): ?>
                                <tr>
                                    <td><strong><?= e($f['full_name']) ?></strong></td>
                                    <td class="text-nowrap"><?= e(rating_text($ratings[(int)$f['driver_id']] ?? null)) ?></td>
                                    <td><?= $f['location_name'] ? e($f['location_name']) : '<span class="text-muted">-</span>' ?></td>
                                    <td><span class="sdot s-<?= e($f['status'] ?? 'off_duty') ?>"><?= e($f['status_label']) ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
