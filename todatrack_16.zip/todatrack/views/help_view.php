<?php
require __DIR__ . '/header_view.php';
$active = null;
foreach ($mine as $m) { if (in_array($m['status'], ['open', 'on_the_way'], true)) { $active = $m; break; } }
?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <h1 class="h3 mb-1">Request Help</h1>
        <p class="text-muted">Broke down on the road? Tell the TODA admin what happened and where you are. Your tricycle is set to Off Duty so passengers are shown other available tricycles.</p>

        <?php if ($errors): ?>
            <div class="alert alert-danger" role="alert">
                <ul class="mb-0 ps-3">
                    <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($active): ?>
            <div class="card shadow-sm mb-4 help-<?= e($active['status']) ?>">
                <div class="card-body">
                    <div class="d-flex flex-wrap justify-content-between gap-2">
                        <div>
                            <div class="fw-semibold"><?= e($active['problem_label']) ?> at <?= e($active['location_name']) ?></div>
                            <div class="small text-muted"><?= e($active['created_at']) ?></div>
                        </div>
                        <span class="badge align-self-start <?= $active['status'] === 'on_the_way' ? 'text-bg-warning' : 'text-bg-danger' ?>"><?= e($active['status_label']) ?></span>
                    </div>
                    <?php if ($active['note']): ?><p class="mb-0 mt-2 small">Note: <?= e($active['note']) ?></p><?php endif; ?>
                    <?php if ($active['status'] === 'open'): ?>
                        <form method="post" action="<?= e(url('help_cancel')) ?>" class="mt-3"
                              data-confirm="Cancel this help request?" data-confirm-style="danger">
                            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                            <input type="hidden" name="request_id" value="<?= (int)$active['request_id'] ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger">Cancel request</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="card shadow-sm mb-4">
                <div class="card-body p-4">
                    <form method="post" action="<?= e(url('help_save')) ?>" data-validate
                          data-confirm="Send this help request? Your tricycle will be set to Off Duty." novalidate>
                        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                        <div class="mb-3">
                            <label for="problem" class="form-label">What is the problem? *</label>
                            <select class="form-select" id="problem" name="problem" required>
                                <option value="">Choose a problem</option>
                                <?php foreach ($problems as $key => $label): ?>
                                    <option value="<?= e($key) ?>" <?= $values['problem'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Choose what the problem is.</div>
                        </div>
                        <div class="mb-3">
                            <label for="location_id" class="form-label">Where are you now? *</label>
                            <select class="form-select" id="location_id" name="location_id" required>
                                <option value="">Choose your location</option>
                                <?php foreach ($locations as $l): ?>
                                    <option value="<?= (int)$l['location_id'] ?>" <?= (int)$values['location_id'] === (int)$l['location_id'] ? 'selected' : '' ?>><?= e($l['location_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Choose where you are.</div>
                        </div>
                        <div class="mb-3">
                            <label for="note" class="form-label">Note (optional)</label>
                            <textarea class="form-control" id="note" name="note" rows="2" maxlength="255"
                                      placeholder="e.g., Rear tire flat, near the gas station"><?= e($values['note']) ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-add">Send help request</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($mine): ?>
            <h2 class="h6">Your recent requests</h2>
            <ul class="list-group">
                <?php foreach ($mine as $m): ?>
                    <li class="list-group-item d-flex flex-wrap justify-content-between gap-2">
                        <span><?= e($m['problem_label']) ?> at <?= e($m['location_name']) ?> <span class="small text-muted">(<?= e($m['created_at']) ?>)</span></span>
                        <span class="badge text-bg-secondary"><?= e($m['status_label']) ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
