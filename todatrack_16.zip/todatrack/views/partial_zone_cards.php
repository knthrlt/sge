<?php
/* Availability by zone, as a bar chart card. Needs: $zones.
 * Each bar is a link: the colored part is the number of available tricycles, the hatched part the rest.
 *   guests and passengers -> Find a Tricycle, filtered to that zone's available tricycles
 *   drivers and admin     -> Tricycles list, filtered to that zone
 * Colors come from the zones table (color_hex), so the Zones page stays the single place to change them. */
$zoneRole = $user['type'] ?? 'guest';
$staff    = in_array($zoneRole, ['admin', 'driver'], true);
$maxTotal = max(1, ...array_map(fn($z) => (int)$z['total'], $zones ?: [['total' => 1]]));
?>
<section class="dcard h-100 zone-chart-card" id="zones" aria-labelledby="zonesTitle">
    <div class="dcard-head">
        <div>
            <h2 id="zonesTitle">Availability by zone</h2>
            <p class="dsub"><?= $staff ? 'Select a zone to view its tricycles.' : 'Select a zone to see who is available.' ?></p>
        </div>
        <div class="zlegend" aria-hidden="true"><span><i class="lg-av"></i>Available</span><span><i class="lg-rest"></i>Not available</span></div>
    </div>
    <?php if (!$zones): ?>
        <div class="alert alert-info mb-0">No zones yet.</div>
    <?php else: ?>
    <div class="zchart">
        <?php foreach ($zones as $zone):
            $tot  = (int)$zone['total'];
            $av   = (int)$zone['available'];
            $href = $staff ? url('tricycles', ['zone' => $zone['zone_id']]) : url('find', ['zone' => $zone['zone_id']]) . '#available'; ?>
            <a class="zbar" href="<?= e($href) ?>" style="--z: <?= e($zone['color_hex']) ?>; --h: <?= $tot > 0 ? max(6, round($tot / $maxTotal * 100)) : 4 ?>%; --a: <?= $tot > 0 ? round($av / $tot * 100) : 0 ?>%;"
               aria-label="<?= e($zone['zone_name']) ?> zone: <?= $av ?> of <?= $tot ?> tricycles available. <?= $staff ? 'View tricycles' : 'See available' ?>">
                <span class="zcount"><?= $av ?><small>/<?= $tot ?></small></span>
                <span class="zplot"><span class="zcol"><span class="zfill"></span></span></span>
                <span class="zname"><?= e($zone['zone_name']) ?></span>
                <span class="zcolor"><?= e($zone['color_name']) ?></span>
            </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</section>
