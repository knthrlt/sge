<?php require __DIR__ . '/header_view.php'; ?>
<h1 class="h3 mb-1">Help Requests</h1>
<p class="text-muted">Requests from drivers who need help. Active requests are listed first.</p>

<?php if (!$requests): ?>
    <div class="alert alert-info">No help requests yet.</div>
<?php endif; ?>

<?php foreach ($requests as $r): $isActive = in_array($r['status'], ['open', 'on_the_way'], true); ?>
    <div class="card shadow-sm mb-3 help-<?= e($r['status']) ?>">
        <div class="card-body">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-2">
                <div>
                    <span class="fw-semibold"><?= e($r['problem_label']) ?></span> at <strong><?= e($r['location_name']) ?></strong>
                    <div class="small text-muted"><?= e($r['created_at']) ?></div>
                </div>
                <span class="badge <?= ['open' => 'text-bg-danger', 'on_the_way' => 'text-bg-warning', 'resolved' => 'text-bg-success', 'cancelled' => 'text-bg-secondary'][$r['status']] ?>"><?= e($r['status_label']) ?></span>
            </div>
            <div class="mt-2 small">
                <span class="badge zone-badge" style="background: <?= e($r['color_hex']) ?>; color: <?= e($r['text_hex']) ?>;"><?= e($r['body_number']) ?></span>
                <?= e($r['plate_number']) ?> | Driver: <?= e($r['driver_name']) ?> | <?= e($r['contact_no']) ?>
            </div>
            <?php if ($r['note']): ?><p class="mb-0 mt-2 small">Note: <?= e($r['note']) ?></p><?php endif; ?>

            <?php if ($isActive): ?>
                <div class="d-flex flex-wrap gap-2 mt-3">
                    <?php if ($r['status'] === 'open'): ?>
                        <form method="post" action="<?= e(url('help_update')) ?>" data-confirm="Tell the driver that help is on the way?">
                            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                            <input type="hidden" name="request_id" value="<?= (int)$r['request_id'] ?>">
                            <input type="hidden" name="status" value="on_the_way">
                            <button type="submit" class="btn btn-sm btn-warning">Help is on the way</button>
                        </form>
                    <?php endif; ?>
                    <form method="post" action="<?= e(url('help_update')) ?>" data-confirm="Mark this request as resolved?">
                        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                        <input type="hidden" name="request_id" value="<?= (int)$r['request_id'] ?>">
                        <input type="hidden" name="status" value="resolved">
                        <button type="submit" class="btn btn-sm btn-success">Resolved</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; ?>
<?php require __DIR__ . '/footer_view.php'; ?>
