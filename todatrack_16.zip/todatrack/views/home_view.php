<?php
/*
 * Landing page. Layout follows the reference screenshots:
 *   1. hero: left headline + two buttons, right collage of rounded tiles
 *   2. "Ride by zone": heading + soft button, horizontal rail of zone cards (big tile + two small tiles)
 *   3. join band: tile mosaic with a big headline and a white welcome card
 *   4. big dark footer (footer_view.php)
 * Colors come only from the official TodaTrack palette (see assets/css/style.css).
 */
$fullWidth = true;   // header_view.php: render <main> without the page container
require __DIR__ . '/header_view.php';

$mosaic = [   // [row span, palette color, icon]
    [2, 'indigo', 'trike'], [1, 'sand', ''],      [2, 'leaf', 'pin'],     [1, 'yellow', 'peso'], [2, 'sky', ''],      [1, 'red', 'star'],     [2, 'sea', 'trike'],   [1, 'lime', ''],
    [1, 'orange', 'pin'],   [2, 'forest', ''],    [1, 'sand', 'star'],    [2, 'indigo', ''],     [1, 'leaf', 'peso'], [2, 'deepred', 'pin'],  [1, 'yellow', ''],     [2, 'sky', 'trike'],
    [2, 'red', ''],         [1, 'lime', 'trike'], [2, 'sea', 'peso'],     [1, 'orange', ''],     [2, 'sand', 'pin'],  [1, 'forest', 'star'],  [2, 'indigo', 'peso'], [1, 'yellow', 'pin'],
];
$mosaic = array_merge($mosaic, array_slice(array_reverse($mosaic), 0, 10));   // enough tiles to cover tall screens
?>
<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
    <symbol id="ico-trike" viewBox="0 0 120 80"><g fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="30" cy="62" r="11"/><circle cx="98" cy="62" r="11"/>
        <path d="M10 54V38q0-6 6-6h28q8 0 8 8v14z"/><path d="M52 50h18l10-14h14M88 32h12M94 36l4 26"/></g></symbol>
    <symbol id="ico-pin" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></g></symbol>
    <symbol id="ico-star" viewBox="0 0 24 24"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.2 6.5 20.2l1-6.2L3 9.6l6.2-.9z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></symbol>
    <symbol id="ico-peso" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 20V5h5a3.5 3.5 0 0 1 0 7H8"/><path d="M5 9h12M5 12h12"/></g></symbol>
    <symbol id="ico-check" viewBox="0 0 16 16"><circle cx="8" cy="8" r="8" fill="currentColor"/><path d="m4.6 8.3 2.3 2.3 4.5-4.7" fill="none" stroke="var(--check-ink, #fff)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></symbol>
</svg>

<!-- 1. Hero -->
<section class="lp-hero">
    <div class="lp-inner lp-hero-grid">
        <div class="lp-hero-copy">
            <h1>Find the right tricycle on TodaTrack</h1>
            <p class="lp-lead">See which zone serves your destination, the fare before you ride, and which tricycles are free right now. No account needed.</p>
            <div class="lp-actions">
                <a class="btn btn-primary btn-lg" href="<?= e(url('find')) ?>">Find a tricycle</a>
                <a class="btn btn-soft btn-lg" href="<?= e(url('fares')) ?>">View fare guide</a>
            </div>
            <p class="lp-live"><span class="live-dot" aria-hidden="true"></span><b><?= (int)$available ?></b> of <?= (int)$total ?> tricycles available right now</p>
        </div>
        <div class="lp-collage" aria-hidden="true">
            <div class="lp-tile t-red"><b class="lp-big"><?= (int)$available ?></b><span>available now</span></div>
            <div class="lp-tile t-leaf"><b class="lp-big"><?= count($zones) ?></b><span>color-coded zones</span></div>
            <div class="lp-tile t-indigo"><img src="<?= e(asset('assets/img/logo.png')) ?>" alt=""><span>Tricycle zone monitoring</span></div>
            <div class="lp-tile t-sand"><svg class="lp-ico"><use href="#ico-trike"/></svg><span>Fare guide</span></div>
            <div class="lp-tile t-sky"><svg class="lp-ico"><use href="#ico-pin"/></svg><span><?= (int)$places ?> destinations</span></div>
            <div class="lp-tile t-yellow"><b class="lp-big">20%</b><span>off for students, seniors &amp; PWD</span></div>
        </div>
    </div>
</section>

<!-- 2. Ride by zone -->
<section class="lp-section lp-section-soft" id="zones">
    <div class="lp-inner">
        <div class="lp-head">
            <h2>Ride by zone</h2>
            <a class="btn btn-soft" href="<?= e(url('fares')) ?>">See all fares</a>
        </div>
        <?php if (!$zones): ?>
            <div class="alert alert-info">No zones yet.</div>
        <?php else: ?>
        <div class="lp-rail-wrap">
            <div class="lp-rail" id="zoneRail" tabindex="0" aria-label="Tricycle zones, scroll sideways for more">
                <?php foreach ($zones as $z): ?>
                <a class="lp-card" href="<?= e(url('find', ['zone' => $z['zone_id']]) . '#available') ?>"
                   style="--z: <?= e($z['color_hex']) ?>; --z-ink: <?= e($z['text_hex']) ?>;"
                   aria-label="<?= e($z['zone_name']) ?> zone, <?= (int)$z['available'] ?> of <?= (int)$z['total'] ?> tricycles available. See available">
                    <div class="lp-mosaic">
                        <div class="m-big"><b class="lp-big"><?= (int)$z['available'] ?></b><span>available now</span></div>
                        <div class="m-s1"><svg class="lp-ico"><use href="#ico-trike"/></svg></div>
                        <div class="m-s2"><b><?= (int)$z['total'] ?></b><span>total</span></div>
                    </div>
                    <h3><?= e($z['zone_name']) ?></h3>
                    <div class="lp-sub"><?= e($z['color_name']) ?> zone <svg class="lp-check" style="--check-ink: <?= e($z['text_hex']) ?>"><use href="#ico-check"/></svg></div>
                    <div class="lp-meta"><?= (int)$z['available'] ?> of <?= (int)$z['total'] ?> available &middot; live</div>
                </a>
                <?php endforeach; ?>
            </div>
            <button type="button" class="lp-next" id="zoneNext" aria-label="Show more zones">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg>
            </button>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- How it works (system introduction) -->
<section class="lp-section" id="about">
    <div class="lp-inner">
        <div class="lp-head">
            <h2>How TodaTrack works</h2>
        </div>
        <p class="lp-intro">TodaTrack is a tricycle zone monitoring system. Every TODA zone has its own color, so you can tell which tricycles serve your route, what the fare is, and who is free to take you.</p>
        <div class="row g-3">
            <div class="col-md-4"><div class="card step-card h-100 s1"><div class="step-num">01</div><div class="card-body">
                <h3 class="h5">Choose your destination</h3>
                <p class="text-muted mb-0">Pick where you are going on the Find a Tricycle page, or search from the top bar.</p>
            </div></div></div>
            <div class="col-md-4"><div class="card step-card h-100 s2"><div class="step-num">02</div><div class="card-body">
                <h3 class="h5">Read the zone color and fare</h3>
                <p class="text-muted mb-0">The color tells you which tricycles serve that route, and the fare guide tells you what you pay.</p>
            </div></div></div>
            <div class="col-md-4"><div class="card step-card h-100 s3"><div class="step-num">03</div><div class="card-body">
                <h3 class="h5">Pick a free tricycle</h3>
                <p class="text-muted mb-0">See which tricycles of that color are available, where they are now, and their passenger rating.</p>
            </div></div></div>
        </div>
    </div>
</section>

<!-- 3. Join band: tile mosaic + welcome card -->
<section class="lp-join" id="join">
    <div class="lp-mosaic-bg" aria-hidden="true">
        <?php foreach ($mosaic as [$span, $col, $icon]): ?>
            <div class="mb mb-<?= e($col) ?> span-<?= (int)$span ?>"><?php if ($icon): ?><svg class="lp-ico"><use href="#ico-<?= e($icon) ?>"/></svg><?php endif; ?></div>
        <?php endforeach; ?>
    </div>
    <div class="lp-inner lp-join-grid">
        <h2 class="lp-join-title">Join TodaTrack to ride smarter</h2>
        <div class="lp-signup">
            <img class="lp-signup-logo" src="<?= e(asset('assets/img/logo.png')) ?>" alt="TodaTrack logo" width="56" height="56">
            <h3>Welcome to TodaTrack</h3>
            <p class="text-muted">Join for free to save places, follow favorite drivers, and rate your rides. Drivers register here too.</p>
            <form method="get" action="index.php">
                <input type="hidden" name="page" value="register">
                <fieldset class="lp-role">
                    <legend class="visually-hidden">I am a</legend>
                    <input type="radio" class="btn-check" name="type" id="lpPassenger" value="passenger" checked>
                    <label class="btn btn-outline-primary" for="lpPassenger">Passenger</label>
                    <input type="radio" class="btn-check" name="type" id="lpDriver" value="driver">
                    <label class="btn btn-outline-primary" for="lpDriver">Driver</label>
                </fieldset>
                <button type="submit" class="btn btn-primary w-100">Continue</button>
            </form>
            <div class="lp-or"><span>OR</span></div>
            <a class="btn btn-soft w-100" href="<?= e(url('login')) ?>">I already have an account</a>
            <p class="lp-staff">TODA staff? <a href="<?= e(url('login')) ?>">Admin log in</a></p>
            <p class="lp-terms">By continuing, you agree to the Data Privacy Notice shown when you register.</p>
        </div>
    </div>
</section>

<script>
(function () {
    var rail = document.getElementById('zoneRail'), next = document.getElementById('zoneNext');
    if (!rail || !next) return;
    function sync() { next.hidden = rail.scrollWidth - rail.clientWidth - rail.scrollLeft < 8; }
    next.addEventListener('click', function () {
        var card = rail.querySelector('.lp-card');
        var step = card ? card.getBoundingClientRect().width + 16 : rail.clientWidth * 0.8;
        var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        rail.scrollBy({ left: step, behavior: reduce ? 'auto' : 'smooth' });
    });
    rail.addEventListener('scroll', sync, { passive: true });
    window.addEventListener('resize', sync);
    sync();
})();
</script>
<?php require __DIR__ . '/footer_view.php'; ?>
