<?php
require __DIR__ . '/header_view.php';
$first    = explode(' ', trim($user['full_name']))[0];
$avail    = (int)$statuses['available'];
$pctAvail = $total > 0 ? (int)round($avail / $total * 100) : 0;
?>
<header class="greet">
    <h1><span data-greeting>Welcome back</span>, <?= e($first) ?></h1>
    <p>Stay on top of tricycles, drivers, passengers, help requests, and ratings.</p>
</header>

<?php if ($helpCount > 0): ?>
    <div class="alert alert-danger d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span><strong><?= (int)$helpCount ?></strong> driver<?= $helpCount === 1 ? ' needs' : 's need' ?> help right now.</span>
        <a class="btn btn-sm btn-danger" href="<?= e(url('help_requests')) ?>">Open Help Requests</a>
    </div>
<?php endif; ?>
<?php if ($waiting > 0): ?>
    <div class="alert alert-warning">
        <strong><?= (int)$waiting ?></strong> registered driver<?= $waiting === 1 ? ' is' : 's are' ?> waiting for a tricycle.
        <a href="<?= e(url('tricycle_form')) ?>">Assign one</a>.
    </div>
<?php endif; ?>

<div class="row g-3">
    <!-- Left column: fleet, availability, ratings -->
    <div class="col-xl-4">
        <div class="d-flex flex-column gap-3">
            <section class="dcard" aria-labelledby="fleetTitle">
                <h2 class="dlabel" id="fleetTitle">Total tricycles</h2>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <span class="dbig"><?= (int)$total ?></span>
                    <?php if ($total > 0): ?><span class="chip"><?= $pctAvail ?>% available</span><?php endif; ?>
                </div>
                <p class="dsub mb-3">registered in the system</p>
                <div class="d-flex gap-2 mb-3">
                    <a class="btn btn-primary flex-fill btn-icon" href="<?= e(url('tricycle_form')) ?>"><?= icon('plus') ?>Add Tricycle</a>
                    <a class="btn btn-soft flex-fill btn-icon" href="<?= e(url('fares')) ?>"><?= icon('peso') ?>Fare Guide</a>
                </div>
                <div class="dinset">
                    <div class="dinset-head"><span>Manage</span><span class="dsub">System records</span></div>
                    <div class="dlinks">
                        <a class="dlink" href="<?= e(url('tricycles')) ?>"><?= icon('trike') ?><span>Tricycles</span><small><?= (int)$total ?> total</small></a>
                        <a class="dlink" href="<?= e(url('zones')) ?>"><?= icon('map') ?><span>Zones</span><small><?= count($zones) ?> zones</small></a>
                        <a class="dlink" href="<?= e(url('locations')) ?>"><?= icon('pin') ?><span>Locations</span><small>Destinations</small></a>
                        <a class="dlink" href="<?= e(url('drivers')) ?>"><?= icon('user') ?><span>Drivers</span><small><?= (int)$accounts['drivers'] ?> accounts</small></a>
                        <a class="dlink" href="<?= e(url('passengers')) ?>"><?= icon('users') ?><span>Passengers</span><small><?= (int)$accounts['passengers'] ?> accounts</small></a>
                        <a class="dlink" href="<?= e(url('ratings')) ?>"><?= icon('star') ?><span>Ratings</span><small><?= (int)$ratingCount ?> total</small></a>
                    </div>
                </div>
            </section>

            <section class="dcard" aria-labelledby="availTitle">
                <h2 class="dlabel" id="availTitle">Fleet availability</h2>
                <div class="dprog" role="img" aria-label="<?= $avail ?> of <?= (int)$total ?> tricycles available"><span style="width: <?= $pctAvail ?>%"></span></div>
                <div class="dprog-meta"><span><strong><?= $avail ?></strong> available</span><span>of <?= (int)$total ?> tricycles</span></div>
                <p class="dsub mb-0 mt-2">On trip <?= (int)$statuses['on_trip'] ?> &middot; Off duty <?= (int)$statuses['off_duty'] ?></p>
            </section>

            <section class="dcard" aria-labelledby="ratingsTitle">
                <div class="dcard-head">
                    <h2 id="ratingsTitle">Latest ratings</h2>
                    <a class="btn btn-soft btn-sm" href="<?= e(url('ratings')) ?>">View all</a>
                </div>
                <?php if (!$recentRatings): ?><p class="text-muted small mb-0">No ratings yet.</p><?php endif; ?>
                <ul class="dfeed">
                <?php foreach ($recentRatings as $r): ?>
                    <li>
                        <div class="d-flex justify-content-between gap-2">
                            <strong><?= e($r['driver_name']) ?></strong><?= star_row((int)$r['stars']) ?>
                        </div>
                        <?php if ($r['status'] === 'hidden'): ?><span class="badge text-bg-secondary">Hidden</span><?php endif; ?>
                        <?php if ($r['comment']): ?><div class="text-muted small">&ldquo;<?= e($r['comment']) ?>&rdquo;</div><?php endif; ?>
                    </li>
                <?php endforeach; ?>
                </ul>
            </section>
        </div>
    </div>

    <!-- Right column: statistics, zones, help requests -->
    <div class="col-xl-8">
        <div class="row g-3">
            <div class="col-md-6">
                <div class="tiles h-100">
                    <?= dash_tile('Available now', $avail, 'ready for passengers', 'indigo', 'check', true) ?>
                    <?= dash_tile('On trip', $statuses['on_trip'], 'currently on the road', 'indigo', 'trike') ?>
                    <?= dash_tile('Off duty', $statuses['off_duty'], 'not taking passengers', 'indigo', 'power') ?>
                    <?= dash_tile('Waiting for tricycle', $waiting, 'drivers without a tricycle', 'indigo', 'clock', false, $waiting > 0 ? url('tricycle_form') : null) ?>
                </div>
            </div>
            <div class="col-md-6"><?php require __DIR__ . '/partial_zone_cards.php'; ?></div>
            <div class="col-12">
                <div class="tiles tiles-4">
                    <?= dash_tile('Drivers', $accounts['drivers'], 'driver accounts', 'red', 'user', false, url('drivers')) ?>
                    <?= dash_tile('Passengers', $accounts['passengers'], 'passenger accounts', 'sky', 'users', false, url('passengers')) ?>
                    <?= dash_tile('Active help requests', $helpCount, 'drivers needing help', 'red', 'alert', false, url('help_requests')) ?>
                    <?= dash_tile('Ratings', $ratingCount, 'passenger ratings', 'indigo', 'star', false, url('ratings')) ?>
                </div>
            </div>
            <div class="col-12">
                <section class="dcard" aria-labelledby="helpTitle">
                    <div class="dcard-head">
                        <h2 id="helpTitle">Active help requests</h2>
                        <a class="btn btn-soft btn-sm" href="<?= e(url('help_requests')) ?>">Open Help Requests</a>
                    </div>
                    <div class="dtab-wrap">
                        <table class="dtab">
                            <thead><tr><th scope="col">Tricycle</th><th scope="col">Driver</th><th scope="col">Problem</th><th scope="col">Location</th><th scope="col">Status</th></tr></thead>
                            <tbody>
                            <?php if (!$activeHelp): ?>
                                <tr><td colspan="5" class="text-muted">No drivers need help right now.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($activeHelp as $h): ?>
                                <tr>
                                    <td><strong><?= e($h['body_number']) ?></strong></td>
                                    <td><?= e($h['driver_name']) ?></td>
                                    <td><?= e($h['problem_label']) ?></td>
                                    <td><?= e($h['location_name']) ?></td>
                                    <td><span class="sdot s-<?= e($h['status']) ?>"><?= e($h['status_label']) ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
