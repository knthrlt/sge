<?php require __DIR__ . '/header_view.php'; ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h1 class="h3 mb-0">Locations</h1>
        <p class="text-muted mb-0">Barangays, sitios, and landmarks used as destinations and as a tricycle's current location.</p>
    </div>
    <button type="button" class="btn btn-primary btn-add" data-bs-toggle="modal" data-bs-target="#locationModal">+ Add Location</button>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table id="locationTable" class="table table-hover align-middle w-100">
                <thead>
                    <tr>
                        <th data-priority="1">Location</th>
                        <th class="text-end" data-priority="3">Fares</th>
                        <th class="text-end" data-priority="4">Tricycles here</th>
                        <th class="no-sort" data-priority="2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($locations as $l): ?>
                    <tr>
                        <td><?= e($l['location_name']) ?></td>
                        <td class="text-end"><?= (int)$l['fare_count'] ?></td>
                        <td class="text-end"><?= (int)$l['tricycle_count'] ?></td>
                        <td class="text-nowrap">
                            <button type="button" class="btn btn-sm btn-outline-primary edit-btn"
                                    data-bs-toggle="modal" data-bs-target="#locationModal"
                                    data-id="<?= (int)$l['location_id'] ?>" data-name="<?= e($l['location_name']) ?>">Edit</button>
                            <form method="post" action="<?= e(url('location_delete')) ?>" class="d-inline"
                                  data-confirm="Delete the location <?= e($l['location_name']) ?>? This cannot be undone." data-confirm-style="danger">
                                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                <input type="hidden" name="location_id" value="<?= (int)$l['location_id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade crud-modal" id="locationModal" tabindex="-1" aria-labelledby="locationModalTitle" aria-hidden="true"
     data-title-add="Add Location" data-title-edit="Edit Location">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content" method="post" action="<?= e(url('location_save')) ?>" data-validate data-confirm="Save this location?" novalidate>
            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
            <input type="hidden" name="location_id" value="0" data-field="id" data-default="0">
            <div class="modal-header">
                <h5 class="modal-title" id="locationModalTitle">Add Location</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label for="location_name" class="form-label">Location name *</label>
                <input type="text" class="form-control" id="location_name" name="location_name" maxlength="80"
                       placeholder="e.g., Brgy. Rizal" data-field="name" required>
                <div class="invalid-feedback">Location name is required.</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Location</button>
            </div>
        </form>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
