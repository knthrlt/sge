<?php require __DIR__ . '/header_view.php'; ?>
<div class="page-head">
    <h1 class="h3 mb-0">Saved Places</h1>
    <p class="text-muted mb-0">Save the destinations you go to often (up to <?= (int)$max ?>) and open them in one tap.</p>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <h2 class="h6 mb-3">Add a destination</h2>
        <form method="post" action="<?= e(url('place_save')) ?>" data-validate novalidate>
            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
            <div class="row g-2 align-items-end">
                <div class="col-md-5">
                    <label for="location_id" class="form-label small mb-1">Destination *</label>
                    <select class="form-select" id="location_id" name="location_id" required>
                        <option value="">Choose a destination</option>
                        <?php foreach ($locations as $l): ?>
                            <option value="<?= (int)$l['location_id'] ?>"><?= e($l['location_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">Choose a destination.</div>
                </div>
                <div class="col-md-4">
                    <label for="label" class="form-label small mb-1">Label (optional)</label>
                    <input type="text" class="form-control" id="label" name="label" maxlength="30" placeholder="e.g., Home, School">
                </div>
                <div class="col-md-3"><button type="submit" class="btn btn-primary w-100">Save</button></div>
            </div>
        </form>
    </div>
</div>

<?php if (!$places): ?>
    <div class="alert alert-info">You have no saved places yet.</div>
<?php endif; ?>
<div class="row g-3">
    <?php foreach ($places as $p): ?>
    <div class="col-md-6">
        <div class="card shadow-sm h-100"><div class="card-body">
            <div class="d-flex justify-content-between gap-2">
                <div>
                    <div class="fw-semibold"><?= e($p['label'] ?: $p['location_name']) ?></div>
                    <?php if ($p['label']): ?><div class="small text-muted"><?= e($p['location_name']) ?></div><?php endif; ?>
                </div>
                <div class="text-end small">
                    <?php if ($p['from_fare'] !== null): ?><div>from <?= e(peso($p['from_fare'])) ?></div><?php endif; ?>
                    <div class="<?= (int)$p['available_count'] > 0 ? 'text-success' : 'text-muted' ?>"><?= (int)$p['available_count'] ?> available</div>
                </div>
            </div>
            <div class="d-flex gap-2 mt-3">
                <a class="btn btn-sm btn-primary" href="<?= e(url('find', ['destination' => $p['location_id']])) ?>">Find a Tricycle</a>
                <form method="post" action="<?= e(url('place_delete')) ?>" class="d-inline"
                      data-confirm="Remove <?= e($p['label'] ?: $p['location_name']) ?> from your saved places?" data-confirm-style="danger">
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <input type="hidden" name="saved_id" value="<?= (int)$p['saved_id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger">Remove</button>
                </form>
            </div>
        </div></div>
    </div>
    <?php endforeach; ?>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
