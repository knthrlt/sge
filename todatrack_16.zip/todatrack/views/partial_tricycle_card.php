<?php /* One available tricycle. Needs: $t, $isPassenger, $favIds, $self, $ratings, $csrf */ ?>
<div class="border rounded p-2 h-100 trike-card">
    <div class="d-flex justify-content-between align-items-start gap-2">
        <div class="fw-semibold"><?= e($t['body_number']) ?> <span class="text-muted fw-normal">| <?= e($t['plate_number']) ?></span></div>
        <span class="badge status-available">Available</span>
    </div>
    <div class="small">Now at: <strong><?= e($t['location_name']) ?></strong></div>
    <div class="small text-muted"><?= e($t['driver_name']) ?></div>
    <div class="small"><?= e(rating_text($ratings[(int)$t['driver_id']] ?? null)) ?></div>
    <div class="d-flex flex-wrap gap-1 mt-2">
        <?php if ($isPassenger): $isFav = in_array((int)$t['driver_id'], $favIds, true); ?>
            <form method="post" action="<?= e(url('favorite_toggle')) ?>" class="d-inline">
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                <input type="hidden" name="driver_id" value="<?= (int)$t['driver_id'] ?>">
                <input type="hidden" name="return_to" value="<?= e($self) ?>">
                <button type="submit" class="btn btn-sm <?= $isFav ? 'btn-warning' : 'btn-outline-secondary' ?>"><?= $isFav ? '★ Favorite' : '☆ Add favorite' ?></button>
            </form>
            <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('rate', ['driver_id' => $t['driver_id'], 'return_to' => $self])) ?>">Rate</a>
        <?php endif; ?>
    </div>
</div>
