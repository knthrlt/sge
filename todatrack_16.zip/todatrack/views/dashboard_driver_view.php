<?php
require __DIR__ . '/header_view.php';
$first = explode(' ', trim($user['full_name']))[0];
?>
<header class="greet">
    <h1><span data-greeting>Welcome back</span>, <?= e($first) ?></h1>
    <p>Your tricycle, your status, and what passengers think of your service.</p>
</header>

<div class="row g-3">
    <!-- Left column: my tricycle, favorites -->
    <div class="col-xl-4">
        <div class="d-flex flex-column gap-3">
            <section class="dcard" aria-labelledby="myTrikeTitle">
                <h2 class="dlabel" id="myTrikeTitle">My tricycle</h2>
                <?php if ($myTricycle): ?>
                    <div class="d-flex align-items-center gap-2 flex-wrap">
                        <span class="dbig"><?= e($myTricycle['body_number']) ?></span>
                        <span class="badge zone-badge" style="background: <?= e($myTricycle['color_hex']) ?>; color: <?= e($myTricycle['text_hex']) ?>;"><?= e($myTricycle['zone_name']) ?></span>
                    </div>
                    <p class="dsub mb-3"><?= e($myTricycle['plate_number']) ?> &middot; <span class="sdot s-<?= e($myTricycle['status']) ?>"><?= e($myTricycle['status_label']) ?></span></p>
                    <div class="d-flex flex-column flex-sm-row flex-xl-column gap-2 mb-3">
                        <a class="btn btn-primary flex-fill btn-add btn-icon" href="<?= e(url('tricycle_form', ['id' => $myTricycle['tricycle_id']])) ?>"><?= icon('pin') ?>Update my location and status</a>
                        <a class="btn btn-outline-danger flex-fill btn-add btn-icon" href="<?= e(url('help')) ?>"><?= icon('alert') ?>Request Help</a>
                    </div>
                    <div class="dinset">
                        <div class="dinset-head"><span>Current location</span></div>
                        <p class="mb-0 fw-bold"><?= e($myTricycle['location_name']) ?></p>
                        <?php if ($activeHelp): ?>
                            <p class="small mt-2 mb-0"><span class="sdot s-<?= e($activeHelp['status']) ?>"><?= e($activeHelp['status_label']) ?></span>
                            <?= e($activeHelp['problem_label']) ?> at <?= e($activeHelp['location_name']) ?></p>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <p class="mb-0 text-muted">The admin has not assigned a tricycle to you yet. Once assigned, it will appear here and you can update its location and status.</p>
                <?php endif; ?>
            </section>

            <section class="dcard" aria-labelledby="favTitle">
                <div class="dcard-head"><h2 id="favTitle">Passengers who favorited you</h2><span class="chip"><?= (int)$favoritedBy ?></span></div>
                <?php if (!$favoriteEntries): ?>
                    <p class="text-muted small mb-0">No passengers have favorited you yet.</p>
                <?php else: ?>
                    <ul class="dfeed">
                        <?php foreach ($favoriteEntries as $_): ?>
                            <li class="d-flex justify-content-between gap-2"><span>Anonymous passenger</span><span class="text-muted small">added <?= e(substr((string)$_['favorited_at'], 0, 10)) ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>
        </div>
    </div>

    <!-- Right column: statistics, zones, feedback -->
    <div class="col-xl-8">
        <div class="row g-3">
            <div class="col-md-6">
                <div class="tiles h-100">
                    <?= dash_tile('Passenger rating', $myRating['count'] ? number_format($myRating['avg'], 1) . ' ★' : '-', $myRating['count'] ? (int)$myRating['count'] . ' rating' . ((int)$myRating['count'] === 1 ? '' : 's') : 'no ratings yet', 'red', 'star', true, '#passenger-feedback') ?>
                    <?= dash_tile('Favorited by', $favoritedBy, 'passengers', 'red', 'heart') ?>
                    <?= dash_tile('Reviews', count($myReviews), 'visible feedback', 'red', 'chat', false, '#passenger-feedback') ?>
                    <?= dash_tile('My status', $myTricycle ? $myTricycle['status_label'] : '-', $myTricycle ? 'at ' . $myTricycle['location_name'] : 'no tricycle yet', 'red', 'trike') ?>
                </div>
            </div>
            <div class="col-md-6"><?php require __DIR__ . '/partial_zone_cards.php'; ?></div>
            <div class="col-12">
                <section class="dcard" id="passenger-feedback" tabindex="-1" aria-labelledby="feedbackTitle">
                    <div class="dcard-head"><h2 id="feedbackTitle">Passenger feedback</h2></div>
                    <?php if (!$myReviews): ?>
                        <p class="text-muted mb-0">No visible ratings or feedback yet.</p>
                    <?php else: ?>
                    <div class="dtab-wrap">
                        <table class="dtab">
                            <thead><tr><th scope="col">Rating</th><th scope="col">Passenger</th><th scope="col">Feedback</th><th scope="col">Date</th></tr></thead>
                            <tbody>
                            <?php foreach ($myReviews as $review): ?>
                                <tr>
                                    <td class="text-nowrap"><?= star_row((int)$review['stars']) ?></td>
                                    <td class="text-nowrap"><?= e($review['passenger_display']) ?></td>
                                    <td><?= $review['comment'] ? e($review['comment']) : '<span class="text-muted">No comment</span>' ?></td>
                                    <td class="text-nowrap text-muted"><?= e(substr((string)$review['created_at'], 0, 10)) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
