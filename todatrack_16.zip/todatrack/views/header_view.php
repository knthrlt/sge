<?php
/*
 * Header + navigation. One clean navbar for every visitor type:
 *   guest      Home | Find a Tricycle | Fare Guide                 [Log in] [Register]
 *   passenger  Dashboard | Find a Tricycle | Fare Guide | Saved Places | Favorite Drivers   [user menu]
 *   driver     Dashboard | Tricycles | Request Help | Fare Guide   [user menu]
 *   admin      Dashboard | Tricycles | Fare Guide | Help Requests | Manage v   [user menu]
 * The user menu (name, role, profile, log out) is always visible, also on phones.
 */
$type     = $user['type'] ?? null;
$authPage = in_array($currentPage, ['login', 'register'], true);

// [label, route, other routes that should highlight the link]
if (!$user) {
    $links = [];   // guests get their own layout below: Explore | search | About, Fare Guide, Zones
} elseif ($type === 'admin') {
    $links = [['Dashboard', 'dashboard', []], ['Tricycles', 'tricycles', ['tricycle_form', 'tricycle_save']],
              ['Fare Guide', 'fares', []], ['Help Requests', 'help_requests', []]];
} elseif ($type === 'driver') {
    $links = [['Dashboard', 'dashboard', []], ['Tricycles', 'tricycles', ['tricycle_form', 'tricycle_save']],
              ['Request Help', 'help', ['help_save', 'help_cancel']], ['Fare Guide', 'fares', []]];
} else {
    $links = [['Dashboard', 'dashboard', []], ['Find a Tricycle', 'find', []], ['Fare Guide', 'fares', []],
              ['Saved Places', 'places', ['place_save']], ['Favorite Drivers', 'favorites', ['rate', 'rate_save']]];
}
// Icon rail (desktop): [label, route, icon, other routes that should highlight it]
if ($type === 'admin') {
    $rail = [['Dashboard', 'dashboard', 'grid', []], ['Tricycles', 'tricycles', 'trike', ['tricycle_form', 'tricycle_save']], ['Fare Guide', 'fares', 'peso', []],
             ['Help Requests', 'help_requests', 'alert', []], ['Zones', 'zones', 'map', []], ['Locations', 'locations', 'pin', []],
             ['Drivers', 'drivers', 'user', []], ['Passengers', 'passengers', 'users', []], ['Ratings', 'ratings', 'star', []]];
} elseif ($type === 'driver') {
    $rail = [['Dashboard', 'dashboard', 'grid', []], ['Tricycles', 'tricycles', 'trike', ['tricycle_form', 'tricycle_save']],
             ['Request Help', 'help', 'alert', ['help_save', 'help_cancel']], ['Fare Guide', 'fares', 'peso', []]];
} elseif ($type === 'passenger') {
    $rail = [['Dashboard', 'dashboard', 'grid', []], ['Find a Tricycle', 'find', 'trike', []], ['Fare Guide', 'fares', 'peso', []],
             ['Saved Places', 'places', 'bookmark', ['place_save']], ['Favorite Drivers', 'favorites', 'heart', ['rate', 'rate_save']], ['My Profile', 'profile', 'user', []]];
} else {
    $rail = [];
}
$manage = ['zones' => 'Zones', 'locations' => 'Locations', 'drivers' => 'Drivers', 'passengers' => 'Passengers', 'ratings' => 'Ratings'];
$roleLabel = $user ? account_label($user) : '';
$initial   = $user ? strtoupper(mb_substr($user['full_name'], 0, 1)) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'TodaTrack') ?> | TodaTrack</title>
    <link rel="icon" type="image/png" href="<?= e(asset('assets/img/favicon.png')) ?>">
    <link rel="apple-touch-icon" href="<?= e(asset('assets/img/apple-touch-icon.png')) ?>">
    <script src="<?= e(asset('assets/js/prefs.js')) ?>"></script>
    <link rel="stylesheet" href="<?= e(asset('assets/vendor/bootstrap/bootstrap.min.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('assets/vendor/datatables/dataTables.bootstrap5.min.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('assets/vendor/datatables/responsive.bootstrap5.min.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('assets/css/style.css')) ?>">
</head>
<body class="role-<?= e($type ?? 'guest') ?> <?= ($user || !$authPage) ? 'app-body' : 'auth-body' ?><?= $user ? ' app-shell' : '' ?>">
<a class="visually-hidden-focusable btn btn-primary m-2 position-absolute" href="#content">Skip to content</a>

<nav class="navbar navbar-expand-lg app-nav sticky-top<?= $user ? ' shell-nav' : ' guest-nav' ?>" aria-label="Main navigation">
    <div class="container">
        <a class="navbar-brand brand-link" href="<?= e(url($user ? 'dashboard' : 'home')) ?>">
            <img class="brand-mark" src="<?= e(asset('assets/img/logo.png')) ?>" alt="" width="38" height="38">TodaTrack
        </a>

        <!-- Right side: always visible, also on phones -->
        <div class="d-flex align-items-center nav-actions ms-auto order-lg-3">
            <?php if (!$user): ?><button type="button" class="btn icon-btn" data-toggle-theme aria-label="Switch between light and dark mode" title="Light / dark">
                <svg class="theme-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
                <svg class="theme-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
            </button><?php endif; ?>
            <div class="dropdown">
                <button class="btn icon-btn" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" aria-label="Display settings: text size and theme" title="Text size and theme">
                    <span style="font-weight:800;font-size:1rem;line-height:1" aria-hidden="true">Aa</span>
                </button>
                <div class="dropdown-menu dropdown-menu-end display-menu">
                    <div class="dm-label" id="dmText">Text size</div>
                    <div class="seg mb-3" role="group" aria-labelledby="dmText">
                        <button type="button" class="t-sm" data-set-text="md" aria-pressed="true" aria-label="Normal text">A</button>
                        <button type="button" class="t-md" data-set-text="lg" aria-pressed="false" aria-label="Large text">A</button>
                        <button type="button" class="t-lg" data-set-text="xl" aria-pressed="false" aria-label="Extra large text">A</button>
                    </div>
                    <div class="dm-label" id="dmTheme">Theme</div>
                    <div class="seg" role="group" aria-labelledby="dmTheme">
                        <button type="button" data-set-theme="light" aria-pressed="false">Light</button>
                        <button type="button" data-set-theme="dark" aria-pressed="false">Dark</button>
                        <button type="button" data-set-theme="auto" aria-pressed="true">Auto</button>
                    </div>
                </div>
            </div>
            <?php if ($user): ?>
                <div class="dropdown">
                    <button class="btn user-btn dropdown-toggle d-flex align-items-center gap-2" type="button"
                            data-bs-toggle="dropdown" aria-expanded="false" aria-label="Account menu">
                        <span class="avatar"><?= e($initial) ?></span>
                        <span class="d-none d-xl-flex flex-column text-start lh-sm user-name"><span><?= e($user['full_name']) ?></span><small class="text-muted fw-normal">@<?= e($user['username']) ?></small></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                        <li class="px-3 py-2">
                            <div class="fw-semibold"><?= e($user['full_name']) ?></div>
                            <div class="small text-muted">@<?= e($user['username']) ?></div>
                            <span class="badge-role mt-1"><?= e($roleLabel) ?></span>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <?php if ($type === 'passenger'): ?>
                            <li><a class="dropdown-item" href="<?= e(url('profile')) ?>">My Profile</a></li>
                        <?php endif; ?>
                        <li>
                            <form method="post" action="<?= e(url('logout')) ?>" class="m-0" data-confirm="Log out of TodaTrack?">
                                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                <button type="submit" class="dropdown-item">Log out</button>
                            </form>
                        </li>
                    </ul>
                </div>
            <?php else: ?>
                <a class="btn btn-primary btn-sm nav-cta d-none d-sm-inline-block" href="<?= e(url('login')) ?>">Log in</a>
                <a class="btn btn-soft btn-sm nav-cta d-none d-sm-inline-block" href="<?= e(url('register')) ?>">Register</a>
            <?php endif; ?>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
                    aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>

        <div class="collapse navbar-collapse order-lg-2" id="mainNav">
            <?php if (!$user): $locs = $locations ?? []; ?>
                <ul class="navbar-nav guest-first">
                    <li class="nav-item"><a class="nav-link <?= $currentPage === 'find' ? 'active' : '' ?>" <?= $currentPage === 'find' ? 'aria-current="page"' : '' ?> href="<?= e(url('find')) ?>">Explore</a></li>
                </ul>
                <form class="nav-search" role="search" method="get" action="index.php">
                    <input type="hidden" name="page" value="find">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
                    <input type="search" name="q" value="" <?= $locs ? 'list="navPlaces"' : '' ?> placeholder="Search a destination, e.g. Tanke" aria-label="Search a destination" autocomplete="off" maxlength="60">
                    <?php if ($locs): ?><datalist id="navPlaces"><?php foreach ($locs as $l): ?><option value="<?= e($l['location_name']) ?>"><?php endforeach; ?></datalist><?php endif; ?>
                </form>
                <ul class="navbar-nav guest-last">
                    <li class="nav-item"><a class="nav-link" href="<?= e(url('home') . '#about') ?>">About</a></li>
                    <li class="nav-item"><a class="nav-link <?= $currentPage === 'fares' ? 'active' : '' ?>" <?= $currentPage === 'fares' ? 'aria-current="page"' : '' ?> href="<?= e(url('fares')) ?>">Fare Guide</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= e(url('home') . '#zones') ?>">Zones</a></li>
                </ul>
            <?php else: ?>
            <ul class="navbar-nav">
                <?php foreach ($links as [$label, $route, $more]): $on = $currentPage === $route || in_array($currentPage, $more, true); ?>
                    <li class="nav-item"><a class="nav-link <?= $on ? 'active' : '' ?>" <?= $on ? 'aria-current="page"' : '' ?> href="<?= e(url($route)) ?>"><?= e($label) ?></a></li>
                <?php endforeach; ?>
                <?php if ($type === 'admin'): $manageOn = array_key_exists($currentPage, $manage); ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?= $manageOn ? 'active' : '' ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Manage</a>
                        <ul class="dropdown-menu shadow-sm">
                            <?php foreach ($manage as $route => $label): ?>
                                <li><a class="dropdown-item <?= $currentPage === $route ? 'active' : '' ?>" href="<?= e(url($route)) ?>"><?= e($label) ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
            <?php endif; ?>
            <?php if (!$user): ?>
                <!-- Log in / Register for very small screens (inside the menu) -->
                <div class="d-sm-none d-flex gap-2 pb-2">
                    <a class="btn btn-primary btn-sm flex-fill" href="<?= e(url('login')) ?>">Log in</a>
                    <a class="btn btn-soft btn-sm flex-fill" href="<?= e(url('register')) ?>">Register</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>

<?php if ($user): ?>
<div class="shell">
<aside class="rail" aria-label="Quick navigation">
    <div class="rail-group" role="group" aria-label="Theme">
        <button type="button" class="rail-btn" data-set-theme="light" aria-pressed="false" aria-label="Light theme" title="Light theme"><?= icon('sun') ?></button>
        <button type="button" class="rail-btn" data-set-theme="dark" aria-pressed="false" aria-label="Dark theme" title="Dark theme"><?= icon('moon') ?></button>
    </div>
    <nav class="rail-group rail-links" aria-label="Pages">
        <?php foreach ($rail as [$label, $route, $ico, $more]): $on = $currentPage === $route || in_array($currentPage, $more, true); ?>
            <a class="rail-btn<?= $on ? ' active' : '' ?>" href="<?= e(url($route)) ?>" title="<?= e($label) ?>" aria-label="<?= e($label) ?>"<?= $on ? ' aria-current="page"' : '' ?>><?= icon($ico) ?></a>
        <?php endforeach; ?>
    </nav>
    <div class="rail-group">
        <form method="post" action="<?= e(url('logout')) ?>" class="m-0" data-confirm="Log out of TodaTrack?">
            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
            <button type="submit" class="rail-btn" title="Log out" aria-label="Log out"><?= icon('logout') ?></button>
        </form>
    </div>
</aside>
<?php endif; ?>
<main id="content" class="<?= !empty($fullWidth) ? 'landing' : 'container ' . ($authPage && !$user ? 'py-5' : 'py-4') ?>">

<?php if (!empty($fullWidth) && $flashes): ?><div class="container pt-3"><?php endif; ?>
<?php foreach ($flashes as $flash): ?>
    <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show" role="alert">
        <?= e($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endforeach; ?>
<?php if (!empty($fullWidth) && $flashes): ?></div><?php endif; ?>
