<?php require __DIR__ . '/header_view.php'; ?>
<div class="page-head">
    <h1 class="h3 mb-0">Ratings</h1>
    <p class="text-muted mb-0">Passenger ratings and comments. Hidden ratings are not counted in a driver's average.</p>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table id="ratingTable" class="table table-hover align-middle w-100">
                <thead>
                    <tr>
                        <th data-priority="1">Driver</th>
                        <th data-priority="2" class="text-nowrap">Stars</th>
                        <th data-priority="5">Comment</th>
                        <th data-priority="4">Passenger</th>
                        <th data-priority="3">Status</th>
                        <th data-priority="6">Date</th>
                        <th class="no-sort" data-priority="2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($ratings as $r): ?>
                    <tr>
                        <td><?= e($r['driver_name']) ?></td>
                        <td data-order="<?= (int)$r['stars'] ?>" class="text-nowrap"><span class="text-warning"><?= str_repeat('★', (int)$r['stars']) ?></span><span class="text-muted"><?= str_repeat('★', 5 - (int)$r['stars']) ?></span></td>
                        <td><?= $r['comment'] ? e($r['comment']) : '<span class="text-muted">-</span>' ?></td>
                        <td>
                            <?= e($r['passenger_name']) ?> <span class="small text-muted">(<?= e($r['passenger_username']) ?>)</span>
                            <?php if ($r['is_anonymous']): ?><span class="badge text-bg-info">Submitted anonymously</span><?php endif; ?>
                        </td>
                        <td><span class="badge <?= $r['status'] === 'visible' ? 'text-bg-success' : 'text-bg-secondary' ?>"><?= e(DriverRating::STATUSES[$r['status']]) ?></span></td>
                        <td class="text-nowrap small"><?= e(substr((string)$r['created_at'], 0, 10)) ?></td>
                        <td class="text-nowrap">
                            <form method="post" action="<?= e(url('rating_update')) ?>" class="d-inline"
                                  data-confirm="<?= $r['status'] === 'visible' ? 'Hide this rating? It will not count in the average.' : 'Show this rating again?' ?>">
                                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                <input type="hidden" name="rating_id" value="<?= (int)$r['rating_id'] ?>">
                                <input type="hidden" name="status" value="<?= $r['status'] === 'visible' ? 'hidden' : 'visible' ?>">
                                <button type="submit" class="btn btn-sm btn-outline-secondary"><?= $r['status'] === 'visible' ? 'Hide' : 'Show' ?></button>
                            </form>
                            <form method="post" action="<?= e(url('rating_delete')) ?>" class="d-inline"
                                  data-confirm="Delete this rating permanently?" data-confirm-style="danger">
                                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                <input type="hidden" name="rating_id" value="<?= (int)$r['rating_id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
