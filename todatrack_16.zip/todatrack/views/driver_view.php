<?php require __DIR__ . '/header_view.php'; ?>
<div class="page-head">
    <h1 class="h3 mb-0">Drivers</h1>
    <p class="text-muted mb-0">Drivers create their own account on the Register page. Assign them to a tricycle in the Tricycles module.</p>
</div>

<div class="alert alert-info small">
    <strong>Deactivate</strong> is the safe choice: the driver cannot log in, the tricycle is hidden from passengers, and ratings are kept. You can reactivate any time.
    <strong>Delete</strong> removes the account permanently and is only available for a driver without a tricycle.
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table id="driverTable" class="table table-hover align-middle w-100">
                <thead>
                    <tr>
                        <th data-priority="1">Name</th>
                        <th data-priority="3">Username</th>
                        <th data-priority="4">Contact number</th>
                        <th data-priority="6">License no.</th>
                        <th data-priority="4">Tricycle</th>
                        <th data-priority="2">Status</th>
                        <th class="no-sort" data-priority="2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($drivers as $d): $hasLogin = !empty($d['user_id']); $active = (bool)$d['is_active']; ?>
                    <tr>
                        <td class="fw-semibold"><?= e($d['full_name']) ?></td>
                        <td><?= $d['username'] ? e($d['username']) : '<span class="text-muted">-</span>' ?></td>
                        <td><?= e($d['contact_no']) ?></td>
                        <td><?= e($d['license_no']) ?></td>
                        <td><?= $d['body_number'] ? e($d['body_number']) . ' <span class="text-muted small">' . e($d['plate_number']) . '</span>' : '<span class="badge text-bg-secondary">Not assigned</span>' ?></td>
                        <td data-search="<?= !$hasLogin ? 'No login' : ($active ? 'Active' : 'Deactivated') ?>">
                            <?php if (!$hasLogin): ?><span class="badge status-off_duty">No login</span>
                            <?php elseif ($active): ?><span class="badge status-available">Active</span>
                            <?php else: ?><span class="badge text-bg-danger">Deactivated</span><?php endif; ?>
                        </td>
                        <td class="text-nowrap">
                            <?php if ($hasLogin): ?>
                                <form method="post" action="<?= e(url('driver_status')) ?>" class="d-inline"
                                      data-confirm="<?= $active
                                          ? 'Deactivate ' . e($d['full_name']) . '? They will be logged out and cannot log in, and their tricycle will be hidden from passengers. You can reactivate the account later.'
                                          : 'Reactivate ' . e($d['full_name']) . '? They can log in again. Their tricycle stays Off Duty until they set their status.' ?>"
                                      <?= $active ? 'data-confirm-style="danger"' : '' ?>>
                                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                    <input type="hidden" name="driver_id" value="<?= (int)$d['driver_id'] ?>">
                                    <input type="hidden" name="active" value="<?= $active ? '0' : '1' ?>">
                                    <button type="submit" class="btn btn-sm <?= $active ? 'btn-outline-secondary' : 'btn-success' ?>"><?= $active ? 'Deactivate' : 'Reactivate' ?></button>
                                </form>
                            <?php endif; ?>
                            <?php if (empty($d['tricycle_id'])): ?>
                                <form method="post" action="<?= e(url('driver_delete')) ?>" class="d-inline"
                                      data-confirm="Permanently delete <?= e($d['full_name']) ?> and their account? Their ratings and favorites are removed too. This cannot be undone. (To keep the records, choose Deactivate instead.)"
                                      data-confirm-style="danger">
                                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                    <input type="hidden" name="driver_id" value="<?= (int)$d['driver_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                </form>
                            <?php else: ?>
                                <span class="small text-muted" title="Delete or reassign the tricycle first">Has tricycle</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
