<?php require __DIR__ . '/header_view.php'; $isAdmin = ($user['role'] ?? '') === 'admin'; ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h1 class="h3 mb-0">Fare Guide</h1>
        <p class="text-muted mb-0">Student, Senior Citizen, and PWD fare is <?= (int)$discountPct ?>% off the regular fare.</p>
    </div>
    <?php if ($isAdmin): ?>
        <button type="button" class="btn btn-primary btn-add" data-bs-toggle="modal" data-bs-target="#fareModal">+ Add Fare</button>
    <?php endif; ?>
</div>

<?php if (!empty($myDiscount)): ?>
    <div class="alert alert-success py-2 small">Your discount: <strong><?= e(discount_label($myDiscount)) ?></strong>. Your fare is the "Student / Senior / PWD" column.</div>
<?php endif; ?>
<div class="card shadow-sm">
    <div class="card-body">
        <div class="row g-2 mb-3">
            <div class="col-sm-6 col-md-3">
                <label for="filterFareZone" class="form-label small mb-1">Origin zone</label>
                <select id="filterFareZone" class="form-select form-select-sm" data-table="#fareTable" data-col="0">
                    <option value="">All zones</option>
                    <?php foreach ($zones as $z): ?>
                        <option value="<?= e($z['zone_name']) ?>"><?= e($z['zone_name']) ?> (<?= e($z['color_name']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="table-responsive">
            <table id="fareTable" class="table table-hover align-middle w-100">
                <thead>
                    <tr>
                        <th data-priority="3">From (zone)</th>
                        <th data-priority="1">To (destination)</th>
                        <th class="text-end" data-priority="2">Regular</th>
                        <th class="text-end" data-priority="5">Student / Senior / PWD</th>
                        <?php if ($isAdmin): ?><th class="no-sort" data-priority="2">Actions</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($fares as $f): ?>
                    <tr>
                        <td data-search="<?= e($f['zone_name']) ?>"><span class="badge zone-badge" style="background: <?= e($f['color_hex']) ?>; color: <?= e($f['text_hex']) ?>;"><?= e($f['zone_name']) ?></span></td>
                        <td><?= e($f['location_name']) ?></td>
                        <td class="text-end" data-order="<?= e($f['fare']) ?>"><?= e(peso($f['fare'])) ?></td>
                        <td class="text-end" data-order="<?= e($f['discounted_fare']) ?>"><?= e(peso($f['discounted_fare'])) ?></td>
                        <?php if ($isAdmin): ?>
                        <td class="text-nowrap">
                            <button type="button" class="btn btn-sm btn-outline-primary edit-btn"
                                    data-bs-toggle="modal" data-bs-target="#fareModal"
                                    data-id="<?= (int)$f['fare_id'] ?>" data-zone="<?= (int)$f['zone_id'] ?>"
                                    data-location="<?= (int)$f['location_id'] ?>" data-fare="<?= e($f['fare']) ?>">Edit</button>
                            <form method="post" action="<?= e(url('fare_delete')) ?>" class="d-inline"
                                  data-confirm="Delete the fare from <?= e($f['zone_name']) ?> to <?= e($f['location_name']) ?>?" data-confirm-style="danger">
                                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                <input type="hidden" name="fare_id" value="<?= (int)$f['fare_id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($isAdmin): ?>
<!-- Add / Edit fare (admin only) -->
<div class="modal fade crud-modal" id="fareModal" tabindex="-1" aria-labelledby="fareModalTitle" aria-hidden="true"
     data-title-add="Add Fare" data-title-edit="Edit Fare">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content" method="post" action="<?= e(url('fare_save')) ?>" id="fareForm"
              data-validate data-confirm="Save this fare?" novalidate>
            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
            <input type="hidden" name="fare_id" id="fare_id" value="0" data-field="id" data-default="0">
            <div class="modal-header">
                <h5 class="modal-title" id="fareModalTitle">Add Fare</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="fare_zone" class="form-label">From (origin zone) *</label>
                    <select class="form-select" id="fare_zone" name="zone_id" data-field="zone" required>
                        <option value="">Choose a zone</option>
                        <?php foreach ($zones as $z): ?>
                            <option value="<?= (int)$z['zone_id'] ?>"><?= e($z['zone_name']) ?> (<?= e($z['color_name']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">Choose an origin zone.</div>
                </div>
                <div class="mb-3">
                    <label for="fare_location" class="form-label">To (destination) *</label>
                    <select class="form-select" id="fare_location" name="location_id" data-field="location" required>
                        <option value="">Choose a destination</option>
                        <?php foreach ($locations as $l): ?>
                            <option value="<?= (int)$l['location_id'] ?>"><?= e($l['location_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">Choose a destination.</div>
                </div>
                <div class="mb-1">
                    <label for="fare_amount" class="form-label">Regular fare (₱) *</label>
                    <input type="number" class="form-control" id="fare_amount" name="fare" min="1" max="9999.99" step="0.01"
                           placeholder="e.g., 15.00" data-field="fare" required>
                    <div class="invalid-feedback">Enter an amount greater than 0.</div>
                    <div class="form-text"><?= (int)$discountPct ?>% discount for students, seniors, and PWD is computed automatically.</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Fare</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/footer_view.php'; ?>
