<?php require __DIR__ . '/header_view.php'; ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h1 class="h3 mb-0">Zones</h1>
        <p class="text-muted mb-0">Each zone has a color. Tricycles and fares use these zones, and users see the changes right away.</p>
    </div>
    <button type="button" class="btn btn-primary btn-add" data-bs-toggle="modal" data-bs-target="#zoneModal">+ Add Zone</button>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table id="zoneTable" class="table table-hover align-middle w-100">
                <thead>
                    <tr>
                        <th data-priority="1">Zone</th>
                        <th data-priority="3">Color</th>
                        <th class="text-end" data-priority="4">Tricycles</th>
                        <th class="text-end" data-priority="5">Fares</th>
                        <th class="no-sort" data-priority="2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($zones as $z): ?>
                    <tr>
                        <td data-search="<?= e($z['zone_name']) ?>"><span class="badge zone-badge" style="background: <?= e($z['color_hex']) ?>; color: <?= e($z['text_hex']) ?>;"><?= e($z['zone_name']) ?></span></td>
                        <td><?= e($z['color_name']) ?> <span class="text-muted small"><?= e($z['color_hex']) ?></span></td>
                        <td class="text-end"><?= (int)$z['total'] ?></td>
                        <td class="text-end"><?= (int)$z['fare_count'] ?></td>
                        <td class="text-nowrap">
                            <button type="button" class="btn btn-sm btn-outline-primary edit-btn"
                                    data-bs-toggle="modal" data-bs-target="#zoneModal"
                                    data-id="<?= (int)$z['zone_id'] ?>" data-name="<?= e($z['zone_name']) ?>"
                                    data-color="<?= e($z['color_name']) ?>" data-hex="<?= e($z['color_hex']) ?>">Edit</button>
                            <form method="post" action="<?= e(url('zone_delete')) ?>" class="d-inline"
                                  data-confirm="Delete the zone <?= e($z['zone_name']) ?>? This cannot be undone." data-confirm-style="danger">
                                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                <input type="hidden" name="zone_id" value="<?= (int)$z['zone_id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade crud-modal" id="zoneModal" tabindex="-1" aria-labelledby="zoneModalTitle" aria-hidden="true"
     data-title-add="Add Zone" data-title-edit="Edit Zone">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content" method="post" action="<?= e(url('zone_save')) ?>" data-validate data-confirm="Save this zone?" novalidate>
            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
            <input type="hidden" name="zone_id" value="0" data-field="id" data-default="0">
            <div class="modal-header">
                <h5 class="modal-title" id="zoneModalTitle">Add Zone</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="zone_name" class="form-label">Zone name *</label>
                    <input type="text" class="form-control" id="zone_name" name="zone_name" maxlength="50"
                           placeholder="e.g., City Proper" data-field="name" required>
                    <div class="invalid-feedback">Zone name is required.</div>
                </div>
                <div class="row">
                    <div class="col-8 mb-1">
                        <label for="color_name" class="form-label">Color name *</label>
                        <input type="text" class="form-control" id="color_name" name="color_name" maxlength="30"
                               placeholder="e.g., Red" data-field="color" required>
                        <div class="invalid-feedback">Color name is required.</div>
                    </div>
                    <div class="col-4 mb-1">
                        <label for="color_hex" class="form-label">Color *</label>
                        <input type="color" class="form-control form-control-color w-100" id="color_hex" name="color_hex"
                               value="#489BDE" data-field="hex" data-default="#489BDE" required>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Zone</button>
            </div>
        </form>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
