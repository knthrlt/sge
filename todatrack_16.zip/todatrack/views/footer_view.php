</main>
<?php if ($user): ?></div><!-- /.shell --><?php endif; ?>

<!-- Confirmation dialog used for save, update, and delete -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmTitle">Please confirm</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="confirmMessage">Are you sure?</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmYes">Yes, continue</button>
            </div>
        </div>
    </div>
</div>

<?php if (!$user): ?>
<footer class="site-footer foot-big">
    <div class="stripe" aria-hidden="true"></div>
    <div class="container foot-grid">
        <div class="foot-lead">
            <a class="foot-wordmark" href="<?= e(url('home')) ?>"><img src="<?= e(asset('assets/img/logo.png')) ?>" alt="">TodaTrack</a>
            <small>Tricycle zone monitoring. Ingat sa biyahe!</small>
            <small class="foot-copy">&copy; <?= date('Y') ?> TodaTrack</small>
        </div>
        <nav class="foot-col" aria-label="Explore">
            <h2>Explore</h2>
            <a href="<?= e(url('find')) ?>">Find a Tricycle</a>
            <a href="<?= e(url('fares')) ?>">Fare Guide</a>
            <a href="<?= e(url('home') . '#zones') ?>">Zones</a>
        </nav>
        <nav class="foot-col" aria-label="Accounts">
            <h2>Accounts</h2>
            <a href="<?= e(url('login')) ?>">Log in</a>
            <a href="<?= e(url('register', ['type' => 'passenger'])) ?>">Passenger register</a>
            <a href="<?= e(url('register', ['type' => 'driver'])) ?>">Driver register</a>
        </nav>
        <nav class="foot-col" aria-label="About">
            <h2>About</h2>
            <a href="<?= e(url('home') . '#about') ?>">How it works</a>
            <a href="<?= e(url('home') . '#join') ?>">Join TodaTrack</a>
            <a href="<?= e(url('login')) ?>">Admin log in</a>
        </nav>
    </div>
</footer>
<?php else: ?>
<footer class="site-footer">
    <div class="stripe" aria-hidden="true"></div>
    <div class="container foot-inner">
        <div>
            <div class="foot-brand"><img src="<?= e(asset('assets/img/logo.png')) ?>" alt="">TodaTrack</div>
            <small>Tricycle zone monitoring. Ingat sa biyahe!</small>
        </div>
        <small>
            <a href="<?= e(url('dashboard')) ?>">Dashboard</a> &middot;
            <a href="<?= e(url('find')) ?>">Find a Tricycle</a> &middot;
            <a href="<?= e(url('fares')) ?>">Fare Guide</a>
        </small>
    </div>
</footer>
<?php endif; ?>

<script src="<?= e(asset('assets/vendor/jquery/jquery.min.js')) ?>"></script>
<script src="<?= e(asset('assets/vendor/bootstrap/bootstrap.bundle.min.js')) ?>"></script>
<script src="<?= e(asset('assets/vendor/datatables/jquery.dataTables.min.js')) ?>"></script>
<script src="<?= e(asset('assets/vendor/datatables/dataTables.bootstrap5.min.js')) ?>"></script>
<script src="<?= e(asset('assets/vendor/datatables/dataTables.responsive.min.js')) ?>"></script>
<script src="<?= e(asset('assets/vendor/datatables/responsive.bootstrap5.min.js')) ?>"></script>
<script src="<?= e(asset('assets/js/app.js')) ?>"></script>
</body>
</html>
