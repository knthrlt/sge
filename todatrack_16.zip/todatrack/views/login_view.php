<?php require __DIR__ . '/header_view.php'; ?>
<div class="row g-4 align-items-stretch justify-content-center">
    <div class="col-lg-6 d-none d-lg-block">
        <div class="auth-art">
            <img src="<?= e(asset('assets/img/logo.png')) ?>" alt="TodaTrack logo">
            <h2>Balik ka na!<br><span class="hl">Sakay</span> na tayo.</h2>
            <p>Log in as a passenger, driver, or admin.</p>
        </div>
    </div>
    <div class="col-lg-5 col-md-8">
        <div class="card">
            <div class="card-body p-4 p-md-5">
                <div class="page-head mb-3"><h1 class="h3 mb-0">Log in</h1></div>
                <form method="post" action="<?= e(url('login')) ?>" data-validate novalidate>
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <div class="mb-3">
                        <label for="login" class="form-label">Username or email</label>
                        <input type="text" class="form-control" id="login" name="login"
                               value="<?= e($old['login']) ?>" placeholder="Enter username or email" required autofocus>
                        <div class="invalid-feedback">Enter your username or email.</div>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password"
                               placeholder="Enter password" required>
                        <div class="invalid-feedback">Enter your password.</div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Log in</button>
                </form>
                <p class="text-center small mt-4 mb-0">No account yet? <a href="<?= e(url('register')) ?>">Register</a><br>Just looking? <a href="<?= e(url('find')) ?>">Find a tricycle</a> without an account.</p>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
