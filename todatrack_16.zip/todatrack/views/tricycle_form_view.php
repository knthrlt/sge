<?php
require __DIR__ . '/header_view.php';
$isEdit = (int)($values['tricycle_id'] ?? 0) > 0;
?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <h1 class="h3 mb-1"><?= $isEdit ? 'Edit Tricycle' : 'Add Tricycle' ?></h1>
        <p class="text-muted"><?= $limited ? 'You can update your current location and status.' : 'Fields marked * are required.' ?></p>

        <?php if ($errors): ?>
            <div class="alert alert-danger" role="alert">
                <ul class="mb-0 ps-3">
                    <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (!$limited && (!$zones || !$locations || !$drivers)): ?>
            <div class="alert alert-info">
                Before saving a tricycle you need:
                <?php if (!$zones): ?><a href="<?= e(url('zones')) ?>">a zone</a>; <?php endif; ?>
                <?php if (!$locations): ?><a href="<?= e(url('locations')) ?>">a location</a>; <?php endif; ?>
                <?php if (!$drivers): ?>a driver without a tricycle (drivers add themselves on the Register page)<?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm">
            <div class="card-body p-4">
                <form method="post" action="<?= e(url('tricycle_save')) ?>" data-validate
                      data-confirm="<?= $isEdit ? 'Save the changes to this tricycle?' : 'Add this tricycle?' ?>" novalidate>
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <input type="hidden" name="tricycle_id" value="<?= (int)($values['tricycle_id'] ?? 0) ?>">

                    <?php if ($limited): ?>
                        <div class="row mb-3">
                            <div class="col-md-4"><div class="small text-muted">Body number</div><div class="fw-semibold"><?= e($values['body_number'] ?? '') ?></div></div>
                            <div class="col-md-4"><div class="small text-muted">Plate number</div><div class="fw-semibold"><?= e($values['plate_number'] ?? '') ?></div></div>
                            <div class="col-md-4"><div class="small text-muted">Zone</div>
                                <span class="badge zone-badge" style="background: <?= e($values['color_hex'] ?? '#222329') ?>; color: <?= e($values['text_hex'] ?? '#FFFFFF') ?>;"><?= e($values['zone_name'] ?? '') ?></span>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="body_number" class="form-label">Body number *</label>
                                <input type="text" class="form-control text-uppercase" id="body_number" name="body_number"
                                       pattern="[A-Za-z0-9\-]{1,10}" maxlength="10" placeholder="e.g., T-015"
                                       value="<?= e($values['body_number'] ?? '') ?>" required>
                                <div class="invalid-feedback">Required: up to 10 letters, numbers, or dashes.</div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="plate_number" class="form-label">Plate number *</label>
                                <input type="text" class="form-control text-uppercase" id="plate_number" name="plate_number"
                                       pattern="[A-Za-z0-9\-]{4,10}" maxlength="10" placeholder="e.g., ABC-1234"
                                       value="<?= e($values['plate_number'] ?? '') ?>" required>
                                <div class="invalid-feedback">Required: 4-10 letters, numbers, or dashes.</div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="driver_id" class="form-label">Driver *</label>
                                <select class="form-select" id="driver_id" name="driver_id" required>
                                    <option value="">Choose a driver</option>
                                    <?php foreach ($drivers as $d): ?>
                                        <option value="<?= (int)$d['driver_id'] ?>" <?= (int)($values['driver_id'] ?? 0) === (int)$d['driver_id'] ? 'selected' : '' ?>><?= e($d['full_name']) ?> (<?= e($d['license_no']) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">Choose a driver.</div>
                                <div class="form-text">Only drivers without a tricycle are listed.</div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="zone_id" class="form-label">Zone (color) *</label>
                                <select class="form-select" id="zone_id" name="zone_id" required>
                                    <option value="">Choose a zone</option>
                                    <?php foreach ($zones as $z): ?>
                                        <option value="<?= (int)$z['zone_id'] ?>" data-color="<?= e($z['color_hex']) ?>" <?= (int)($values['zone_id'] ?? 0) === (int)$z['zone_id'] ? 'selected' : '' ?>><?= e($z['zone_name']) ?> (<?= e($z['color_name']) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">Choose a zone.</div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="location_id" class="form-label">Current location *</label>
                            <select class="form-select" id="location_id" name="location_id" required>
                                <option value="">Choose a location</option>
                                <?php foreach ($locations as $l): ?>
                                    <option value="<?= (int)$l['location_id'] ?>" <?= (int)($values['location_id'] ?? 0) === (int)$l['location_id'] ? 'selected' : '' ?>><?= e($l['location_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Choose the current location.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">Status *</label>
                            <select class="form-select" id="status" name="status" required>
                                <?php foreach ($statuses as $key => $label): ?>
                                    <option value="<?= e($key) ?>" <?= ($values['status'] ?? 'available') === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Choose a status.</div>
                        </div>
                    </div>

                    <div class="d-flex flex-column flex-sm-row gap-2">
                        <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Update Tricycle' : 'Save Tricycle' ?></button>
                        <a class="btn btn-outline-secondary" href="<?= e(url('tricycles')) ?>">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
