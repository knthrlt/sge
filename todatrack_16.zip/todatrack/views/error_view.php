<?php require __DIR__ . '/header_view.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm">
            <div class="card-body text-center p-4">
                <h1 class="display-5 fw-bold text-brand"><?= (int)$code ?></h1>
                <p class="lead mb-4"><?= e($message) ?></p>
                <a class="btn btn-primary" href="<?= e(url($user ? 'dashboard' : 'login')) ?>">Go back</a>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
