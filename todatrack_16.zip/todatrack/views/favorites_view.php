<?php require __DIR__ . '/header_view.php'; ?>
<div class="page-head">
    <h1 class="h3 mb-0">Favorite Drivers</h1>
    <p class="text-muted mb-0">See at a glance whether your favorite drivers are available. Add favorites from Find a Tricycle.</p>
</div>

<?php if (!$favorites): ?>
    <div class="alert alert-info d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span>You have no favorite drivers yet.</span>
        <a class="btn btn-sm btn-primary" href="<?= e(url('find')) ?>">Find a Tricycle</a>
    </div>
<?php endif; ?>
<div class="row g-3">
    <?php foreach ($favorites as $f): ?>
    <div class="col-md-6">
        <div class="card shadow-sm h-100"><div class="card-body">
            <div class="d-flex justify-content-between align-items-start gap-2">
                <div>
                    <div class="fw-semibold"><?= e($f['full_name']) ?></div>
                    <div class="small text-muted"><?= e(rating_text($ratings[(int)$f['driver_id']] ?? null)) ?></div>
                </div>
                <span class="badge status-<?= e($f['status'] ?? 'off_duty') ?>"><?= e($f['status_label']) ?></span>
            </div>
            <?php if ($f['body_number']): ?>
                <div class="mt-2 small">
                    <span class="badge zone-badge" style="background: <?= e($f['color_hex']) ?>; color: <?= e($f['text_hex']) ?>;"><?= e($f['zone_name']) ?></span>
                    <?= e($f['body_number']) ?> | <?= e($f['plate_number']) ?> | now at <strong><?= e($f['location_name']) ?></strong>
                </div>
            <?php endif; ?>
            <div class="d-flex flex-wrap gap-2 mt-3">
                <a class="btn btn-sm btn-outline-primary" href="<?= e(url('rate', ['driver_id' => $f['driver_id']])) ?>"><?= $f['my_stars'] ? 'Your rating: ' . (int)$f['my_stars'] . ' ★ (edit)' : 'Rate driver' ?></a>
                <form method="post" action="<?= e(url('favorite_toggle')) ?>" class="d-inline"
                      data-confirm="Remove <?= e($f['full_name']) ?> from your favorites?" data-confirm-style="danger">
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <input type="hidden" name="driver_id" value="<?= (int)$f['driver_id'] ?>">
                    <input type="hidden" name="return_to" value="<?= e(url('favorites')) ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger">Remove</button>
                </form>
            </div>
        </div></div>
    </div>
    <?php endforeach; ?>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
