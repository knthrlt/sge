<?php
require __DIR__ . '/header_view.php';
$self = url('find', array_filter(['from_zone' => $fromZone ?: null, 'destination' => $destination ?: null, 'zone' => $zoneFilter ?: null]));
$myDiscountLabel = discount_label($myDiscount);
?>
<div class="page-head">
    <h1 class="h3 mb-0">Find a Tricycle</h1>
    <p class="text-muted mb-0">Choose where you are going. The color shows which zone's tricycles serve that route.</p>
</div>

<?php if ($isPassenger && $savedPlaces): ?>
    <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
        <span class="small text-muted me-1">Your saved places:</span>
        <?php foreach ($savedPlaces as $sp): ?>
            <a class="btn btn-sm btn-outline-primary" href="<?= e(url('find', ['destination' => $sp['location_id']])) ?>"><?= e($sp['label'] ?: $sp['location_name']) ?></a>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="get" action="index.php" data-validate novalidate>
            <input type="hidden" name="page" value="find">
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label for="from_zone" class="form-label">Pick-up zone (optional)</label>
                    <select class="form-select" id="from_zone" name="from_zone">
                        <option value="0">Any zone</option>
                        <?php foreach ($zones as $z): ?>
                            <option value="<?= (int)$z['zone_id'] ?>" <?= $fromZone === (int)$z['zone_id'] ? 'selected' : '' ?>><?= e($z['zone_name']) ?> (<?= e($z['color_name']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-5">
                    <label for="destination" class="form-label">Destination *</label>
                    <select class="form-select" id="destination" name="destination" required>
                        <option value="">Choose a destination</option>
                        <?php foreach ($locations as $l): ?>
                            <option value="<?= (int)$l['location_id'] ?>" <?= $destination === (int)$l['location_id'] ? 'selected' : '' ?>><?= e($l['location_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">Choose a destination.</div>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">Search</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if ($isPassenger && $searched && !in_array($destination, $savedIds, true)): ?>
    <form method="post" action="<?= e(url('place_save')) ?>" class="mb-3 d-flex flex-wrap gap-2 align-items-center">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="location_id" value="<?= (int)$destination ?>">
        <input type="hidden" name="return_to" value="<?= e($self) ?>">
        <input type="text" name="label" class="form-control form-control-sm" style="max-width: 11rem;" maxlength="30" placeholder="Label (optional)" aria-label="Label">
        <button type="submit" class="btn btn-sm btn-outline-primary">Save this destination</button>
    </form>
<?php elseif ($isPassenger && $searched): ?>
    <p class="small text-success mb-3">This destination is in your saved places.</p>
<?php endif; ?>

<div class="d-flex flex-wrap gap-2 mb-4 align-items-center">
    <span class="small text-muted me-1">Zone colors:</span>
    <?php foreach ($zones as $z): ?>
        <span class="badge zone-badge" style="background: <?= e($z['color_hex']) ?>; color: <?= e($z['text_hex']) ?>;"><?= e($z['zone_name']) ?></span>
    <?php endforeach; ?>
</div>

<?php if (!empty($queryMiss)): ?>
    <div class="alert alert-warning">No destination matches &ldquo;<?= e($query) ?>&rdquo;. Pick one from the list above.</div>
<?php endif; ?>
<?php if ($searched && !$groups): ?>
    <div class="alert alert-warning">No fare is listed for that route. Try another pick-up zone or destination.</div>
<?php endif; ?>

<?php foreach ($groups as $group): $fare = $group['fare']; ?>
    <div class="card shadow-sm mb-3" style="border-left: 8px solid <?= e($fare['color_hex']) ?>;">
        <div class="card-body">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">
                <div>
                    <span class="badge zone-badge" style="background: <?= e($fare['color_hex']) ?>; color: <?= e($fare['text_hex']) ?>;"><?= e($fare['zone_name']) ?> (<?= e($fare['color_name']) ?>)</span>
                    <span class="ms-2 fw-semibold">to <?= e($fare['location_name']) ?></span>
                </div>
                <div class="text-end">
                    <div><span class="text-muted small">Regular fare</span> <span class="h5 mb-0"><?= e(peso($fare['fare'])) ?></span></div>
                    <div class="small text-muted">Student / Senior / PWD (<?= (int)$discountPct ?>% off): <strong><?= e(peso($fare['discounted_fare'])) ?></strong></div>
                    <?php if ($myDiscountLabel): ?>
                        <div class="small"><span class="badge text-bg-success">Your fare (<?= e($myDiscountLabel) ?>): <?= e(peso($fare['discounted_fare'])) ?></span></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($group['tricycles']): ?>
                <div class="small text-muted mb-2">Available <?= e($fare['color_name']) ?> tricycles right now:</div>
                <div class="row g-2">
                    <?php foreach ($group['tricycles'] as $t): ?>
                        <div class="col-sm-6 col-lg-4"><?php require __DIR__ . '/partial_tricycle_card.php'; ?></div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-muted small">No <?= e($fare['color_name']) ?> tricycle is available right now.</div>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; ?>

<?php
/* All tricycles that are free right now, with a zone filter. Refreshes itself every 30 seconds. */
$chipUrl = fn(int $zid) => url('find', array_filter(['from_zone' => $fromZone ?: null, 'destination' => $destination ?: null, 'zone' => $zid ?: null])) . '#available';
?>
<section id="available" class="mt-4" data-live-url="<?= e($self) ?>">
    <div id="availLive">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
            <h2 class="section-title mb-0">Available now <span class="text-muted fs-6" style="font-family:var(--bs-body-font-family)">(<?= count($availableAll) ?>)</span></h2>
            <span class="small text-muted"><span class="live-dot" aria-hidden="true"></span> Live: updates every 30 seconds</span>
        </div>
        <div class="d-flex flex-wrap gap-2 mb-3" role="group" aria-label="Filter available tricycles by zone">
            <a class="btn btn-sm <?= $zoneFilter === 0 ? 'btn-primary' : 'btn-outline-secondary' ?>" href="<?= e($chipUrl(0)) ?>" <?= $zoneFilter === 0 ? 'aria-current="true"' : '' ?>>All zones (<?= (int)array_sum($zoneAvail) ?>)</a>
            <?php foreach ($zones as $z): $zid = (int)$z['zone_id']; $on = $zoneFilter === $zid; ?>
                <a class="btn btn-sm zone-chip <?= $on ? 'on' : '' ?>" href="<?= e($chipUrl($zid)) ?>" <?= $on ? 'aria-current="true"' : '' ?>
                   style="--chip: <?= e($z['color_hex']) ?>; --chip-ink: <?= e($z['text_hex']) ?>;"><?= e($z['zone_name']) ?> (<?= (int)($zoneAvail[$zid] ?? 0) ?>)</a>
            <?php endforeach; ?>
        </div>
        <?php if ($availableAll): ?>
            <div class="row g-2">
                <?php foreach ($availableAll as $t): ?>
                    <div class="col-sm-6 col-lg-4">
                        <?php require __DIR__ . '/partial_tricycle_card.php'; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-light border mb-0">No tricycle is available<?= $zoneFilter ? ' in this zone' : '' ?> right now. Check again in a moment.</div>
        <?php endif; ?>
    </div>
</section>

<?php if (!$isPassenger && empty($user)): ?>
    <div class="alert alert-light border mt-4 small mb-0">
        Want to save destinations, mark favorite drivers, and rate drivers? <a href="<?= e(url('register', ['type' => 'passenger'])) ?>">Create a free passenger account</a>.
    </div>
<?php endif; ?>
<?php require __DIR__ . '/footer_view.php'; ?>
