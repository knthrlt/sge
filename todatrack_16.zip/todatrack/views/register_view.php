<?php require __DIR__ . '/header_view.php'; ?>
<div class="row justify-content-center reg-page">
    <div class="col-xl-9 col-lg-10">
        <div class="card reg-card">
            <div class="card-body">
                <div class="d-flex flex-wrap justify-content-between align-items-baseline gap-2 mb-3">
                    <h1 class="h3 mb-0">Create an account</h1>
                    <span class="small text-muted">Free for passengers and drivers. Already registered? <a href="<?= e(url('login')) ?>">Log in</a></span>
                </div>
                <?php if ($errors): ?>
                    <div class="alert alert-danger py-2" role="alert">
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= e(url('register')) ?>" data-validate
                      data-confirm="Create this account?" novalidate>
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">

                    <div class="reg-grid">
                        <div class="rg">
                            <label for="first_name" class="form-label">First name</label>
                            <input type="text" class="form-control" id="first_name" name="first_name" maxlength="50"
                                   autocomplete="given-name" value="<?= e($old['first_name']) ?>" placeholder="e.g., Maria" required>
                            <div class="invalid-feedback">First name is required.</div>
                        </div>
                        <div class="rg">
                            <label for="last_name" class="form-label">Last name</label>
                            <input type="text" class="form-control" id="last_name" name="last_name" maxlength="50"
                                   autocomplete="family-name" value="<?= e($old['last_name']) ?>" placeholder="e.g., Santos" required>
                            <div class="invalid-feedback">Last name is required.</div>
                        </div>
                        <div class="rg">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" data-username
                                   pattern="[A-Za-z][A-Za-z0-9_]{4,19}" minlength="5" maxlength="20"
                                   autocomplete="username" autocapitalize="none" spellcheck="false"
                                   value="<?= e($old['username']) ?>" placeholder="5-20 characters, e.g., maria_s" required>
                            <div class="invalid-feedback">5-20 characters, start with a letter; letters, numbers, underscore only.</div>
                        </div>
                        <div class="rg">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" maxlength="120"
                                   value="<?= e($old['email']) ?>" placeholder="name@gmail.com" required>
                            <div class="invalid-feedback">Enter a valid email address.</div>
                        </div>
                        <div class="rg">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" data-strong
                                   minlength="8" maxlength="64" autocomplete="new-password"
                                   placeholder="Create a strong password" required>
                            <div class="invalid-feedback">Your password does not meet all the requirements below.</div>
                        </div>
                        <div class="rg">
                            <label for="confirm_password" class="form-label">Confirm password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password"
                                   data-match="password" autocomplete="new-password" placeholder="Re-enter password" required>
                            <div class="invalid-feedback">Passwords do not match.</div>
                        </div>

                        <div class="rg-full" id="pwRulesBox">
                            <ul class="list-unstyled small mb-2 rule-list rule-grid" id="pwRules" aria-label="Password requirements">
                                <li data-rule="length">8-64 characters</li>
                                <li data-rule="upper">Uppercase (A-Z)</li>
                                <li data-rule="lower">Lowercase (a-z)</li>
                                <li data-rule="number">Number (0-9)</li>
                                <li data-rule="special">Special (! @ # $ %)</li>
                                <li data-rule="space">No spaces</li>
                                <li data-rule="username">Not your username</li>
                                <li data-rule="common">Not a common password</li>
                            </ul>
                            <div class="progress" style="height: 5px;" role="progressbar" aria-label="Password strength">
                                <div class="progress-bar" id="pwBar" style="width: 0%;"></div>
                            </div>
                        </div>

                        <div class="rg-full">
                            <fieldset>
                                <legend class="form-label">I am registering as *</legend>
                                <div class="reg-toggle">
                                    <input type="radio" class="btn-check" name="account_type" id="type_passenger" value="passenger"
                                           <?= $old['account_type'] === 'passenger' ? 'checked' : '' ?> required>
                                    <label class="btn btn-outline-primary" for="type_passenger">Passenger</label>
                                    <input type="radio" class="btn-check" name="account_type" id="type_driver" value="driver"
                                           <?= $old['account_type'] === 'driver' ? 'checked' : '' ?> required>
                                    <label class="btn btn-outline-primary" for="type_driver">Driver</label>
                                </div>
                                <div class="text-danger small mt-1 d-none" id="typeError">Please choose Passenger or Driver.</div>
                            </fieldset>
                        </div>

                        <div id="driverFields" class="rg-full driver-grid <?= $old['account_type'] === 'driver' ? '' : 'd-none' ?>">
                            <div class="rg-full driver-note">Driver details (required for drivers). The admin assigns your tricycle after you register.</div>
                                <div class="rg">
                                    <label for="contact_no" class="form-label">Contact number *</label>
                                    <input class="form-control" id="contact_no" name="contact_no"
                                           pattern="(09[0-9]{9}|\+639[0-9]{9})" inputmode="tel" type="tel" value="<?= e($old['contact_no']) ?>"
                                           placeholder="09171234567" <?= $old['account_type'] === 'driver' ? 'required' : '' ?>>
                                    <div class="invalid-feedback">Use 09171234567 or +639171234567.</div>
                                </div>
                                <div class="rg">
                                    <label for="license_no" class="form-label">License number *</label>
                                    <input type="text" class="form-control" id="license_no" name="license_no"
                                           pattern="[A-Za-z0-9\-]{5,20}" value="<?= e($old['license_no']) ?>"
                                           placeholder="N06-24-000115" <?= $old['account_type'] === 'driver' ? 'required' : '' ?>>
                                    <div class="invalid-feedback">5-20 letters, numbers, or dashes.</div>
                                </div>
                        </div>

                        <div class="rg-full consent">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="privacy_consent" name="privacy_consent" value="1"
                                       <?= $old['privacy_consent'] ? 'checked' : '' ?> required>
                                <label class="form-check-label small" for="privacy_consent">
                                    I have read and agree to the
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#privacyModal">Data Privacy Notice</a>
                                    and consent to the collection of my information. *
                                </label>
                                <div class="invalid-feedback">You must agree to the Data Privacy Notice to create an account.</div>
                            </div>
                        </div>
                        <div class="rg-full submit-cell"><button type="submit" class="btn btn-primary w-100">Register</button></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Data Privacy Notice: the user chooses Agree or Disagree -->
<div class="modal fade" id="privacyModal" tabindex="-1" aria-labelledby="privacyTitle" aria-hidden="true"
     data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="privacyTitle">Data Privacy Notice</h5>
            </div>
            <div class="modal-body">
                <p>TodaTrack collects and uses your personal information in line with the Data Privacy Act of 2012 (Republic Act No. 10173).</p>
                <p class="fw-semibold mb-1">What we collect</p>
                <ul>
                    <li>Full name, username, and email address</li>
                    <li>Your password (stored only as a secure hash, never as plain text)</li>
                    <li><strong>Passengers:</strong> the destinations you save, the drivers you mark as favorite, the ratings and comments you give, and your fare discount type (student, senior, or PWD) if you choose to set one</li>
                    <li><strong>Drivers:</strong> contact number and license number</li>
                </ul>
                <p class="fw-semibold mb-1">Why we collect it</p>
                <ul>
                    <li>To create and secure your account and to run the features you use</li>
                    <li>To show passengers which tricycles are available, along with the driver's name and average star rating. Driver contact numbers are not shown on the public Find a Tricycle page.</li>
                    <li>To show visible ratings and comments on the driver's dashboard. When a passenger submits anonymously, their name is hidden from the driver and other users.</li>
                </ul>
                <p class="fw-semibold mb-1">Who can see it</p>
                <ul>
                    <li>The TODA administrator can see the account details, ratings, and comments of every user, and every driver's license number.</li>
                    <li>Drivers can see their visible ratings and comments. A passenger's name is shown only when they did not submit anonymously; the administrator can still identify anonymous submitters.</li>
                    <li>Drivers see an anonymous list of favorite entries, their added dates, and the total count; names and account details are not shown.</li>
                    <li>Your saved destinations, discount type, email, username, and license number are never shown to the public or to other users.</li>
                    <li>We do not sell or share your data with outside parties.</li>
                </ul>
                <p class="fw-semibold mb-1">Your rights</p>
                <p class="mb-0">You may ask the administrator to view, correct, or delete your information, and you may withdraw your consent at any time.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-danger" id="privacyDisagree">I Disagree</button>
                <button type="button" class="btn btn-primary" id="privacyAgree">I Agree</button>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
