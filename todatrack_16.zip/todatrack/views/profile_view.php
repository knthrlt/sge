<?php require __DIR__ . '/header_view.php'; ?>
<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="page-head">
            <h1 class="h3 mb-0">My Profile</h1>
            <p class="text-muted mb-0">Your discount type is used to show your fare on Find a Tricycle and the Fare Guide.</p>
        </div>
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <form method="post" action="<?= e(url('profile_save')) ?>" data-validate data-confirm="Save your profile?" novalidate>
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <div class="row mb-3">
                        <div class="col-sm-6"><div class="small text-muted">Username</div><div class="fw-semibold"><?= e($profile['username']) ?></div></div>
                        <div class="col-sm-6"><div class="small text-muted">Email</div><div class="fw-semibold"><?= e($profile['email']) ?></div></div>
                    </div>
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full name *</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" maxlength="100" minlength="2"
                               value="<?= e($profile['full_name']) ?>" required>
                        <div class="invalid-feedback">Full name is required (2-100 characters).</div>
                    </div>
                    <div class="mb-3">
                        <label for="discount_type" class="form-label">Fare discount</label>
                        <select class="form-select" id="discount_type" name="discount_type">
                            <option value="">None (regular fare)</option>
                            <?php foreach ($discounts as $key => $label): ?>
                                <option value="<?= e($key) ?>" <?= $profile['discount_type'] === $key ? 'selected' : '' ?>><?= e($label) ?> (<?= (int)$discountPct ?>% off)</option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Pick only if it applies to you. Drivers may ask to see your ID.</div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-add">Save profile</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
