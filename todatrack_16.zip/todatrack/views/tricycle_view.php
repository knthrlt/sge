<?php require __DIR__ . '/header_view.php'; ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h1 class="h3 mb-0">Tricycles</h1>
        <p class="text-muted mb-0">Search the list or filter by zone and status.</p>
    </div>
    <?php if ($user['role'] === 'admin'): ?>
        <a class="btn btn-primary btn-add" href="<?= e(url('tricycle_form')) ?>">+ Add Tricycle</a>
    <?php endif; ?>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="row g-2 mb-3">
            <div class="col-sm-6 col-md-3">
                <label for="filterZone" class="form-label small mb-1">Zone</label>
                <select id="filterZone" class="form-select form-select-sm" data-table="#tricycleTable" data-col="3">
                    <option value="">All zones</option>
                    <?php foreach ($zones as $zone): ?>
                        <option value="<?= e($zone['zone_name']) ?>" <?= (int)($_GET['zone'] ?? 0) === (int)$zone['zone_id'] ? 'selected' : '' ?>><?= e($zone['zone_name']) ?> (<?= e($zone['color_name']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-sm-6 col-md-3">
                <label for="filterStatus" class="form-label small mb-1">Status</label>
                <select id="filterStatus" class="form-select form-select-sm" data-table="#tricycleTable" data-col="5">
                    <option value="">All statuses</option>
                    <?php foreach ($statuses as $label): ?>
                        <option value="<?= e($label) ?>"><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="table-responsive">
            <table id="tricycleTable" class="table table-hover align-middle w-100">
                <thead>
                    <tr>
                        <th data-priority="1">Body No.</th>
                        <th data-priority="7">Plate</th>
                        <th data-priority="5">Driver</th>
                        <th data-priority="3">Zone</th>
                        <th data-priority="6">Current Location</th>
                        <th data-priority="4">Status</th>
                        <th data-priority="8">Updated</th>
                        <th class="no-sort" data-priority="2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($tricycles as $t): ?>
                    <tr>
                        <td class="fw-semibold"><?= e($t['body_number']) ?></td>
                        <td><?= e($t['plate_number']) ?></td>
                        <td><?= e($t['driver_name']) ?><div class="small text-muted"><?= e($t['contact_no']) ?></div></td>
                        <td data-search="<?= e($t['zone_name']) ?>"><span class="badge zone-badge" style="background: <?= e($t['color_hex']) ?>; color: <?= e($t['text_hex']) ?>;"><?= e($t['zone_name']) ?></span></td>
                        <td><?= e($t['location_name']) ?></td>
                        <td data-search="<?= e($t['status_label']) ?>"><span class="badge status-<?= e($t['status']) ?>"><?= e($t['status_label']) ?></span></td>
                        <td data-order="<?= e($t['updated_at']) ?>"><?= e(date('M j, g:i A', strtotime($t['updated_at']))) ?></td>
                        <td class="text-nowrap">
                            <?php if ($user['role'] === 'admin'): ?>
                                <a class="btn btn-sm btn-outline-primary" href="<?= e(url('tricycle_form', ['id' => $t['tricycle_id']])) ?>">Edit</a>
                                <form method="post" action="<?= e(url('tricycle_delete')) ?>" class="d-inline"
                                      data-confirm="Delete tricycle <?= e($t['body_number']) ?>? This cannot be undone." data-confirm-style="danger">
                                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                                    <input type="hidden" name="tricycle_id" value="<?= (int)$t['tricycle_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                </form>
                            <?php elseif ((int)$t['tricycle_id'] === (int)$ownId): ?>
                                <a class="btn btn-sm btn-outline-primary" href="<?= e(url('tricycle_form', ['id' => $t['tricycle_id']])) ?>">Update my status</a>
                            <?php else: ?>
                                <span class="text-muted small">View only</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require __DIR__ . '/footer_view.php'; ?>
